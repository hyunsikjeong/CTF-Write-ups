
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const script_1 = __webpack_require__(/*! ./script */ "./src/script.ts");
const src_1 = __webpack_require__(/*! @watness/common/src */ "../../common/src/index.ts");
const bootstrap_1 = __webpack_require__(/*! ./bootstrap */ "./src/bootstrap.ts");
const howler_1 = __webpack_require__(/*! howler */ "../../node_modules/howler/dist/howler.js");
const challenge = __webpack_require__(/*! ../../assets/Challenge.mp3 */ "../assets/Challenge.mp3");
const $ = __webpack_require__(/*! jquery */ "../../node_modules/jquery/dist/jquery.js");
function runGames(wasmInstance, args) {
    return __awaiter(this, void 0, void 0, function* () {
        $(".selection").addClass("gone");
        let constrainers = [
            (mtx, parts, horizontalPathSegments, verticalPathSegments) => wasmInstance.check(mtx, parts, horizontalPathSegments, verticalPathSegments)
        ];
        let results = [];
        for (let [mtx, additionalOptions] of args) {
            let constraints = mtx.map(row => row.map(({ t }) => t).filter((t) => t !== null)).reduce((l, nxt) => l.concat(nxt), []);
            let segment = yield script_1.createGame($("witness-game")[0], additionalOptions, constrainers, constraints);
            results.push(segment);
        }
        $(".selection").removeClass("gone");
        return results;
    });
}
function runPuzzleRemote(wasmInstance) {
    return __awaiter(this, void 0, void 0, function* () {
        let query = yield fetch("/get-puzzle");
        let bundle = yield query.text();
        let args = wasmInstance.deserializeState(bundle);
        if (args === null) {
            throw new Error("Unreachable");
        }
        let howl = new howler_1.Howl({
            src: [challenge],
        });
        howl.play();
        let gamePromise = runGames(wasmInstance, args);
        let songPromise = new Promise((resolve) => setTimeout(resolve, src_1.Options.TimeLimit));
        let segments = yield Promise.race([gamePromise, songPromise]);
        howl.stop();
        if (!segments) {
            $("witness-game").addClass("gone");
            yield new Promise((resolve) => setTimeout(resolve, 1000));
            $(".failure").removeClass("gone");
            return;
        }
        let result = {
            bundle,
            segments,
        };
        let response = yield fetch("/check-puzzle", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(result),
        });
        let answer = yield response.json();
        if (answer.correct) {
            $(".selection").addClass("gone");
            $(".flag-contents").text(answer.flag);
            $(".flag").removeClass("gone");
        }
        else {
            // failed
        }
    });
}
function runPuzzleLocal(wasmInstance) {
    return __awaiter(this, void 0, void 0, function* () {
        let pts = [];
        let mtx = [];
        let def = src_1.Options.defaultOptions;
        let options = {};
        options.startingPoints = [
            {
                x: Math.floor(Math.random() * (def.tiles.width + 1)),
                y: Math.floor(Math.random() * (def.tiles.height + 1))
            }
        ];
        let path = null;
        while (pts.length < 3) {
            path = src_1.PathUtils.generatePath(def.tiles.width, def.tiles.height, options.startingPoints[0], def.endingPoints[0]);
            if (path === null)
                continue;
            let out = src_1.PathUtils.partition(def.tiles.width, def.tiles.height, [])(path);
            mtx = out[0];
            pts = out[1];
        }
        if (path === null) {
            throw new Error("Unreachable");
        }
        let [horizontalPathSegments, verticalPathSegments] = src_1.PathUtils.getPathSegments(def.tiles.width, def.tiles.height, path);
        let mtxFinal = wasmInstance.gen(mtx, pts, horizontalPathSegments, verticalPathSegments, [true, true, true, true, true, true])[0];
        yield runGames(wasmInstance, [[mtxFinal, options]]);
    });
}
$(window).ready(function () {
    return __awaiter(this, void 0, void 0, function* () {
        let wasmInstance = yield bootstrap_1.default();
        $("#local").on("click", () => runPuzzleLocal(wasmInstance));
        $("#remote").on("click", () => runPuzzleRemote(wasmInstance));
    });
});

