
Object.defineProperty(exports, "__esModule", { value: true });
const PIXI = __webpack_require__(/*! pixi.js */ "../../node_modules/pixi.js/lib/index.js");
const src_1 = __webpack_require__(/*! @watness/common/src */ "../../common/src/index.ts");
//Constraints
let { genShuff, typeToColor, gaussian, copyPath } = src_1.Utils;
;
class Constraint {
    constructor(x, y, classification, name, serializedArguments) {
        this.x = x;
        this.y = y;
        this.classification = classification;
        this.name = name;
        this.serializedArguments = serializedArguments;
    }
    col(x, y, r, classification, name) {
        throw new Error("Uncallable");
    }
    serialize() {
        let { x, y, classification, name } = this;
        return { x, y, classification, name };
    }
}
exports.Constraint = Constraint;
class Constraint1 extends Constraint {
    constructor(x, y, classification, name, serializedArguments) {
        super(x, y, classification, name || "constraint1", serializedArguments);
    }
    col(x, y, r, classification, name) {
        let sprite = new PIXI.Graphics();
        let color = typeToColor(classification);
        sprite.beginFill(color);
        sprite.lineStyle(2, 0x000000);
        sprite.drawCircle(x, y, r * 1.5);
        sprite.endFill();
        sprite.cacheAsBitmap = true;
        return sprite;
    }
}
exports.Constraint1 = Constraint1;
class Constraint2 extends Constraint {
    constructor(x, y, classification, name, serializedArguments) {
        super(x, y, classification, name || "constraint2", serializedArguments);
    }
    col(x, y, r, classification, name) {
        let sprite = new PIXI.Graphics();
        let color = typeToColor(classification);
        sprite.beginFill(color);
        /*
        //Yay geometry!
        let s = 2 / (2 + Math.sqrt(2)) * r
        let h = r - s

        //On the one hand, I should probably iterate over these
        //On the other hand, that sounds like more work than typing these out
        
        sprite.moveTo(Math.round(x + 0), Math.round(y + r + h))
        sprite.lineTo(Math.round(x + h), Math.round(y + r))
        sprite.lineTo(Math.round(x + r), Math.round(y + r))
        sprite.lineTo(Math.round(x + r), Math.round(y + h))
        sprite.lineTo(Math.round(x + r + h), Math.round(y + 0))
        sprite.lineTo(Math.round(x + r), Math.round(y - h))
        sprite.lineTo(Math.round(x + r), Math.round(y - r))
        sprite.lineTo(Math.round(x + h), Math.round(y - r))
        sprite.lineTo(Math.round(x - 0), Math.round(y - r - h))
        sprite.lineTo(Math.round(x - h), Math.round(y - r))
        sprite.lineTo(Math.round(x - r), Math.round(y - r))
        sprite.lineTo(Math.round(x - r), Math.round(y - h))
        sprite.lineTo(Math.round(x - r - h), Math.round(y - 0))
        sprite.lineTo(Math.round(x - r), Math.round(y + h))
        sprite.lineTo(Math.round(x - r), Math.round(y + r))
        sprite.lineTo(Math.round(x - h), Math.round(y + r))
        sprite.lineTo(Math.round(x + 0), Math.round(y + r + h))
        */
        sprite.lineStyle(2, 0x000000);
        sprite.drawCircle(x - r, y, r * 0.7);
        sprite.drawCircle(x + r, y, r * 0.7);
        sprite.endFill();
        sprite.cacheAsBitmap = true;
        return sprite;
    }
}
exports.Constraint2 = Constraint2;
class Constraint3 extends Constraint {
    constructor(x, y, classification, name, serializedArguments) {
        super(x, y, classification, name || "constraint3", serializedArguments);
        this.shape =
            JSON.parse(serializedArguments)
                .map((row) => row.map((args) => parseInt(args.value)));
    }
    col(x, y, r, classification, name) {
        let sprite = new PIXI.Graphics();
        let bh = this.shape.length;
        let bw = this.shape[0].length;
        let color = 0xFFEB3B;
        sprite.beginFill(color);
        sprite.lineStyle(1, 0x000000);
        for (let i = 0; i < bh; i++) {
            for (let j = 0; j < bw; j++) {
                if (this.shape[i][j]) {
                    let cx = (bw - 1) / 2 - j;
                    let cy = (bh - 1) / 2 - i;
                    sprite.drawRect(Math.round(x - cx * r * 3 / 4 - r / 3), Math.round(y - cy * r * 3 / 4 - r / 3), Math.round(r * 2 / 3), Math.round(r * 2 / 3));
                }
            }
        }
        sprite.endFill();
        //let blur = new PIXI.filters.BlurFilter()
        //blur.blur = 0.5;
        //sprite.filters = [blur]
        //sprite.cacheAsBitmap = true
        return sprite;
    }
}
exports.Constraint3 = Constraint3;
class Constraint4 extends Constraint {
    constructor(x, y, classification, name, serializedArguments) {
        super(x, y, classification, name || "Constraint4", serializedArguments);
        this.value = parseInt(serializedArguments);
    }
    col(x, y, r, classification, name) {
        let sprite = new PIXI.Graphics();
        let color = 0xB2EBF2;
        sprite.beginFill(color);
        sprite.lineStyle(1, 0x000000);
        for (let i = 0; i < this.value; i++) {
            let cx = Math.sin(Math.PI / 2 * i);
            let cy = Math.cos(Math.PI / 2 * i);
            sprite.drawRect(Math.round(x - cx * r * 3 / 4 - r / 3), Math.round(y - cy * r * 3 / 4 - r / 3), Math.round(r * 2 / 3), Math.round(r * 2 / 3));
        }
        sprite.endFill();
        return sprite;
    }
}
exports.Constraint4 = Constraint4;
class Constraint5 extends Constraint {
    constructor(x, y, classification, name, serializedArguments) {
        super(x, y, classification, name || "Constraint5", serializedArguments);
    }
    col(x, y, r, classification, name) {
        let sprite = new PIXI.Graphics();
        let color = 0x673AB7;
        sprite.beginFill(color);
        sprite.lineStyle(2, 0x000000);
        sprite.moveTo(x + 0, y + r);
        sprite.lineTo(x + r, y - r);
        sprite.lineTo(x - r, y - r);
        sprite.lineTo(x + 0, y + r);
        sprite.endFill();
        return sprite;
    }
}
exports.Constraint5 = Constraint5;
class Constraint6 extends Constraint {
    constructor(x, y, classification, name, serializedArguments) {
        super(x, y, classification, name || "Constraint6", serializedArguments);
    }
    col(x, y, r, classification, name) {
        let sprite = new PIXI.Graphics();
        sprite.beginFill(src_1.Utils.typeToColor(classification));
        sprite.lineStyle(2, 0x000000);
        sprite.drawRoundedRect(x - r, y - r * 2 / 3, 2 * r, 4 / 3 * r, r * 1 / 4);
        sprite.endFill();
        return sprite;
    }
}
exports.Constraint6 = Constraint6;

