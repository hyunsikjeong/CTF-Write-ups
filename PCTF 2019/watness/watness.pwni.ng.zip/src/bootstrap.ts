
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const wasmPath = __webpack_require__(/*! @watness/wasm/build/untouched.wasm */ "../../wasm/build/untouched.wasm");
const constraints_1 = __webpack_require__(/*! ./constraints */ "./src/constraints.ts");
const loader = __webpack_require__(/*! assemblyscript/lib/loader */ "../../node_modules/assemblyscript/lib/loader/index.js");
const src_1 = __webpack_require__(/*! @watness/common/src */ "../../common/src/index.ts");
function newConstraint(kind, x, y, classification, serializedArgs) {
    switch (kind) {
        case "constraint1":
            return new constraints_1.Constraint1(x, y, classification, kind, serializedArgs);
        case "constraint2":
            return new constraints_1.Constraint2(x, y, classification, kind, serializedArgs);
        case "constraint3":
            return new constraints_1.Constraint3(x, y, classification, kind, serializedArgs);
        case "constraint4":
            return new constraints_1.Constraint4(x, y, classification, kind, serializedArgs);
        case "constraint5":
            return new constraints_1.Constraint5(x, y, classification, kind, serializedArgs);
        case "constraint6":
            return new constraints_1.Constraint6(x, y, classification, kind, serializedArgs);
        default:
            throw new Error(`Unknown constraint ${kind}`);
    }
}
exports.newConstraint = newConstraint;
function default_1() {
    return __awaiter(this, void 0, void 0, function* () {
        let module = yield loader.instantiateStreaming(fetch(wasmPath), {
            env: {},
            index: {
                "console.logI": (x) => console.log("Wasm:", x),
                "console.logS": (x) => console.log("Wasm:", module.getString(x)),
                "console.logIA": (x) => console.log("Wasm:", module.getArray(Int32Array, x)),
            },
        });
        return new src_1.Bootstrap.WasmModule(module, newConstraint);
    });
}
exports.default = default_1;

