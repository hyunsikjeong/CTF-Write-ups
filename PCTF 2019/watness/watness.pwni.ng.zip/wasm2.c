#include <math.h>
#include <string.h>

#include "out.h"
#define UNLIKELY(x) __builtin_expect(!!(x), 0)
#define LIKELY(x) __builtin_expect(!!(x), 1)

#define TRAP(x) (wasm_rt_trap(WASM_RT_TRAP_##x), 0)

#define FUNC_PROLOGUE                                            \
  if (++wasm_rt_call_stack_depth > WASM_RT_MAX_CALL_STACK_DEPTH) \
    TRAP(EXHAUSTION)

#define FUNC_EPILOGUE --wasm_rt_call_stack_depth

#define UNREACHABLE TRAP(UNREACHABLE)

#define CALL_INDIRECT(table, t, ft, x, ...)          \
  (LIKELY((x) < table.size && table.data[x].func &&  \
          table.data[x].func_type == func_types[ft]) \
       ? ((t)table.data[x].func)(__VA_ARGS__)        \
       : TRAP(CALL_INDIRECT))

#define MEMCHECK(mem, a, t)  \
  if (UNLIKELY((a) + sizeof(t) > mem->size)) TRAP(OOB)

#define DEFINE_LOAD(name, t1, t2, t3)              \
  static inline t3 name(wasm_rt_memory_t* mem, u64 addr) {   \
    MEMCHECK(mem, addr, t1);                       \
    t1 result;                                     \
    memcpy(&result, &mem->data[addr], sizeof(t1)); \
    return (t3)(t2)result;                         \
  }

#define DEFINE_STORE(name, t1, t2)                           \
  static inline void name(wasm_rt_memory_t* mem, u64 addr, t2 value) { \
    MEMCHECK(mem, addr, t1);                                 \
    t1 wrapped = (t1)value;                                  \
    memcpy(&mem->data[addr], &wrapped, sizeof(t1));          \
  }

DEFINE_LOAD(i32_load, u32, u32, u32);
DEFINE_LOAD(i64_load, u64, u64, u64);
DEFINE_LOAD(f32_load, f32, f32, f32);
DEFINE_LOAD(f64_load, f64, f64, f64);
DEFINE_LOAD(i32_load8_s, s8, s32, u32);
DEFINE_LOAD(i64_load8_s, s8, s64, u64);
DEFINE_LOAD(i32_load8_u, u8, u32, u32);
DEFINE_LOAD(i64_load8_u, u8, u64, u64);
DEFINE_LOAD(i32_load16_s, s16, s32, u32);
DEFINE_LOAD(i64_load16_s, s16, s64, u64);
DEFINE_LOAD(i32_load16_u, u16, u32, u32);
DEFINE_LOAD(i64_load16_u, u16, u64, u64);
DEFINE_LOAD(i64_load32_s, s32, s64, u64);
DEFINE_LOAD(i64_load32_u, u32, u64, u64);
DEFINE_STORE(i32_store, u32, u32);
DEFINE_STORE(i64_store, u64, u64);
DEFINE_STORE(f32_store, f32, f32);
DEFINE_STORE(f64_store, f64, f64);
DEFINE_STORE(i32_store8, u8, u32);
DEFINE_STORE(i32_store16, u16, u32);
DEFINE_STORE(i64_store8, u8, u64);
DEFINE_STORE(i64_store16, u16, u64);
DEFINE_STORE(i64_store32, u32, u64);

#define I32_CLZ(x) ((x) ? __builtin_clz(x) : 32)
#define I64_CLZ(x) ((x) ? __builtin_clzll(x) : 64)
#define I32_CTZ(x) ((x) ? __builtin_ctz(x) : 32)
#define I64_CTZ(x) ((x) ? __builtin_ctzll(x) : 64)
#define I32_POPCNT(x) (__builtin_popcount(x))
#define I64_POPCNT(x) (__builtin_popcountll(x))

#define DIV_S(ut, min, x, y)                                 \
   ((UNLIKELY((y) == 0)) ?                TRAP(DIV_BY_ZERO)  \
  : (UNLIKELY((x) == min && (y) == -1)) ? TRAP(INT_OVERFLOW) \
  : (ut)((x) / (y)))

#define REM_S(ut, min, x, y)                                \
   ((UNLIKELY((y) == 0)) ?                TRAP(DIV_BY_ZERO) \
  : (UNLIKELY((x) == min && (y) == -1)) ? 0                 \
  : (ut)((x) % (y)))

#define I32_DIV_S(x, y) DIV_S(u32, INT32_MIN, (s32)x, (s32)y)
#define I64_DIV_S(x, y) DIV_S(u64, INT64_MIN, (s64)x, (s64)y)
#define I32_REM_S(x, y) REM_S(u32, INT32_MIN, (s32)x, (s32)y)
#define I64_REM_S(x, y) REM_S(u64, INT64_MIN, (s64)x, (s64)y)

#define DIVREM_U(op, x, y) \
  ((UNLIKELY((y) == 0)) ? TRAP(DIV_BY_ZERO) : ((x) op (y)))

#define DIV_U(x, y) DIVREM_U(/, x, y)
#define REM_U(x, y) DIVREM_U(%, x, y)

#define ROTL(x, y, mask) \
  (((x) << ((y) & (mask))) | ((x) >> (((mask) - (y) + 1) & (mask))))
#define ROTR(x, y, mask) \
  (((x) >> ((y) & (mask))) | ((x) << (((mask) - (y) + 1) & (mask))))

#define I32_ROTL(x, y) ROTL(x, y, 31)
#define I64_ROTL(x, y) ROTL(x, y, 63)
#define I32_ROTR(x, y) ROTR(x, y, 31)
#define I64_ROTR(x, y) ROTR(x, y, 63)

#define FMIN(x, y)                                          \
   ((UNLIKELY((x) != (x))) ? NAN                            \
  : (UNLIKELY((y) != (y))) ? NAN                            \
  : (UNLIKELY((x) == 0 && (y) == 0)) ? (signbit(x) ? x : y) \
  : (x < y) ? x : y)

#define FMAX(x, y)                                          \
   ((UNLIKELY((x) != (x))) ? NAN                            \
  : (UNLIKELY((y) != (y))) ? NAN                            \
  : (UNLIKELY((x) == 0 && (y) == 0)) ? (signbit(x) ? y : x) \
  : (x > y) ? x : y)

#define TRUNC_S(ut, st, ft, min, max, maxop, x)                             \
   ((UNLIKELY((x) != (x))) ? TRAP(INVALID_CONVERSION)                       \
  : (UNLIKELY((x) < (ft)(min) || (x) maxop (ft)(max))) ? TRAP(INT_OVERFLOW) \
  : (ut)(st)(x))

#define I32_TRUNC_S_F32(x) TRUNC_S(u32, s32, f32, INT32_MIN, INT32_MAX, >=, x)
#define I64_TRUNC_S_F32(x) TRUNC_S(u64, s64, f32, INT64_MIN, INT64_MAX, >=, x)
#define I32_TRUNC_S_F64(x) TRUNC_S(u32, s32, f64, INT32_MIN, INT32_MAX, >,  x)
#define I64_TRUNC_S_F64(x) TRUNC_S(u64, s64, f64, INT64_MIN, INT64_MAX, >=, x)

#define TRUNC_U(ut, ft, max, maxop, x)                                    \
   ((UNLIKELY((x) != (x))) ? TRAP(INVALID_CONVERSION)                     \
  : (UNLIKELY((x) <= (ft)-1 || (x) maxop (ft)(max))) ? TRAP(INT_OVERFLOW) \
  : (ut)(x))

#define I32_TRUNC_U_F32(x) TRUNC_U(u32, f32, UINT32_MAX, >=, x)
#define I64_TRUNC_U_F32(x) TRUNC_U(u64, f32, UINT64_MAX, >=, x)
#define I32_TRUNC_U_F64(x) TRUNC_U(u32, f64, UINT32_MAX, >,  x)
#define I64_TRUNC_U_F64(x) TRUNC_U(u64, f64, UINT64_MAX, >=, x)

#define DEFINE_REINTERPRET(name, t1, t2)  \
  static inline t2 name(t1 x) {           \
    t2 result;                            \
    memcpy(&result, &x, sizeof(result));  \
    return result;                        \
  }

DEFINE_REINTERPRET(f32_reinterpret_i32, u32, f32)
DEFINE_REINTERPRET(i32_reinterpret_f32, f32, u32)
DEFINE_REINTERPRET(f64_reinterpret_i64, u64, f64)
DEFINE_REINTERPRET(i64_reinterpret_f64, f64, u64)


static u32 func_types[18];

static void init_func_types(void) {
  func_types[0] = wasm_rt_register_func_type(0, 0);
  func_types[1] = wasm_rt_register_func_type(2, 1, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32);
  func_types[2] = wasm_rt_register_func_type(4, 0, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32);
  func_types[3] = wasm_rt_register_func_type(0, 1, WASM_RT_F64);
  func_types[4] = wasm_rt_register_func_type(1, 0, WASM_RT_I64);
  func_types[5] = wasm_rt_register_func_type(1, 1, WASM_RT_I64, WASM_RT_I64);
  func_types[6] = wasm_rt_register_func_type(1, 1, WASM_RT_I32, WASM_RT_I32);
  func_types[7] = wasm_rt_register_func_type(3, 0, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32);
  func_types[8] = wasm_rt_register_func_type(1, 0, WASM_RT_I32);
  func_types[9] = wasm_rt_register_func_type(5, 1, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32);
  func_types[10] = wasm_rt_register_func_type(3, 1, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32);
  func_types[11] = wasm_rt_register_func_type(4, 1, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32);
  func_types[12] = wasm_rt_register_func_type(6, 1, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32);
  func_types[13] = wasm_rt_register_func_type(6, 0, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32);
  func_types[14] = wasm_rt_register_func_type(2, 0, WASM_RT_I32, WASM_RT_I32);
  func_types[15] = wasm_rt_register_func_type(5, 0, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32);
  func_types[16] = wasm_rt_register_func_type(3, 0, WASM_RT_I32, WASM_RT_I32, WASM_RT_I64);
  func_types[17] = wasm_rt_register_func_type(9, 1, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32, WASM_RT_I32);
}

static void start__lib_allocator_arena(void);
static u32 _lib_string_String_charCodeAt(u32, u32);
static void start____node_modules_assemblyscript_json_assembly_decoder(void);
static u64 _lib_math_murmurHash3(u64);
static u32 _lib_math_splitMix32(u32);
static void _lib_math_NativeMath_seedRandom(u64);
static u32 _lib_internal_arraybuffer_computeSize(u32);
static u32 _lib_allocator_arena___memory_allocate(u32);
static u32 _lib_internal_arraybuffer_allocateUnsafe(u32);
static u32 _lib_memory_memory_allocate(u32);
static void _lib_internal_memory_memset(u32, u32, u32);
static u32 _lib_array_Array_i32__constructor(u32, u32);
static void _lib_internal_memory_memcpy(u32, u32, u32);
static void _lib_internal_memory_memmove(u32, u32, u32);
static void _lib_allocator_arena___memory_free(u32);
static u32 _lib_internal_arraybuffer_reallocateUnsafe(u32, u32);
static void _lib_array_Array_i32____set(u32, u32, u32);
static f64 _lib_math_NativeMath_random(void);
static u32 _lib_array_Array_i32____get(u32, u32);
static u32 start_assembly_index_anonymous_0(u32);
static u32 _lib_array_Array_PathMarker__constructor(u32, u32);
static u32 assembly_index_PathMarker_constructor(u32, u32, u32, u32, u32);
static u32 _lib_array_Array_PathMarker____get(u32, u32);
static u32 _lib_array_Array_PathMarker__push(u32, u32);
static u32 start_assembly_index_anonymous_1(u32);
static void start_assembly_index(void);
static f64 assembly_index_gaussian(void);
static u32 assembly_index_ArrayLen_Array_BoardMatrixElement__(u32);
static u32 _lib_array_Array_Array_BoardMatrixElement_____get(u32, u32);
static u32 assembly_index_ArrayLen_BoardMatrixElement_(u32);
static u32 assembly_index_ArrayLen_Array_PartitionListElement__(u32);
static u32 _lib_array_Array_Array_PartitionListElement_____get(u32, u32);
static u32 assembly_index_ArrayLen_PartitionListElement_(u32);
static u32 assembly_index_ArrayIndex_Array_BoardMatrixElement__(u32, u32);
static u32 _lib_array_Array_BoardMatrixElement____get(u32, u32);
static u32 assembly_index_ArrayIndex_BoardMatrixElement_(u32, u32);
static u32 assembly_index_ArrayIndex_Array_PartitionListElement__(u32, u32);
static u32 _lib_array_Array_PartitionListElement____get(u32, u32);
static u32 assembly_index_ArrayIndex_PartitionListElement_(u32, u32);
static void assembly_index__constrainer(void);
static u32 assembly_index_BoardMatrixElement_constructor(u32, u32, u32);
static u32 assembly_index_BoardMatrixElement_create(u32, u32);
static u32 assembly_index_PartitionListElement_constructor(u32, u32, u32, u32);
static u32 assembly_index_PartitionListElement_create(u32, u32, u32);
static u32 assembly_index_Constraint_check(u32, u32, u32, u32);
static u32 assembly_index_Constraint_gen(u32, u32, u32, u32, u32);
static u32 assembly_index_Constraint_constructor(u32, u32, u32, u32, u32, u32);
static void assembly_index_Constraint_col(u32, u32, u32, u32, u32, u32);
static u32 _lib_array_Array_Constraint__constructor(u32, u32);
static u32 _lib_internal_typedarray_TypedArray_u8__constructor(u32, u32);
static u32 _lib_typedarray_Uint8Array_constructor(u32, u32);
static void _lib_internal_typedarray_TypedArray_u8____set(u32, u32, u32);
static u32 assembly_index_stringToUint8Array(u32);
static u32 _lib_internal_typedarray_TypedArray_u8____get(u32, u32);
static u32 assembly_index_streq(u32, u32);
static u32 _lib_array_Array_Constraint__push(u32, u32);
static u32 assembly_index_Constraint1_check(u32, u32, u32, u32);
static u32 assembly_index_Constraint1_constructor(u32, u32, u32, u32, u32, u32);
static u32 assembly_index_Constraint1_gen(u32, u32, u32, u32, u32);
static u32 _lib_arraybuffer_ArrayBuffer_constructor(u32, u32, u32);
static void _lib_map_Map_i32_i32__clear(u32);
static u32 _lib_map_Map_i32_i32__constructor(u32);
static u32 _lib_internal_hash_hash32(u32);
static u32 _lib_map_Map_i32_i32__find(u32, u32, u32);
static u32 _lib_map_Map_i32_i32__has(u32, u32);
static void _lib_map_Map_i32_i32__rehash(u32, u32);
static void _lib_map_Map_i32_i32__set(u32, u32, u32);
static u32 _lib_map_Map_i32_i32__get(u32, u32);
static u32 _lib_array_Array_i32__push(u32, u32);
static u32 assembly_index_Constraint2_constructor(u32, u32, u32, u32, u32, u32);
static void assembly_index_Constraint2_gen_anonymous_0(u32, u32, u32, u32, u32);
static u32 assembly_index_Constraint2_gen(u32, u32, u32, u32, u32);
static void _lib_map_Map_i32_Array_Constraint___clear(u32);
static u32 _lib_map_Map_i32_Array_Constraint___constructor(u32);
static u32 _lib_map_Map_i32_Array_Constraint___find(u32, u32, u32);
static u32 _lib_map_Map_i32_Array_Constraint___has(u32, u32);
static void _lib_map_Map_i32_Array_Constraint___rehash(u32, u32);
static void _lib_map_Map_i32_Array_Constraint___set(u32, u32, u32);
static u32 _lib_map_Map_i32_Array_Constraint___get(u32, u32);
static u32 _lib_array_Array_Constraint__concat(u32, u32);
static u32 assembly_index_Constraint2_check(u32, u32, u32, u32);
static u32 assembly_index_Constraint3_checkHelper(u32, u32, u32);
static u32 _lib_array_Array_Array_Array_i32____constructor(u32, u32);
static u32 _lib_array_Array_Array_Array_i32____slice(u32, u32, u32);
static u32 _lib_array_Array_Array_Array_i32____slice_trampoline(u32, u32, u32);
static u32 _lib_array_Array_Array_Array_i32____pop(u32);
static u32 assembly_index_Constraint3_brute(u32, u32, u32);
static u32 _lib_array_Array_Array_i32_____get(u32, u32);
static u32 assembly_index_CoordinatePair_constructor(u32, u32, u32);
static u32 assembly_index_Constraint3_check_anonymous_0(u32, u32, u32);
static u32 _lib_array_Array_Constraint3__constructor(u32, u32);
static u32 _lib_array_Array_Constraint3__push(u32, u32);
static u32 assembly_index_Constraint3_check_anonymous_1(u32);
static u32 assembly_index_arrayMap_PartitionListElement_PathMarker_(u32, u32);
static u32 assembly_index_Constraint3_check_anonymous_2(u32);
static u32 _lib_array_Array_Constraint3____get(u32, u32);
static u32 _lib_array_Array_Array_Array_i32____push(u32, u32);
static u32 assembly_index_arrayMap_Constraint3_Array_Array_i32___(u32, u32);
static u32 assembly_index_Constraint3_check_anonymous_3(u32);
static u32 assembly_index_Constraint3_check_anonymous_4(u32);
static u32 assembly_index_Constraint3_check(u32, u32, u32, u32);
static u32 _lib_array_Array_CoordinatePair__constructor(u32, u32);
static void _lib_array_Array_CoordinatePair____unchecked_set(u32, u32, u32);
static u32 _lib_array_Array_Array_PathMarker___constructor(u32, u32);
static void _lib_array_Array_Array_PathMarker_____set(u32, u32, u32);
static u32 _lib_array_Array_Array_PathMarker___concat(u32, u32);
static void _lib_array_Array_PathMarker____set(u32, u32, u32);
static u32 _lib_array_Array_PathMarker__pop(u32);
static u32 _lib_array_Array_CoordinatePair____get(u32, u32);
static u32 _lib_array_Array_PathMarker__concat(u32, u32);
static u32 assembly_index_Constraint3_formShape(u32, u32, u32, u32, u32, u32);
static u32 _lib_array_Array_Array_PathMarker_____get(u32, u32);
static u32 _lib_array_Array_Array_i32___constructor(u32, u32);
static void _lib_array_Array_Array_i32_____set(u32, u32, u32);
static u32 assembly_index_Constraint3_gen_anonymous_0(u32);
static u32 assembly_index_Constraint3_gen_anonymous_1(u32);
static u32 _lib_array_Array_Array_Array_i32______get(u32, u32);
static u32 _lib_internal_number_decimalCount32(u32);
static u32 _lib_internal_string_allocateUnsafe(u32);
static void _lib_internal_number_utoa32_lut(u32, u32, u32);
static u32 _lib_internal_number_itoa32(u32);
static u32 _lib_internal_number_itoa_i32_(u32);
static u32 _lib_number_I32_toString(u32);
static u32 _lib_array_Array_bool____get(u32, u32);
static u32 _lib_array_Array_String__push(u32, u32);
static void ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(u32, u32);
static void _lib_array_Array_bool____set(u32, u32, u32);
static u32 _lib_internal_string_compareUnsafe(u32, u32, u32, u32, u32);
static u32 _lib_string_String___eq(u32, u32);
static u32 _lib_string_String___ne(u32, u32);
static void _lib_internal_string_copyUnsafe(u32, u32, u32, u32, u32);
static u32 _lib_string_String_substring(u32, u32, u32);
static u32 _lib_string_String_concat(u32, u32);
static u32 _lib_string_String___concat(u32, u32);
static void ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_writeString(u32, u32);
static void ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_writeKey(u32, u32);
static void ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_setString(u32, u32, u32);
static void assembly_index_encodeI32(u32, u32);
static u32 _lib_array_Array_bool__constructor(u32, u32);
static u32 _lib_array_Array_String__constructor(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_constructor(u32);
static u32 _lib_array_Array_bool__push(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushArray(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushObject(u32, u32);
static u32 _lib_array_Array_bool__pop(u32);
static void ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popObject(u32);
static void ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popArray(u32);
static u32 _lib_array_Array_String__join(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_toString(u32);
static u32 _lib_string_String_get_lengthUTF8(u32);
static u32 _lib_string_String_toUTF8(u32);
static u32 ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_serialize(u32);
static u32 assembly_index_MatrixEncoder_i32_(u32, u32);
static u32 assembly_index_serializeI32(u32);
static u32 _lib_string_String_fromCharCode(u32);
static void _lib_array_Array_String____set(u32, u32, u32);
static u32 assembly_index_uint8ArrayToString(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_constructor(u32);
static u32 assembly_index_MatrixDecoder_i32__constructor(u32, u32);
static u32 _lib_internal_hash_hashStr(u32);
static u32 _lib_map_Map_String_String__find(u32, u32, u32);
static u32 _lib_map_Map_String_String__get(u32, u32);
static u32 _lib_internal_string_parse_i32_(u32, u32);
static u32 _lib_string_parseI32(u32, u32);
static u32 assembly_index_decodeI32(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___constructor(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_DecoderState_constructor(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___isWhitespace(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___skipWhitespace(u32);
static void _lib_map_Map_String_String__clear(u32);
static u32 _lib_map_Map_String_String__constructor(u32);
static u32 assembly_index_MatrixDecoder_i32__pushObject(u32, u32);
static u32 _lib_string_String_fromUTF8(u32, u32);
static void _lib_array_Array_i32____unchecked_set(u32, u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readHexDigit(u32);
static u32 _lib_string_String_fromCodePoint(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readEscapedChar(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readString(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseKey(u32);
static void assembly_index_MatrixDecoder_i32__popObject(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseObject(u32);
static u32 _lib_array_Array_Array_i32___push(u32, u32);
static u32 assembly_index_MatrixDecoder_i32__pushArray(u32, u32);
static void assembly_index_MatrixDecoder_i32__popArray(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseArray(u32);
static void _lib_map_Map_String_String__rehash(u32, u32);
static void _lib_map_Map_String_String__set(u32, u32, u32);
static void assembly_index_MatrixDecoder_i32__setString(u32, u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseString(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readAndAssert(u32, u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setBoolean(u32, u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseBoolean(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setInteger(u32, u32, u64);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseNumber(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setNull(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseNull(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseValue(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___deserialize(u32, u32, u32);
static u32 assembly_index_MatrixDecoder_i32__getResult(u32);
static u32 assembly_index_Constraint3_constructor(u32, u32, u32, u32, u32, u32);
static u32 assembly_index_Constraint3_gen(u32, u32, u32, u32, u32);
static u32 assembly_index_Constraint4_check(u32, u32, u32, u32);
static u32 assembly_index_Constraint4_constructor(u32, u32, u32, u32, u32, u32);
static u32 assembly_index_Constraint4_gen(u32, u32, u32, u32, u32);
static u32 assembly_index_Constraint5_check(u32, u32, u32, u32);
static u32 assembly_index_Constraint5_constructor(u32, u32, u32, u32, u32, u32);
static u32 assembly_index_Constraint5_gen(u32, u32, u32, u32, u32);
static u32 assembly_index_Constraint6_check(u32, u32, u32, u32);
static u32 assembly_index_Constraint6_constructor(u32, u32, u32, u32, u32, u32);
static u32 assembly_index_Constraint6_gen(u32, u32, u32, u32, u32);
static u32 assembly_index_checkAll(u32, u32, u32, u32);
static u32 assembly_index_State_constructor(u32, u32, u32);
static u32 assembly_index_State_create(u32, u32);
static u32 assembly_index_genAll(u32, u32, u32, u32, u32, u32, u32, u32, u32);
static u32 _lib_array_Array_Array_BoardMatrixElement___constructor(u32, u32);
static u32 assembly_index_MatrixDecoder_BoardMatrixElement__constructor(u32, u32);
static u32 assembly_index_decodeConstraint(u32);
static u32 assembly_index_decodeBoardMatrixElement(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___constructor(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___isWhitespace(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___skipWhitespace(u32);
static u32 assembly_index_MatrixDecoder_BoardMatrixElement__pushObject(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readHexDigit(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readEscapedChar(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readString(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseKey(u32);
static u32 _lib_array_Array_BoardMatrixElement__push(u32, u32);
static void assembly_index_MatrixDecoder_BoardMatrixElement__popObject(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseObject(u32);
static u32 _lib_array_Array_BoardMatrixElement__constructor(u32, u32);
static u32 _lib_array_Array_Array_BoardMatrixElement___push(u32, u32);
static u32 assembly_index_MatrixDecoder_BoardMatrixElement__pushArray(u32, u32);
static void assembly_index_MatrixDecoder_BoardMatrixElement__popArray(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseArray(u32);
static void assembly_index_MatrixDecoder_BoardMatrixElement__setString(u32, u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseString(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readAndAssert(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseBoolean(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseNumber(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseNull(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseValue(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___deserialize(u32, u32, u32);
static u32 assembly_index_MatrixDecoder_BoardMatrixElement__getResult(u32);
static u32 assembly_index_deserializeBoardMatrix(u32);
static u32 _lib_array_Array_Array_PartitionListElement___constructor(u32, u32);
static u32 assembly_index_MatrixDecoder_PartitionListElement__constructor(u32, u32);
static u32 assembly_index_decodePartitionListElement(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___constructor(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___isWhitespace(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___skipWhitespace(u32);
static u32 assembly_index_MatrixDecoder_PartitionListElement__pushObject(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readHexDigit(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readEscapedChar(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readString(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseKey(u32);
static u32 _lib_array_Array_PartitionListElement__push(u32, u32);
static void assembly_index_MatrixDecoder_PartitionListElement__popObject(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseObject(u32);
static u32 _lib_array_Array_PartitionListElement__constructor(u32, u32);
static u32 _lib_array_Array_Array_PartitionListElement___push(u32, u32);
static u32 assembly_index_MatrixDecoder_PartitionListElement__pushArray(u32, u32);
static void assembly_index_MatrixDecoder_PartitionListElement__popArray(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseArray(u32);
static void assembly_index_MatrixDecoder_PartitionListElement__setString(u32, u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseString(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readAndAssert(u32, u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseBoolean(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseNumber(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseNull(u32);
static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseValue(u32);
static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___deserialize(u32, u32, u32);
static u32 assembly_index_MatrixDecoder_PartitionListElement__getResult(u32);
static u32 assembly_index_deserializePartitionList(u32);
static u32 assembly_index_deserializeI32(u32);
static void assembly_index_encodeConstraint(u32, u32);
static void assembly_index_encodeBoardMatrixElement(u32, u32);
static u32 assembly_index_MatrixEncoder_BoardMatrixElement_(u32, u32);
static u32 assembly_index_serializeBoardMatrix(u32);
static void assembly_index_encodePartitionListElement(u32, u32);
static u32 assembly_index_MatrixEncoder_PartitionListElement_(u32, u32);
static u32 assembly_index_serializePartitionList(u32);
static u32 _lib_internal_memory_memcmp(u32, u32, u32);
static u32 _lib_memory_memory_compare(u32, u32, u32);
static void _lib_memory_memory_free(u32);
static void _lib_allocator_arena___memory_reset(void);
static void _lib_memory_memory_reset(void);
static void start(void);
static void null(void);
static u32 BoardMatrixElement_get_p(u32);
static void BoardMatrixElement_set_p(u32, u32);
static u32 BoardMatrixElement_get_t(u32);
static void BoardMatrixElement_set_t(u32, u32);
static u32 PartitionListElement_get_x(u32);
static void PartitionListElement_set_x(u32, u32);
static u32 PartitionListElement_get_y(u32);
static void PartitionListElement_set_y(u32, u32);
static u32 PartitionListElement_get_t(u32);
static void PartitionListElement_set_t(u32, u32);
static u32 Constraint_get_x(u32);
static void Constraint_set_x(u32, u32);
static u32 Constraint_get_y(u32);
static void Constraint_set_y(u32, u32);
static u32 Constraint_get_classification(u32);
static void Constraint_set_classification(u32, u32);
static u32 Constraint_get_name(u32);
static void Constraint_set_name(u32, u32);
static u32 Constraint_get_serializedArgs(u32);
static void Constraint_set_serializedArgs(u32, u32);
static u32 Constraint1_get_x(u32);
static void Constraint1_set_x(u32, u32);
static u32 Constraint1_get_y(u32);
static void Constraint1_set_y(u32, u32);
static u32 Constraint1_get_classification(u32);
static void Constraint1_set_classification(u32, u32);
static u32 Constraint1_get_name(u32);
static void Constraint1_set_name(u32, u32);
static u32 Constraint1_get_serializedArgs(u32);
static void Constraint1_set_serializedArgs(u32, u32);
static u32 Constraint2_get_x(u32);
static void Constraint2_set_x(u32, u32);
static u32 Constraint2_get_y(u32);
static void Constraint2_set_y(u32, u32);
static u32 Constraint2_get_classification(u32);
static void Constraint2_set_classification(u32, u32);
static u32 Constraint2_get_name(u32);
static void Constraint2_set_name(u32, u32);
static u32 Constraint2_get_serializedArgs(u32);
static void Constraint2_set_serializedArgs(u32, u32);
static u32 Constraint3_get_x(u32);
static void Constraint3_set_x(u32, u32);
static u32 Constraint3_get_y(u32);
static void Constraint3_set_y(u32, u32);
static u32 Constraint3_get_classification(u32);
static void Constraint3_set_classification(u32, u32);
static u32 Constraint3_get_name(u32);
static void Constraint3_set_name(u32, u32);
static u32 Constraint3_get_serializedArgs(u32);
static void Constraint3_set_serializedArgs(u32, u32);
static u32 Constraint4_get_x(u32);
static void Constraint4_set_x(u32, u32);
static u32 Constraint4_get_y(u32);
static void Constraint4_set_y(u32, u32);
static u32 Constraint4_get_classification(u32);
static void Constraint4_set_classification(u32, u32);
static u32 Constraint4_get_name(u32);
static void Constraint4_set_name(u32, u32);
static u32 Constraint4_get_serializedArgs(u32);
static void Constraint4_set_serializedArgs(u32, u32);
static u32 Constraint5_get_x(u32);
static void Constraint5_set_x(u32, u32);
static u32 Constraint5_get_y(u32);
static void Constraint5_set_y(u32, u32);
static u32 Constraint5_get_classification(u32);
static void Constraint5_set_classification(u32, u32);
static u32 Constraint5_get_name(u32);
static void Constraint5_set_name(u32, u32);
static u32 Constraint5_get_serializedArgs(u32);
static void Constraint5_set_serializedArgs(u32, u32);
static u32 Constraint6_get_x(u32);
static void Constraint6_set_x(u32, u32);
static u32 Constraint6_get_y(u32);
static void Constraint6_set_y(u32, u32);
static u32 Constraint6_get_classification(u32);
static void Constraint6_set_classification(u32, u32);
static u32 Constraint6_get_name(u32);
static void Constraint6_set_name(u32, u32);
static u32 Constraint6_get_serializedArgs(u32);
static void Constraint6_set_serializedArgs(u32, u32);
static u32 State_get_mtx(u32);
static void State_set_mtx(u32, u32);
static u32 State_get_parts(u32);
static void State_set_parts(u32, u32);

static u32 g0;
static u32 g1;
static u32 g2;
static u32 g3;
static u32 g4;
static u32 g5;
static u32 g6;
static u32 g7;
static u32 g8;
static u32 g9;
static u64 g10;
static u64 g11;
static u32 g12;
static u32 g13;
static u32 genShuff;
static u32 copyPath;
static u32 g16;
static u32 g17;
static u32 g18;
static u32 g19;

static void init_globals(void) {
  g0 = 0u;
  g1 = 0u;
  g2 = 8u;
  g3 = 24u;
  g4 = 40u;
  g5 = 0u;
  g6 = 0u;
  g7 = 0u;
  g8 = 0u;
  g9 = 0u;
  g10 = 0ull;
  g11 = 0ull;
  g12 = 0u;
  g13 = 0u;
  genShuff = 1u;
  copyPath = 2u;
  g16 = 0u;
  g17 = 2147483647u;
  g18 = 0u;
  g19 = 2584u;
}

static wasm_rt_memory_t memory;

static wasm_rt_table_t table;

static void start__lib_allocator_arena(void) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = g19;
  i1 = 7u;
  i0 += i1;
  i1 = 7u;
  i2 = 4294967295u;
  i1 ^= i2;
  i0 &= i1;
  g0 = i0;
  i0 = g0;
  g1 = i0;
  FUNC_EPILOGUE;
}

static u32 _lib_string_String_charCodeAt(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 64u;
    i2 = 75u;
    i3 = 4u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1));
  i0 = i0 >= i1;
  if (i0) {
    i0 = 4294967295u;
    goto Bfunc;
  }
  i0 = p0;
  i1 = p1;
  i2 = 1u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i0 = i32_load16_u((&memory), (u64)(i0 + 4));
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void start____node_modules_assemblyscript_json_assembly_decoder(void) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = 56u;
  i1 = 0u;
  i0 = _lib_string_String_charCodeAt(i0, i1);
  g5 = i0;
  i0 = 96u;
  i1 = 0u;
  i0 = _lib_string_String_charCodeAt(i0, i1);
  g6 = i0;
  i0 = 104u;
  i1 = 0u;
  i0 = _lib_string_String_charCodeAt(i0, i1);
  g7 = i0;
  i0 = 112u;
  i1 = 0u;
  i0 = _lib_string_String_charCodeAt(i0, i1);
  g8 = i0;
  FUNC_EPILOGUE;
}

static u64 _lib_math_murmurHash3(u64 p0) {
  FUNC_PROLOGUE;
  u64 j0, j1, j2;
  j0 = p0;
  j1 = p0;
  j2 = 33ull;
  j1 >>= (j2 & 63);
  j0 ^= j1;
  p0 = j0;
  j0 = p0;
  j1 = 18397679294719823053ull;
  j0 *= j1;
  p0 = j0;
  j0 = p0;
  j1 = p0;
  j2 = 33ull;
  j1 >>= (j2 & 63);
  j0 ^= j1;
  p0 = j0;
  j0 = p0;
  j1 = 14181476777654086739ull;
  j0 *= j1;
  p0 = j0;
  j0 = p0;
  j1 = p0;
  j2 = 33ull;
  j1 >>= (j2 & 63);
  j0 ^= j1;
  p0 = j0;
  j0 = p0;
  FUNC_EPILOGUE;
  return j0;
}

static u32 _lib_math_splitMix32(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = p0;
  i1 = 1831565813u;
  i0 += i1;
  p0 = i0;
  i0 = p0;
  i1 = p0;
  i2 = 15u;
  i1 >>= (i2 & 31);
  i0 ^= i1;
  i1 = p0;
  i2 = 1u;
  i1 |= i2;
  i0 *= i1;
  p0 = i0;
  i0 = p0;
  i1 = p0;
  i2 = p0;
  i3 = p0;
  i4 = 7u;
  i3 >>= (i4 & 31);
  i2 ^= i3;
  i3 = p0;
  i4 = 61u;
  i3 |= i4;
  i2 *= i3;
  i1 += i2;
  i0 ^= i1;
  p0 = i0;
  i0 = p0;
  i1 = p0;
  i2 = 14u;
  i1 >>= (i2 & 31);
  i0 ^= i1;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_math_NativeMath_seedRandom(u64 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  u64 j0, j1;
  j0 = p0;
  i0 = !(j0);
  if (i0) {
    i0 = 0u;
    i1 = 120u;
    i2 = 978u;
    i3 = 4u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = 1u;
  g9 = i0;
  j0 = p0;
  j0 = _lib_math_murmurHash3(j0);
  g10 = j0;
  j0 = g10;
  j1 = 18446744073709551615ull;
  j0 ^= j1;
  j0 = _lib_math_murmurHash3(j0);
  g11 = j0;
  j0 = p0;
  i0 = (u32)(j0);
  i0 = _lib_math_splitMix32(i0);
  g12 = i0;
  i0 = g12;
  i0 = _lib_math_splitMix32(i0);
  g13 = i0;
  FUNC_EPILOGUE;
}

static u32 _lib_internal_arraybuffer_computeSize(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = 1u;
  i1 = 32u;
  i2 = p0;
  i3 = 8u;
  i2 += i3;
  i3 = 1u;
  i2 -= i3;
  i2 = I32_CLZ(i2);
  i1 -= i2;
  i0 <<= (i1 & 31);
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_allocator_arena___memory_allocate(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = p0;
  i1 = 1073741824u;
  i0 = i0 > i1;
  if (i0) {
    UNREACHABLE;
  }
  i0 = g1;
  l1 = i0;
  i0 = l1;
  i1 = p0;
  l2 = i1;
  i2 = 1u;
  l3 = i2;
  i3 = l2;
  i4 = l3;
  i3 = i3 > i4;
  i1 = i3 ? i1 : i2;
  i0 += i1;
  i1 = 7u;
  i0 += i1;
  i1 = 7u;
  i2 = 4294967295u;
  i1 ^= i2;
  i0 &= i1;
  l4 = i0;
  i0 = memory.pages;
  l5 = i0;
  i0 = l4;
  i1 = l5;
  i2 = 16u;
  i1 <<= (i2 & 31);
  i0 = i0 > i1;
  if (i0) {
    i0 = l4;
    i1 = l1;
    i0 -= i1;
    i1 = 65535u;
    i0 += i1;
    i1 = 65535u;
    i2 = 4294967295u;
    i1 ^= i2;
    i0 &= i1;
    i1 = 16u;
    i0 >>= (i1 & 31);
    l2 = i0;
    i0 = l5;
    l3 = i0;
    i1 = l2;
    l6 = i1;
    i2 = l3;
    i3 = l6;
    i2 = (u32)((s32)i2 > (s32)i3);
    i0 = i2 ? i0 : i1;
    l3 = i0;
    i0 = l3;
    i0 = wasm_rt_grow_memory((&memory), i0);
    i1 = 0u;
    i0 = (u32)((s32)i0 < (s32)i1);
    if (i0) {
      i0 = l2;
      i0 = wasm_rt_grow_memory((&memory), i0);
      i1 = 0u;
      i0 = (u32)((s32)i0 < (s32)i1);
      if (i0) {
        UNREACHABLE;
      }
    }
  }
  i0 = l4;
  g1 = i0;
  i0 = l1;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_internal_arraybuffer_allocateUnsafe(u32 p0) {
  u32 l1 = 0, l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i1 = 1073741816u;
  i0 = i0 <= i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 184u;
    i2 = 26u;
    i3 = 2u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = _lib_internal_arraybuffer_computeSize(i0);
  l2 = i0;
  i0 = l2;
  i0 = _lib_allocator_arena___memory_allocate(i0);
  goto B1;
  B1:;
  l1 = i0;
  i0 = l1;
  i1 = p0;
  i32_store((&memory), (u64)(i0), i1);
  i0 = l1;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_memory_memory_allocate(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = _lib_allocator_arena___memory_allocate(i0);
  goto Bfunc;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_internal_memory_memset(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0;
  u64 l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  u64 j0, j1, j2;
  i0 = p2;
  i0 = !(i0);
  if (i0) {
    goto Bfunc;
  }
  i0 = p0;
  i1 = p1;
  i32_store8((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i0 += i1;
  i1 = 1u;
  i0 -= i1;
  i1 = p1;
  i32_store8((&memory), (u64)(i0), i1);
  i0 = p2;
  i1 = 2u;
  i0 = i0 <= i1;
  if (i0) {
    goto Bfunc;
  }
  i0 = p0;
  i1 = 1u;
  i0 += i1;
  i1 = p1;
  i32_store8((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 2u;
  i0 += i1;
  i1 = p1;
  i32_store8((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i0 += i1;
  i1 = 2u;
  i0 -= i1;
  i1 = p1;
  i32_store8((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i0 += i1;
  i1 = 3u;
  i0 -= i1;
  i1 = p1;
  i32_store8((&memory), (u64)(i0), i1);
  i0 = p2;
  i1 = 6u;
  i0 = i0 <= i1;
  if (i0) {
    goto Bfunc;
  }
  i0 = p0;
  i1 = 3u;
  i0 += i1;
  i1 = p1;
  i32_store8((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i0 += i1;
  i1 = 4u;
  i0 -= i1;
  i1 = p1;
  i32_store8((&memory), (u64)(i0), i1);
  i0 = p2;
  i1 = 8u;
  i0 = i0 <= i1;
  if (i0) {
    goto Bfunc;
  }
  i0 = 0u;
  i1 = p0;
  i0 -= i1;
  i1 = 3u;
  i0 &= i1;
  l3 = i0;
  i0 = p0;
  i1 = l3;
  i0 += i1;
  p0 = i0;
  i0 = p2;
  i1 = l3;
  i0 -= i1;
  p2 = i0;
  i0 = p2;
  i1 = 4294967292u;
  i0 &= i1;
  p2 = i0;
  i0 = 4294967295u;
  i1 = 255u;
  i0 = DIV_U(i0, i1);
  i1 = p1;
  i2 = 255u;
  i1 &= i2;
  i0 *= i1;
  l4 = i0;
  i0 = p0;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i0 += i1;
  i1 = 4u;
  i0 -= i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p2;
  i1 = 8u;
  i0 = i0 <= i1;
  if (i0) {
    goto Bfunc;
  }
  i0 = p0;
  i1 = 4u;
  i0 += i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 8u;
  i0 += i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i0 += i1;
  i1 = 12u;
  i0 -= i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i0 += i1;
  i1 = 8u;
  i0 -= i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p2;
  i1 = 24u;
  i0 = i0 <= i1;
  if (i0) {
    goto Bfunc;
  }
  i0 = p0;
  i1 = 12u;
  i0 += i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 16u;
  i0 += i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 20u;
  i0 += i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 24u;
  i0 += i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i0 += i1;
  i1 = 28u;
  i0 -= i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i0 += i1;
  i1 = 24u;
  i0 -= i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i0 += i1;
  i1 = 20u;
  i0 -= i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i0 += i1;
  i1 = 16u;
  i0 -= i1;
  i1 = l4;
  i32_store((&memory), (u64)(i0), i1);
  i0 = 24u;
  i1 = p0;
  i2 = 4u;
  i1 &= i2;
  i0 += i1;
  l3 = i0;
  i0 = p0;
  i1 = l3;
  i0 += i1;
  p0 = i0;
  i0 = p2;
  i1 = l3;
  i0 -= i1;
  p2 = i0;
  i0 = l4;
  j0 = (u64)(i0);
  i1 = l4;
  j1 = (u64)(i1);
  j2 = 32ull;
  j1 <<= (j2 & 63);
  j0 |= j1;
  l5 = j0;
  L7: 
    i0 = p2;
    i1 = 32u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = p0;
      j1 = l5;
      i64_store((&memory), (u64)(i0), j1);
      i0 = p0;
      i1 = 8u;
      i0 += i1;
      j1 = l5;
      i64_store((&memory), (u64)(i0), j1);
      i0 = p0;
      i1 = 16u;
      i0 += i1;
      j1 = l5;
      i64_store((&memory), (u64)(i0), j1);
      i0 = p0;
      i1 = 24u;
      i0 += i1;
      j1 = l5;
      i64_store((&memory), (u64)(i0), j1);
      i0 = p2;
      i1 = 32u;
      i0 -= i1;
      p2 = i0;
      i0 = p0;
      i1 = 32u;
      i0 += i1;
      p0 = i0;
      goto L7;
    }
  Bfunc:;
  FUNC_EPILOGUE;
}

static u32 _lib_array_Array_i32__constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_internal_memory_memcpy(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  L1: 
    i0 = p2;
    if (i0) {
      i0 = p1;
      i1 = 3u;
      i0 &= i1;
    } else {
      i0 = p2;
    }
    if (i0) {
      i0 = p0;
      l5 = i0;
      i1 = 1u;
      i0 += i1;
      p0 = i0;
      i0 = l5;
      i1 = p1;
      l5 = i1;
      i2 = 1u;
      i1 += i2;
      p1 = i1;
      i1 = l5;
      i1 = i32_load8_u((&memory), (u64)(i1));
      i32_store8((&memory), (u64)(i0), i1);
      i0 = p2;
      i1 = 1u;
      i0 -= i1;
      p2 = i0;
      goto L1;
    }
  i0 = p0;
  i1 = 3u;
  i0 &= i1;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    L9: 
      i0 = p2;
      i1 = 16u;
      i0 = i0 >= i1;
      if (i0) {
        i0 = p0;
        i1 = p1;
        i1 = i32_load((&memory), (u64)(i1));
        i32_store((&memory), (u64)(i0), i1);
        i0 = p0;
        i1 = 4u;
        i0 += i1;
        i1 = p1;
        i2 = 4u;
        i1 += i2;
        i1 = i32_load((&memory), (u64)(i1));
        i32_store((&memory), (u64)(i0), i1);
        i0 = p0;
        i1 = 8u;
        i0 += i1;
        i1 = p1;
        i2 = 8u;
        i1 += i2;
        i1 = i32_load((&memory), (u64)(i1));
        i32_store((&memory), (u64)(i0), i1);
        i0 = p0;
        i1 = 12u;
        i0 += i1;
        i1 = p1;
        i2 = 12u;
        i1 += i2;
        i1 = i32_load((&memory), (u64)(i1));
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 16u;
        i0 += i1;
        p1 = i0;
        i0 = p0;
        i1 = 16u;
        i0 += i1;
        p0 = i0;
        i0 = p2;
        i1 = 16u;
        i0 -= i1;
        p2 = i0;
        goto L9;
      }
    i0 = p2;
    i1 = 8u;
    i0 &= i1;
    if (i0) {
      i0 = p0;
      i1 = p1;
      i1 = i32_load((&memory), (u64)(i1));
      i32_store((&memory), (u64)(i0), i1);
      i0 = p0;
      i1 = 4u;
      i0 += i1;
      i1 = p1;
      i2 = 4u;
      i1 += i2;
      i1 = i32_load((&memory), (u64)(i1));
      i32_store((&memory), (u64)(i0), i1);
      i0 = p0;
      i1 = 8u;
      i0 += i1;
      p0 = i0;
      i0 = p1;
      i1 = 8u;
      i0 += i1;
      p1 = i0;
    }
    i0 = p2;
    i1 = 4u;
    i0 &= i1;
    if (i0) {
      i0 = p0;
      i1 = p1;
      i1 = i32_load((&memory), (u64)(i1));
      i32_store((&memory), (u64)(i0), i1);
      i0 = p0;
      i1 = 4u;
      i0 += i1;
      p0 = i0;
      i0 = p1;
      i1 = 4u;
      i0 += i1;
      p1 = i0;
    }
    i0 = p2;
    i1 = 2u;
    i0 &= i1;
    if (i0) {
      i0 = p0;
      i1 = p1;
      i1 = i32_load16_u((&memory), (u64)(i1));
      i32_store16((&memory), (u64)(i0), i1);
      i0 = p0;
      i1 = 2u;
      i0 += i1;
      p0 = i0;
      i0 = p1;
      i1 = 2u;
      i0 += i1;
      p1 = i0;
    }
    i0 = p2;
    i1 = 1u;
    i0 &= i1;
    if (i0) {
      i0 = p0;
      l5 = i0;
      i1 = 1u;
      i0 += i1;
      p0 = i0;
      i0 = l5;
      i1 = p1;
      l5 = i1;
      i2 = 1u;
      i1 += i2;
      p1 = i1;
      i1 = l5;
      i1 = i32_load8_u((&memory), (u64)(i1));
      i32_store8((&memory), (u64)(i0), i1);
    }
    goto Bfunc;
  }
  i0 = p2;
  i1 = 32u;
  i0 = i0 >= i1;
  if (i0) {
    i0 = p0;
    i1 = 3u;
    i0 &= i1;
    l5 = i0;
    i0 = l5;
    i1 = 1u;
    i0 = i0 == i1;
    if (i0) {goto B22;}
    i0 = l5;
    i1 = 2u;
    i0 = i0 == i1;
    if (i0) {goto B21;}
    i0 = l5;
    i1 = 3u;
    i0 = i0 == i1;
    if (i0) {goto B20;}
    goto B19;
    B22:;
    i0 = p1;
    i0 = i32_load((&memory), (u64)(i0));
    l3 = i0;
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p2;
    i1 = 3u;
    i0 -= i1;
    p2 = i0;
    L31: 
      i0 = p2;
      i1 = 17u;
      i0 = i0 >= i1;
      if (i0) {
        i0 = p1;
        i1 = 1u;
        i0 += i1;
        i0 = i32_load((&memory), (u64)(i0));
        l4 = i0;
        i0 = p0;
        i1 = l3;
        i2 = 24u;
        i1 >>= (i2 & 31);
        i2 = l4;
        i3 = 8u;
        i2 <<= (i3 & 31);
        i1 |= i2;
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 5u;
        i0 += i1;
        i0 = i32_load((&memory), (u64)(i0));
        l3 = i0;
        i0 = p0;
        i1 = 4u;
        i0 += i1;
        i1 = l4;
        i2 = 24u;
        i1 >>= (i2 & 31);
        i2 = l3;
        i3 = 8u;
        i2 <<= (i3 & 31);
        i1 |= i2;
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 9u;
        i0 += i1;
        i0 = i32_load((&memory), (u64)(i0));
        l4 = i0;
        i0 = p0;
        i1 = 8u;
        i0 += i1;
        i1 = l3;
        i2 = 24u;
        i1 >>= (i2 & 31);
        i2 = l4;
        i3 = 8u;
        i2 <<= (i3 & 31);
        i1 |= i2;
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 13u;
        i0 += i1;
        i0 = i32_load((&memory), (u64)(i0));
        l3 = i0;
        i0 = p0;
        i1 = 12u;
        i0 += i1;
        i1 = l4;
        i2 = 24u;
        i1 >>= (i2 & 31);
        i2 = l3;
        i3 = 8u;
        i2 <<= (i3 & 31);
        i1 |= i2;
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 16u;
        i0 += i1;
        p1 = i0;
        i0 = p0;
        i1 = 16u;
        i0 += i1;
        p0 = i0;
        i0 = p2;
        i1 = 16u;
        i0 -= i1;
        p2 = i0;
        goto L31;
      }
    goto B19;
    UNREACHABLE;
    B21:;
    i0 = p1;
    i0 = i32_load((&memory), (u64)(i0));
    l3 = i0;
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p2;
    i1 = 2u;
    i0 -= i1;
    p2 = i0;
    L40: 
      i0 = p2;
      i1 = 18u;
      i0 = i0 >= i1;
      if (i0) {
        i0 = p1;
        i1 = 2u;
        i0 += i1;
        i0 = i32_load((&memory), (u64)(i0));
        l4 = i0;
        i0 = p0;
        i1 = l3;
        i2 = 16u;
        i1 >>= (i2 & 31);
        i2 = l4;
        i3 = 16u;
        i2 <<= (i3 & 31);
        i1 |= i2;
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 6u;
        i0 += i1;
        i0 = i32_load((&memory), (u64)(i0));
        l3 = i0;
        i0 = p0;
        i1 = 4u;
        i0 += i1;
        i1 = l4;
        i2 = 16u;
        i1 >>= (i2 & 31);
        i2 = l3;
        i3 = 16u;
        i2 <<= (i3 & 31);
        i1 |= i2;
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 10u;
        i0 += i1;
        i0 = i32_load((&memory), (u64)(i0));
        l4 = i0;
        i0 = p0;
        i1 = 8u;
        i0 += i1;
        i1 = l3;
        i2 = 16u;
        i1 >>= (i2 & 31);
        i2 = l4;
        i3 = 16u;
        i2 <<= (i3 & 31);
        i1 |= i2;
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 14u;
        i0 += i1;
        i0 = i32_load((&memory), (u64)(i0));
        l3 = i0;
        i0 = p0;
        i1 = 12u;
        i0 += i1;
        i1 = l4;
        i2 = 16u;
        i1 >>= (i2 & 31);
        i2 = l3;
        i3 = 16u;
        i2 <<= (i3 & 31);
        i1 |= i2;
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 16u;
        i0 += i1;
        p1 = i0;
        i0 = p0;
        i1 = 16u;
        i0 += i1;
        p0 = i0;
        i0 = p2;
        i1 = 16u;
        i0 -= i1;
        p2 = i0;
        goto L40;
      }
    goto B19;
    UNREACHABLE;
    B20:;
    i0 = p1;
    i0 = i32_load((&memory), (u64)(i0));
    l3 = i0;
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p2;
    i1 = 1u;
    i0 -= i1;
    p2 = i0;
    L47: 
      i0 = p2;
      i1 = 19u;
      i0 = i0 >= i1;
      if (i0) {
        i0 = p1;
        i1 = 3u;
        i0 += i1;
        i0 = i32_load((&memory), (u64)(i0));
        l4 = i0;
        i0 = p0;
        i1 = l3;
        i2 = 8u;
        i1 >>= (i2 & 31);
        i2 = l4;
        i3 = 24u;
        i2 <<= (i3 & 31);
        i1 |= i2;
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 7u;
        i0 += i1;
        i0 = i32_load((&memory), (u64)(i0));
        l3 = i0;
        i0 = p0;
        i1 = 4u;
        i0 += i1;
        i1 = l4;
        i2 = 8u;
        i1 >>= (i2 & 31);
        i2 = l3;
        i3 = 24u;
        i2 <<= (i3 & 31);
        i1 |= i2;
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 11u;
        i0 += i1;
        i0 = i32_load((&memory), (u64)(i0));
        l4 = i0;
        i0 = p0;
        i1 = 8u;
        i0 += i1;
        i1 = l3;
        i2 = 8u;
        i1 >>= (i2 & 31);
        i2 = l4;
        i3 = 24u;
        i2 <<= (i3 & 31);
        i1 |= i2;
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 15u;
        i0 += i1;
        i0 = i32_load((&memory), (u64)(i0));
        l3 = i0;
        i0 = p0;
        i1 = 12u;
        i0 += i1;
        i1 = l4;
        i2 = 8u;
        i1 >>= (i2 & 31);
        i2 = l3;
        i3 = 24u;
        i2 <<= (i3 & 31);
        i1 |= i2;
        i32_store((&memory), (u64)(i0), i1);
        i0 = p1;
        i1 = 16u;
        i0 += i1;
        p1 = i0;
        i0 = p0;
        i1 = 16u;
        i0 += i1;
        p0 = i0;
        i0 = p2;
        i1 = 16u;
        i0 -= i1;
        p2 = i0;
        goto L47;
      }
    goto B19;
    UNREACHABLE;
    B19:;
  }
  i0 = p2;
  i1 = 16u;
  i0 &= i1;
  if (i0) {
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
  }
  i0 = p2;
  i1 = 8u;
  i0 &= i1;
  if (i0) {
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
  }
  i0 = p2;
  i1 = 4u;
  i0 &= i1;
  if (i0) {
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
  }
  i0 = p2;
  i1 = 2u;
  i0 &= i1;
  if (i0) {
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
  }
  i0 = p2;
  i1 = 1u;
  i0 &= i1;
  if (i0) {
    i0 = p0;
    l5 = i0;
    i1 = 1u;
    i0 += i1;
    p0 = i0;
    i0 = l5;
    i1 = p1;
    l5 = i1;
    i2 = 1u;
    i1 += i2;
    p1 = i1;
    i1 = l5;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i32_store8((&memory), (u64)(i0), i1);
  }
  Bfunc:;
  FUNC_EPILOGUE;
}

static void _lib_internal_memory_memmove(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  u64 j1;
  i0 = p0;
  i1 = p1;
  i0 = i0 == i1;
  if (i0) {
    goto Bfunc;
  }
  i0 = p1;
  i1 = p2;
  i0 += i1;
  i1 = p0;
  i0 = i0 <= i1;
  l3 = i0;
  if (i0) {
    i0 = l3;
  } else {
    i0 = p0;
    i1 = p2;
    i0 += i1;
    i1 = p1;
    i0 = i0 <= i1;
  }
  if (i0) {
    i0 = p0;
    i1 = p1;
    i2 = p2;
    _lib_internal_memory_memcpy(i0, i1, i2);
    goto Bfunc;
  }
  i0 = p0;
  i1 = p1;
  i0 = i0 < i1;
  if (i0) {
    i0 = p1;
    i1 = 7u;
    i0 &= i1;
    i1 = p0;
    i2 = 7u;
    i1 &= i2;
    i0 = i0 == i1;
    if (i0) {
      L6: 
        i0 = p0;
        i1 = 7u;
        i0 &= i1;
        if (i0) {
          i0 = p2;
          i0 = !(i0);
          if (i0) {
            goto Bfunc;
          }
          i0 = p2;
          i1 = 1u;
          i0 -= i1;
          p2 = i0;
          i0 = p0;
          l3 = i0;
          i1 = 1u;
          i0 += i1;
          p0 = i0;
          i0 = l3;
          i1 = p1;
          l3 = i1;
          i2 = 1u;
          i1 += i2;
          p1 = i1;
          i1 = l3;
          i1 = i32_load8_u((&memory), (u64)(i1));
          i32_store8((&memory), (u64)(i0), i1);
          goto L6;
        }
      L13: 
        i0 = p2;
        i1 = 8u;
        i0 = i0 >= i1;
        if (i0) {
          i0 = p0;
          i1 = p1;
          j1 = i64_load((&memory), (u64)(i1));
          i64_store((&memory), (u64)(i0), j1);
          i0 = p2;
          i1 = 8u;
          i0 -= i1;
          p2 = i0;
          i0 = p0;
          i1 = 8u;
          i0 += i1;
          p0 = i0;
          i0 = p1;
          i1 = 8u;
          i0 += i1;
          p1 = i0;
          goto L13;
        }
    }
    L17: 
      i0 = p2;
      if (i0) {
        i0 = p0;
        l3 = i0;
        i1 = 1u;
        i0 += i1;
        p0 = i0;
        i0 = l3;
        i1 = p1;
        l3 = i1;
        i2 = 1u;
        i1 += i2;
        p1 = i1;
        i1 = l3;
        i1 = i32_load8_u((&memory), (u64)(i1));
        i32_store8((&memory), (u64)(i0), i1);
        i0 = p2;
        i1 = 1u;
        i0 -= i1;
        p2 = i0;
        goto L17;
      }
  } else {
    i0 = p1;
    i1 = 7u;
    i0 &= i1;
    i1 = p0;
    i2 = 7u;
    i1 &= i2;
    i0 = i0 == i1;
    if (i0) {
      L24: 
        i0 = p0;
        i1 = p2;
        i0 += i1;
        i1 = 7u;
        i0 &= i1;
        if (i0) {
          i0 = p2;
          i0 = !(i0);
          if (i0) {
            goto Bfunc;
          }
          i0 = p0;
          i1 = p2;
          i2 = 1u;
          i1 -= i2;
          p2 = i1;
          i0 += i1;
          i1 = p1;
          i2 = p2;
          i1 += i2;
          i1 = i32_load8_u((&memory), (u64)(i1));
          i32_store8((&memory), (u64)(i0), i1);
          goto L24;
        }
      L29: 
        i0 = p2;
        i1 = 8u;
        i0 = i0 >= i1;
        if (i0) {
          i0 = p2;
          i1 = 8u;
          i0 -= i1;
          p2 = i0;
          i0 = p0;
          i1 = p2;
          i0 += i1;
          i1 = p1;
          i2 = p2;
          i1 += i2;
          j1 = i64_load((&memory), (u64)(i1));
          i64_store((&memory), (u64)(i0), j1);
          goto L29;
        }
    }
    L33: 
      i0 = p2;
      if (i0) {
        i0 = p0;
        i1 = p2;
        i2 = 1u;
        i1 -= i2;
        p2 = i1;
        i0 += i1;
        i1 = p1;
        i2 = p2;
        i1 += i2;
        i1 = i32_load8_u((&memory), (u64)(i1));
        i32_store8((&memory), (u64)(i0), i1);
        goto L33;
      }
  }
  Bfunc:;
  FUNC_EPILOGUE;
}

static void _lib_allocator_arena___memory_free(u32 p0) {
  FUNC_PROLOGUE;
  FUNC_EPILOGUE;
}

static u32 _lib_internal_arraybuffer_reallocateUnsafe(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i0 = (u32)((s32)i0 > (s32)i1);
  if (i0) {
    i0 = p1;
    i1 = 1073741816u;
    i0 = (u32)((s32)i0 <= (s32)i1);
    i0 = !(i0);
    if (i0) {
      i0 = 0u;
      i1 = 184u;
      i2 = 40u;
      i3 = 4u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = p1;
    i1 = l2;
    i1 = _lib_internal_arraybuffer_computeSize(i1);
    i2 = 8u;
    i1 -= i2;
    i0 = (u32)((s32)i0 <= (s32)i1);
    if (i0) {
      i0 = p0;
      i1 = p1;
      i32_store((&memory), (u64)(i0), i1);
    } else {
      i0 = p1;
      i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
      l3 = i0;
      i0 = l3;
      i1 = 8u;
      i0 += i1;
      l4 = i0;
      i0 = p0;
      i1 = 8u;
      i0 += i1;
      l5 = i0;
      i0 = l2;
      l6 = i0;
      i0 = l4;
      i1 = l5;
      i2 = l6;
      _lib_internal_memory_memmove(i0, i1, i2);
      i0 = p0;
      l6 = i0;
      i0 = l6;
      _lib_allocator_arena___memory_free(i0);
      goto B4;
      B4:;
      i0 = l3;
      p0 = i0;
    }
    i0 = p0;
    i1 = 8u;
    i0 += i1;
    i1 = l2;
    i0 += i1;
    l3 = i0;
    i0 = 0u;
    l6 = i0;
    i0 = p1;
    i1 = l2;
    i0 -= i1;
    l5 = i0;
    i0 = l3;
    i1 = l6;
    i2 = l5;
    _lib_internal_memory_memset(i0, i1, i2);
  } else {
    i0 = p1;
    i1 = l2;
    i0 = (u32)((s32)i0 < (s32)i1);
    if (i0) {
      i0 = p1;
      i1 = 0u;
      i0 = (u32)((s32)i0 >= (s32)i1);
      i0 = !(i0);
      if (i0) {
        i0 = 0u;
        i1 = 184u;
        i2 = 62u;
        i3 = 4u;
        (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
        UNREACHABLE;
      }
      i0 = p0;
      i1 = p1;
      i32_store((&memory), (u64)(i0), i1);
    }
  }
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_array_Array_i32____set(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = p1;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = p1;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 107u;
      i3 = 41u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = p1;
    i2 = 1u;
    i1 += i2;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
    i0 = p0;
    i1 = p1;
    i2 = 1u;
    i1 += i2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  }
  i0 = l3;
  l5 = i0;
  i0 = p1;
  l6 = i0;
  i0 = p2;
  l7 = i0;
  i0 = 0u;
  l8 = i0;
  i0 = l5;
  i1 = l6;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l8;
  i0 += i1;
  i1 = l7;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static f64 _lib_math_NativeMath_random(void) {
  u64 l0 = 0, l1 = 0, l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  u64 j0, j1, j2;
  f64 d0, d1;
  i0 = g9;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 120u;
    i2 = 987u;
    i3 = 24u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  j0 = g10;
  l0 = j0;
  j0 = g11;
  l1 = j0;
  j0 = l1;
  g10 = j0;
  j0 = l0;
  j1 = l0;
  j2 = 23ull;
  j1 <<= (j2 & 63);
  j0 ^= j1;
  l0 = j0;
  j0 = l0;
  j1 = l0;
  j2 = 17ull;
  j1 >>= (j2 & 63);
  j0 ^= j1;
  l0 = j0;
  j0 = l0;
  j1 = l1;
  j0 ^= j1;
  l0 = j0;
  j0 = l0;
  j1 = l1;
  j2 = 26ull;
  j1 >>= (j2 & 63);
  j0 ^= j1;
  l0 = j0;
  j0 = l0;
  g11 = j0;
  j0 = l1;
  j1 = l0;
  j0 += j1;
  j1 = 4503599627370495ull;
  j0 &= j1;
  j1 = 4607182418800017408ull;
  j0 |= j1;
  l2 = j0;
  j0 = l2;
  d0 = f64_reinterpret_i64(j0);
  d1 = 1;
  d0 -= d1;
  FUNC_EPILOGUE;
  return d0;
}

static u32 _lib_array_Array_i32____get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = 2u;
  i1 >>= (i2 & 31);
  i0 = i0 < i1;
  if (i0) {
    i0 = l2;
    l3 = i0;
    i0 = p1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = l3;
    i1 = l4;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l5;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 start_assembly_index_anonymous_0(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0;
  f64 l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  f64 d0, d1;
  i0 = 0u;
  i1 = p0;
  i0 = _lib_array_Array_i32__constructor(i0, i1);
  l1 = i0;
  i0 = 0u;
  l2 = i0;
  L1: 
    i0 = l2;
    i1 = p0;
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = l1;
    i1 = l2;
    i2 = l2;
    _lib_array_Array_i32____set(i0, i1, i2);
    i0 = l2;
    i1 = 1u;
    i0 += i1;
    l2 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = 0u;
  l2 = i0;
  L3: 
    i0 = l2;
    i1 = p0;
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B2;}
    d0 = _lib_math_NativeMath_random();
    d0 = _lib_math_NativeMath_random();
    i1 = p0;
    i2 = l2;
    i1 -= i2;
    d1 = (f64)(s32)(i1);
    d0 *= d1;
    l5 = d0;
    d0 = l5;
    d0 = floor(d0);
    i0 = I32_TRUNC_S_F64(d0);
    l3 = i0;
    i0 = l1;
    i1 = l3;
    i2 = l2;
    i1 += i2;
    i0 = _lib_array_Array_i32____get(i0, i1);
    l4 = i0;
    i0 = l1;
    i1 = l3;
    i2 = l2;
    i1 += i2;
    i2 = l1;
    i3 = l2;
    i2 = _lib_array_Array_i32____get(i2, i3);
    _lib_array_Array_i32____set(i0, i1, i2);
    i0 = l1;
    i1 = l2;
    i2 = l4;
    _lib_array_Array_i32____set(i0, i1, i2);
    i0 = l2;
    i1 = 1u;
    i0 += i1;
    l2 = i0;
    goto L3;
  UNREACHABLE;
  B2:;
  i0 = l1;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_PathMarker__constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_PathMarker_constructor(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 10u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i32_store8((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = 0u;
  i32_store8((&memory), (u64)(i0 + 9), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = p3;
  i2 = 0u;
  i1 = i1 != i2;
  i32_store8((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = p4;
  i2 = 0u;
  i1 = i1 != i2;
  i32_store8((&memory), (u64)(i0 + 9), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_PathMarker____get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = 2u;
  i1 >>= (i2 & 31);
  i0 = i0 < i1;
  if (i0) {
    i0 = l2;
    l3 = i0;
    i0 = p1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = l3;
    i1 = l4;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l5;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_PathMarker__push(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l5 = i0;
  i0 = l2;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = l2;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 182u;
      i3 = 42u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = l5;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
  }
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  l6 = i0;
  i0 = l2;
  l7 = i0;
  i0 = p1;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l6;
  i1 = l7;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l9;
  i0 += i1;
  i1 = l8;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 start_assembly_index_anonymous_1(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_PathMarker__constructor(i0, i1);
  l1 = i0;
  i0 = 0u;
  l2 = i0;
  L1: 
    i0 = l2;
    i1 = p0;
    l3 = i1;
    i1 = l3;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = 0u;
    i1 = p0;
    i2 = l2;
    i1 = _lib_array_Array_PathMarker____get(i1, i2);
    i1 = i32_load((&memory), (u64)(i1));
    i2 = p0;
    i3 = l2;
    i2 = _lib_array_Array_PathMarker____get(i2, i3);
    i2 = i32_load((&memory), (u64)(i2 + 4));
    i3 = p0;
    i4 = l2;
    i3 = _lib_array_Array_PathMarker____get(i3, i4);
    i3 = i32_load8_u((&memory), (u64)(i3 + 8));
    i4 = p0;
    i5 = l2;
    i4 = _lib_array_Array_PathMarker____get(i4, i5);
    i4 = i32_load8_u((&memory), (u64)(i4 + 9));
    i0 = assembly_index_PathMarker_constructor(i0, i1, i2, i3, i4);
    l3 = i0;
    i0 = l1;
    i1 = l3;
    i0 = _lib_array_Array_PathMarker__push(i0, i1);
    i0 = l2;
    i1 = 1u;
    i0 += i1;
    l2 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l1;
  FUNC_EPILOGUE;
  return i0;
}

static void start_assembly_index(void) {
  FUNC_PROLOGUE;
  u64 j0;
  f64 d0;
  start__lib_allocator_arena();
  start____node_modules_assemblyscript_json_assembly_decoder();
  d0 = (*Z_DateZ_nowZ_dv)();
  j0 = I64_TRUNC_S_F64(d0);
  _lib_math_NativeMath_seedRandom(j0);
  FUNC_EPILOGUE;
}

static f64 assembly_index_gaussian(void) {
  u32 l0 = 0;
  f64 l1 = 0, l2 = 0, l3 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1;
  f64 d0, d1, d2;
  d0 = 100;
  l1 = d0;
  d0 = 0;
  l2 = d0;
  i0 = 0u;
  l0 = i0;
  L1: 
    i0 = l0;
    d0 = (f64)(s32)(i0);
    d1 = l1;
    i0 = d0 < d1;
    i0 = !(i0);
    if (i0) {goto B0;}
    d0 = l2;
    d1 = _lib_math_NativeMath_random();
    d0 += d1;
    l2 = d0;
    i0 = l0;
    i1 = 1u;
    i0 += i1;
    l0 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  d0 = l2;
  d1 = l1;
  d2 = 0.5;
  d1 *= d2;
  d0 -= d1;
  l2 = d0;
  d0 = l2;
  d1 = l1;
  d2 = 1;
  d1 *= d2;
  d2 = 12;
  d1 /= d2;
  l3 = d1;
  d1 = l3;
  d1 = sqrt(d1);
  d0 /= d1;
  l2 = d0;
  d0 = l2;
  FUNC_EPILOGUE;
  return d0;
}

static u32 assembly_index_ArrayLen_Array_BoardMatrixElement__(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  l1 = i0;
  i0 = l1;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_BoardMatrixElement_____get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = 2u;
  i1 >>= (i2 & 31);
  i0 = i0 < i1;
  if (i0) {
    i0 = l2;
    l3 = i0;
    i0 = p1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = l3;
    i1 = l4;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l5;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_ArrayLen_BoardMatrixElement_(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  l1 = i0;
  i0 = l1;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_ArrayLen_Array_PartitionListElement__(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  l1 = i0;
  i0 = l1;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_PartitionListElement_____get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = 2u;
  i1 >>= (i2 & 31);
  i0 = i0 < i1;
  if (i0) {
    i0 = l2;
    l3 = i0;
    i0 = p1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = l3;
    i1 = l4;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l5;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_ArrayLen_PartitionListElement_(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  l1 = i0;
  i0 = l1;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_ArrayIndex_Array_BoardMatrixElement__(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_BoardMatrixElement____get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = 2u;
  i1 >>= (i2 & 31);
  i0 = i0 < i1;
  if (i0) {
    i0 = l2;
    l3 = i0;
    i0 = p1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = l3;
    i1 = l4;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l5;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_ArrayIndex_BoardMatrixElement_(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_ArrayIndex_Array_PartitionListElement__(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_PartitionListElement____get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = 2u;
  i1 >>= (i2 & 31);
  i0 = i0 < i1;
  if (i0) {
    i0 = l2;
    l3 = i0;
    i0 = p1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = l3;
    i1 = l4;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l5;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_ArrayIndex_PartitionListElement_(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
  FUNC_EPILOGUE;
  return i0;
}

static void assembly_index__constrainer(void) {
  u32 l0 = 0, l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = 256u;
  l0 = i0;
  i0 = 272u;
  l1 = i0;
  i0 = l0;
  i0 = assembly_index_ArrayLen_Array_BoardMatrixElement__(i0);
  i0 = l0;
  i1 = 0u;
  i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
  i0 = assembly_index_ArrayLen_BoardMatrixElement_(i0);
  i0 = l1;
  i0 = assembly_index_ArrayLen_Array_PartitionListElement__(i0);
  i0 = l1;
  i1 = 0u;
  i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
  i0 = assembly_index_ArrayLen_PartitionListElement_(i0);
  i0 = l0;
  i1 = 0u;
  i0 = assembly_index_ArrayIndex_Array_BoardMatrixElement__(i0, i1);
  i0 = l0;
  i1 = 0u;
  i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
  i1 = 0u;
  i0 = assembly_index_ArrayIndex_BoardMatrixElement_(i0, i1);
  i0 = l1;
  i1 = 0u;
  i0 = assembly_index_ArrayIndex_Array_PartitionListElement__(i0, i1);
  i0 = l1;
  i1 = 0u;
  i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
  i1 = 0u;
  i0 = assembly_index_ArrayIndex_PartitionListElement_(i0, i1);
  FUNC_EPILOGUE;
}

static u32 assembly_index_BoardMatrixElement_constructor(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_BoardMatrixElement_create(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 0u;
  i1 = p0;
  i2 = p1;
  i0 = assembly_index_BoardMatrixElement_constructor(i0, i1, i2);
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_PartitionListElement_constructor(u32 p0, u32 p1, u32 p2, u32 p3) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 12u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = p3;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_PartitionListElement_create(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = 0u;
  i1 = p0;
  i2 = p1;
  i3 = p2;
  i0 = assembly_index_PartitionListElement_constructor(i0, i1, i2, i3);
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint_check(u32 p0, u32 p1, u32 p2, u32 p3) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = 288u;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint_gen(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = 304u;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint_constructor(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4, u32 p5) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 20u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 16), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = p3;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = p4;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p5;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = 312u;
    i32_store((&memory), (u64)(i0 + 16), i1);
  } else {
    i0 = p0;
    i1 = p5;
    i32_store((&memory), (u64)(i0 + 16), i1);
  }
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static void assembly_index_Constraint_col(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4, u32 p5) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = 0u;
  i1 = 320u;
  i2 = 205u;
  i3 = 2u;
  (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
  UNREACHABLE;
  FUNC_EPILOGUE;
}

static u32 _lib_array_Array_Constraint__constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_internal_typedarray_TypedArray_u8__constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 1073741816u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 392u;
    i2 = 23u;
    i3 = 34u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 0u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 12u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l2;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_typedarray_Uint8Array_constructor(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 12u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = p1;
  i0 = _lib_internal_typedarray_TypedArray_u8__constructor(i0, i1);
  p0 = i0;
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_internal_typedarray_TypedArray_u8____set(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = 0u;
  i1 >>= (i2 & 31);
  i0 = i0 >= i1;
  if (i0) {
    i0 = 0u;
    i1 = 392u;
    i2 = 50u;
    i3 = 63u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = p1;
  l4 = i0;
  i0 = p2;
  l5 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l6 = i0;
  i0 = l3;
  i1 = l4;
  i2 = 0u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l6;
  i0 += i1;
  i1 = l5;
  i32_store8((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 assembly_index_stringToUint8Array(u32 p0) {
  u32 l1 = 0, l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = 0u;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1));
  i0 = _lib_typedarray_Uint8Array_constructor(i0, i1);
  l1 = i0;
  i0 = 0u;
  l2 = i0;
  L1: 
    i0 = l2;
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = l1;
    i1 = l2;
    i2 = p0;
    i3 = l2;
    i4 = 2u;
    i3 += i4;
    i4 = 2u;
    i3 *= i4;
    i2 += i3;
    i2 = i32_load16_s((&memory), (u64)(i2));
    i3 = 24u;
    i2 <<= (i3 & 31);
    i3 = 24u;
    i2 = (u32)((s32)i2 >> (i3 & 31));
    _lib_internal_typedarray_TypedArray_u8____set(i0, i1, i2);
    i0 = l2;
    i1 = 1u;
    i0 += i1;
    l2 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l1;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_internal_typedarray_TypedArray_u8____get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = 0u;
  i1 >>= (i2 & 31);
  i0 = i0 >= i1;
  if (i0) {
    i0 = 0u;
    i1 = 392u;
    i2 = 39u;
    i3 = 63u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  l3 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l4 = i0;
  i0 = l2;
  i1 = l3;
  i2 = 0u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l4;
  i0 += i1;
  i0 = i32_load8_u((&memory), (u64)(i0 + 8));
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_streq(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = assembly_index_stringToUint8Array(i0);
  l2 = i0;
  i0 = p1;
  i0 = assembly_index_stringToUint8Array(i0);
  l3 = i0;
  i0 = l2;
  l4 = i0;
  i0 = l4;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 0u;
  i0 >>= (i1 & 31);
  i1 = l3;
  l4 = i1;
  i1 = l4;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = 0u;
  i1 >>= (i2 & 31);
  i0 = i0 != i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = 0u;
  l4 = i0;
  L4: 
    i0 = l4;
    i1 = l2;
    l5 = i1;
    i1 = l5;
    i1 = i32_load((&memory), (u64)(i1 + 8));
    i2 = 0u;
    i1 >>= (i2 & 31);
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B3;}
    i0 = l2;
    i1 = l4;
    i0 = _lib_internal_typedarray_TypedArray_u8____get(i0, i1);
    i1 = 255u;
    i0 &= i1;
    i1 = l3;
    i2 = l4;
    i1 = _lib_internal_typedarray_TypedArray_u8____get(i1, i2);
    i2 = 255u;
    i1 &= i2;
    i0 = i0 != i1;
    if (i0) {
      i0 = 0u;
      goto Bfunc;
    }
    i0 = l4;
    i1 = 1u;
    i0 += i1;
    l4 = i0;
    goto L4;
  UNREACHABLE;
  B3:;
  i0 = 1u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Constraint__push(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l5 = i0;
  i0 = l2;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = l2;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 182u;
      i3 = 42u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = l5;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
  }
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  l6 = i0;
  i0 = l2;
  l7 = i0;
  i0 = p1;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l6;
  i1 = l7;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l9;
  i0 += i1;
  i1 = l8;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint1_check(u32 p0, u32 p1, u32 p2, u32 p3) {
  u32 l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  L1: 
    i0 = l5;
    i1 = p1;
    l6 = i1;
    i1 = l6;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = 4294967295u;
    l6 = i0;
    i0 = 0u;
    l7 = i0;
    L5: 
      i0 = l7;
      i1 = p1;
      i2 = l5;
      i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
      l8 = i1;
      i1 = l8;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B4;}
      i0 = p1;
      i1 = l5;
      i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
      i1 = l7;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 8));
      l8 = i0;
      i0 = l8;
      i1 = 0u;
      i0 = i0 != i1;
      l9 = i0;
      if (i0) {
        i0 = l8;
        i0 = i32_load((&memory), (u64)(i0 + 12));
        i1 = 360u;
        i0 = assembly_index_streq(i0, i1);
      } else {
        i0 = l9;
      }
      if (i0) {
        i0 = l6;
        i1 = 4294967295u;
        i0 = i0 == i1;
        if (i0) {
          i0 = l8;
          i0 = i32_load((&memory), (u64)(i0 + 8));
          l6 = i0;
        } else {
          i0 = l8;
          i0 = i32_load((&memory), (u64)(i0 + 8));
          i1 = l6;
          i0 = i0 != i1;
          if (i0) {
            i0 = 456u;
            (*Z_indexZ_consoleZ2ElogSZ_vi)(i0);
            i0 = l8;
            i0 = i32_load((&memory), (u64)(i0));
            (*Z_indexZ_consoleZ2ElogIZ_vi)(i0);
            i0 = l8;
            i0 = i32_load((&memory), (u64)(i0 + 4));
            (*Z_indexZ_consoleZ2ElogIZ_vi)(i0);
            i0 = l4;
            i1 = l8;
            i0 = _lib_array_Array_Constraint__push(i0, i1);
          }
        }
      }
      i0 = l7;
      i1 = 1u;
      i0 += i1;
      l7 = i0;
      goto L5;
    UNREACHABLE;
    B4:;
    i0 = l5;
    i1 = 1u;
    i0 += i1;
    l5 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l4;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint1_constructor(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4, u32 p5) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  i0 = p4;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = 360u;
    p4 = i0;
  }
  i0 = p0;
  if (i0) {
    i0 = p0;
  } else {
    i0 = 20u;
    i0 = _lib_memory_memory_allocate(i0);
  }
  i1 = p1;
  i2 = p2;
  i3 = p3;
  i4 = p4;
  i5 = p5;
  i0 = assembly_index_Constraint_constructor(i0, i1, i2, i3, i4, i5);
  p0 = i0;
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint1_gen(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4) {
  u32 l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0, l11 = 0, l12 = 0, 
      l13 = 0, l14 = 0;
  f64 l15 = 0, l16 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  f64 d0, d1;
  i0 = 3u;
  i1 = 4u;
  i0 = I32_DIV_S(i0, i1);
  l5 = i0;
  i0 = 2u;
  l6 = i0;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l7 = i0;
  i0 = 0u;
  l8 = i0;
  L1: 
    i0 = l8;
    i1 = p1;
    l9 = i1;
    i1 = l9;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    d0 = 0.69999999999999996;
    l15 = d0;
    i0 = p1;
    i1 = l8;
    i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
    l9 = i0;
    i0 = l8;
    l10 = i0;
    i0 = 1u;
    g16 = i0;
    i0 = l9;
    l11 = i0;
    i0 = l11;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = genShuff;
    i0 = CALL_INDIRECT(table, u32 (*)(u32), 6, i1, i0);
    l11 = i0;
    d0 = _lib_math_NativeMath_random();
    d1 = 0.14999999999999999;
    i0 = d0 < d1;
    if (i0) {
      L7: 
        i0 = p1;
        l12 = i0;
        i0 = l12;
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i1 = 1u;
        i0 = (u32)((s32)i0 > (s32)i1);
        l12 = i0;
        if (i0) {
          i0 = l10;
          i1 = l8;
          i0 = i0 == i1;
        } else {
          i0 = l12;
        }
        if (i0) {
          d0 = _lib_math_NativeMath_random();
          i1 = p1;
          l12 = i1;
          i1 = l12;
          i1 = i32_load((&memory), (u64)(i1 + 4));
          d1 = (f64)(s32)(i1);
          d0 *= d1;
          l16 = d0;
          d0 = l16;
          d0 = floor(d0);
          i0 = I32_TRUNC_S_F64(d0);
          l10 = i0;
          goto L7;
        }
    }
    i0 = 0u;
    l12 = i0;
    L14: 
      i0 = l12;
      i1 = l11;
      l13 = i1;
      i1 = l13;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B13;}
      d0 = _lib_math_NativeMath_random();
      d1 = l15;
      i0 = d0 < d1;
      if (i0) {
        d0 = l15;
        i1 = l5;
        d1 = (f64)(s32)(i1);
        d0 *= d1;
        i1 = p2;
        i2 = l6;
        i3 = 1u;
        i2 -= i3;
        i1 += i2;
        i2 = l6;
        i1 = I32_DIV_S(i1, i2);
        d1 = (f64)(s32)(i1);
        d0 /= d1;
        l15 = d0;
        i0 = l9;
        i1 = l11;
        i2 = l12;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
        l13 = i0;
        i0 = 0u;
        i1 = l13;
        i1 = i32_load((&memory), (u64)(i1));
        i2 = l13;
        i2 = i32_load((&memory), (u64)(i2 + 4));
        i3 = l10;
        i4 = 0u;
        i5 = 0u;
        i0 = assembly_index_Constraint1_constructor(i0, i1, i2, i3, i4, i5);
        l14 = i0;
        i0 = p0;
        i1 = l13;
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = l13;
        i1 = i32_load((&memory), (u64)(i1));
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i1 = l14;
        i32_store((&memory), (u64)(i0 + 4), i1);
        i0 = l9;
        i1 = l11;
        i2 = l12;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
        i1 = l14;
        i32_store((&memory), (u64)(i0 + 8), i1);
        i0 = l7;
        i1 = l14;
        i0 = _lib_array_Array_Constraint__push(i0, i1);
      }
      i0 = l12;
      i1 = 1u;
      i0 += i1;
      l12 = i0;
      goto L14;
    UNREACHABLE;
    B13:;
    i0 = l8;
    i1 = 1u;
    i0 += i1;
    l8 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l7;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_arraybuffer_ArrayBuffer_constructor(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 1073741816u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 504u;
    i2 = 47u;
    i3 = 40u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p2;
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = l3;
    i1 = 8u;
    i0 += i1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = p1;
    l6 = i0;
    i0 = l4;
    i1 = l5;
    i2 = l6;
    _lib_internal_memory_memset(i0, i1, i2);
  }
  i0 = l3;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_map_Map_i32_i32__clear(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i1 = 0u;
  i2 = 16u;
  i3 = 0u;
  i1 = _lib_arraybuffer_ArrayBuffer_constructor(i1, i2, i3);
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 4u;
  i2 = 1u;
  i1 -= i2;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i2 = 48u;
  i3 = 1u;
  i1 = _lib_arraybuffer_ArrayBuffer_constructor(i1, i2, i3);
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = 4u;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 16), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 20), i1);
  FUNC_EPILOGUE;
}

static u32 _lib_map_Map_i32_i32__constructor(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 24u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 16), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 20), i1);
  i0 = p0;
  _lib_map_Map_i32_i32__clear(i0);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_internal_hash_hash32(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 2166136261u;
  l1 = i0;
  i0 = l1;
  i1 = p0;
  i2 = 255u;
  i1 &= i2;
  i0 ^= i1;
  i1 = 16777619u;
  i0 *= i1;
  l1 = i0;
  i0 = l1;
  i1 = p0;
  i2 = 8u;
  i1 >>= (i2 & 31);
  i2 = 255u;
  i1 &= i2;
  i0 ^= i1;
  i1 = 16777619u;
  i0 *= i1;
  l1 = i0;
  i0 = l1;
  i1 = p0;
  i2 = 16u;
  i1 >>= (i2 & 31);
  i2 = 255u;
  i1 &= i2;
  i0 ^= i1;
  i1 = 16777619u;
  i0 *= i1;
  l1 = i0;
  i0 = l1;
  i1 = p0;
  i2 = 24u;
  i1 >>= (i2 & 31);
  i0 ^= i1;
  i1 = 16777619u;
  i0 *= i1;
  l1 = i0;
  i0 = l1;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_map_Map_i32_i32__find(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p2;
  i2 = p0;
  i2 = i32_load((&memory), (u64)(i2 + 4));
  i1 &= i2;
  i2 = 4u;
  i1 *= i2;
  i0 += i1;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l3 = i0;
  L1: 
    i0 = l3;
    if (i0) {
      i0 = l3;
      i0 = i32_load((&memory), (u64)(i0 + 8));
      i1 = 1u;
      i0 &= i1;
      i0 = !(i0);
      l4 = i0;
      if (i0) {
        i0 = l3;
        i0 = i32_load((&memory), (u64)(i0));
        i1 = p1;
        i0 = i0 == i1;
      } else {
        i0 = l4;
      }
      if (i0) {
        i0 = l3;
        goto Bfunc;
      }
      i0 = l3;
      i0 = i32_load((&memory), (u64)(i0 + 8));
      i1 = 1u;
      i2 = 4294967295u;
      i1 ^= i2;
      i0 &= i1;
      l3 = i0;
      goto L1;
    }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_map_Map_i32_i32__has(u32 p0, u32 p1) {
  u32 l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i1 = p1;
  i2 = p1;
  l2 = i2;
  i2 = l2;
  i2 = _lib_internal_hash_hash32(i2);
  goto B0;
  B0:;
  i0 = _lib_map_Map_i32_i32__find(i0, i1, i2);
  i1 = 0u;
  i0 = i0 != i1;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_map_Map_i32_i32__rehash(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, 
      l10 = 0, l11 = 0, l12 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  f64 d0, d1;
  i0 = p1;
  i1 = 1u;
  i0 += i1;
  l2 = i0;
  i0 = 0u;
  i1 = l2;
  i2 = 4u;
  i1 *= i2;
  i2 = 0u;
  i0 = _lib_arraybuffer_ArrayBuffer_constructor(i0, i1, i2);
  l3 = i0;
  i0 = l2;
  d0 = (f64)(s32)(i0);
  d1 = 2.6666666666666665;
  d0 *= d1;
  i0 = I32_TRUNC_S_F64(d0);
  l4 = i0;
  i0 = 0u;
  i1 = l4;
  i2 = 12u;
  i1 *= i2;
  i2 = 1u;
  i0 = _lib_arraybuffer_ArrayBuffer_constructor(i0, i1, i2);
  l5 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 8u;
  i0 += i1;
  l6 = i0;
  i0 = l6;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 16));
  i2 = 12u;
  i1 *= i2;
  i0 += i1;
  l7 = i0;
  i0 = l5;
  i1 = 8u;
  i0 += i1;
  l8 = i0;
  L3: 
    i0 = l6;
    i1 = l7;
    i0 = i0 != i1;
    if (i0) {
      i0 = l6;
      l9 = i0;
      i0 = l9;
      i0 = i32_load((&memory), (u64)(i0 + 8));
      i1 = 1u;
      i0 &= i1;
      i0 = !(i0);
      if (i0) {
        i0 = l8;
        l10 = i0;
        i0 = l10;
        i1 = l9;
        i1 = i32_load((&memory), (u64)(i1));
        i32_store((&memory), (u64)(i0), i1);
        i0 = l10;
        i1 = l9;
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i32_store((&memory), (u64)(i0 + 4), i1);
        i0 = l9;
        i0 = i32_load((&memory), (u64)(i0));
        l11 = i0;
        i0 = l11;
        i0 = _lib_internal_hash_hash32(i0);
        goto B7;
        B7:;
        i1 = p1;
        i0 &= i1;
        l11 = i0;
        i0 = l3;
        i1 = l11;
        i2 = 4u;
        i1 *= i2;
        i0 += i1;
        l12 = i0;
        i0 = l10;
        i1 = l12;
        i1 = i32_load((&memory), (u64)(i1 + 8));
        i32_store((&memory), (u64)(i0 + 8), i1);
        i0 = l12;
        i1 = l8;
        i32_store((&memory), (u64)(i0 + 8), i1);
        i0 = l8;
        i1 = 12u;
        i0 += i1;
        l8 = i0;
      }
      i0 = l6;
      i1 = 12u;
      i0 += i1;
      l6 = i0;
      goto L3;
    }
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = l4;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 20));
  i32_store((&memory), (u64)(i0 + 16), i1);
  FUNC_EPILOGUE;
}

static void _lib_map_Map_i32_i32__set(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  f64 d2, d3;
  i0 = p1;
  l3 = i0;
  i0 = l3;
  i0 = _lib_internal_hash_hash32(i0);
  goto B0;
  B0:;
  l4 = i0;
  i0 = p0;
  i1 = p1;
  i2 = l4;
  i0 = _lib_map_Map_i32_i32__find(i0, i1, i2);
  l5 = i0;
  i0 = l5;
  if (i0) {
    i0 = l5;
    i1 = p2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  } else {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 16));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 12));
    i0 = i0 == i1;
    if (i0) {
      i0 = p0;
      i1 = p0;
      i1 = i32_load((&memory), (u64)(i1 + 20));
      i2 = p0;
      i2 = i32_load((&memory), (u64)(i2 + 12));
      d2 = (f64)(s32)(i2);
      d3 = 0.75;
      d2 *= d3;
      i2 = I32_TRUNC_S_F64(d2);
      i1 = (u32)((s32)i1 < (s32)i2);
      if (i1) {
        i1 = p0;
        i1 = i32_load((&memory), (u64)(i1 + 4));
      } else {
        i1 = p0;
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i2 = 1u;
        i1 <<= (i2 & 31);
        i2 = 1u;
        i1 |= i2;
      }
      _lib_map_Map_i32_i32__rehash(i0, i1);
    }
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 8));
    l3 = i0;
    i0 = l3;
    i1 = 8u;
    i0 += i1;
    i1 = p0;
    i2 = p0;
    i2 = i32_load((&memory), (u64)(i2 + 16));
    l6 = i2;
    i3 = 1u;
    i2 += i3;
    i32_store((&memory), (u64)(i1 + 16), i2);
    i1 = l6;
    i2 = 12u;
    i1 *= i2;
    i0 += i1;
    l5 = i0;
    i0 = l5;
    i1 = p1;
    i32_store((&memory), (u64)(i0), i1);
    i0 = l5;
    i1 = p2;
    i32_store((&memory), (u64)(i0 + 4), i1);
    i0 = p0;
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 20));
    i2 = 1u;
    i1 += i2;
    i32_store((&memory), (u64)(i0 + 20), i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = l4;
    i2 = p0;
    i2 = i32_load((&memory), (u64)(i2 + 4));
    i1 &= i2;
    i2 = 4u;
    i1 *= i2;
    i0 += i1;
    l6 = i0;
    i0 = l5;
    i1 = l6;
    i1 = i32_load((&memory), (u64)(i1 + 8));
    i32_store((&memory), (u64)(i0 + 8), i1);
    i0 = l6;
    i1 = l5;
    i32_store((&memory), (u64)(i0 + 8), i1);
  }
  FUNC_EPILOGUE;
}

static u32 _lib_map_Map_i32_i32__get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i1 = p1;
  i2 = p1;
  l2 = i2;
  i2 = l2;
  i2 = _lib_internal_hash_hash32(i2);
  goto B0;
  B0:;
  i0 = _lib_map_Map_i32_i32__find(i0, i1, i2);
  l3 = i0;
  i0 = l3;
  if (i0) {
    i0 = l3;
    i0 = i32_load((&memory), (u64)(i0 + 4));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_i32__push(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l5 = i0;
  i0 = l2;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = l2;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 182u;
      i3 = 42u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = l5;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
  }
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  l6 = i0;
  i0 = l2;
  l7 = i0;
  i0 = p1;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l6;
  i1 = l7;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l9;
  i0 += i1;
  i1 = l8;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint2_constructor(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4, u32 p5) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  i0 = p4;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = 552u;
    p4 = i0;
  }
  i0 = p0;
  if (i0) {
    i0 = p0;
  } else {
    i0 = 20u;
    i0 = _lib_memory_memory_allocate(i0);
  }
  i1 = p1;
  i2 = p2;
  i3 = p3;
  i4 = p4;
  i5 = p5;
  i0 = assembly_index_Constraint_constructor(i0, i1, i2, i3, i4, i5);
  p0 = i0;
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static void assembly_index_Constraint2_gen_anonymous_0(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4) {
  u32 l5 = 0, l6 = 0, l7 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  i0 = 0u;
  l5 = i0;
  L1: 
    i0 = p1;
    i1 = p2;
    i2 = l5;
    i1 = _lib_array_Array_i32____get(i1, i2);
    i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
    i0 = i32_load((&memory), (u64)(i0 + 8));
    i1 = 0u;
    i0 = i0 != i1;
    if (i0) {
      i0 = l5;
      i1 = 1u;
      i0 += i1;
      l5 = i0;
      goto L1;
    }
  i0 = p2;
  i1 = l5;
  i0 = _lib_array_Array_i32____get(i0, i1);
  l6 = i0;
  i0 = 0u;
  i1 = p1;
  i2 = l6;
  i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
  i1 = i32_load((&memory), (u64)(i1));
  i2 = p1;
  i3 = l6;
  i2 = _lib_array_Array_PartitionListElement____get(i2, i3);
  i2 = i32_load((&memory), (u64)(i2 + 4));
  i3 = p4;
  i4 = 0u;
  i5 = 0u;
  i0 = assembly_index_Constraint2_constructor(i0, i1, i2, i3, i4, i5);
  l7 = i0;
  i0 = p1;
  i1 = l6;
  i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
  i1 = l7;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = l7;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
  i1 = l7;
  i1 = i32_load((&memory), (u64)(i1));
  i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
  i1 = l7;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p3;
  i1 = l7;
  i0 = _lib_array_Array_Constraint__push(i0, i1);
  FUNC_EPILOGUE;
}

static u32 assembly_index_Constraint2_gen(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4) {
  u32 l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0, l11 = 0, l12 = 0, 
      l13 = 0, l14 = 0;
  f64 l15 = 0, l16 = 0, l17 = 0, l18 = 0, l19 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  f64 d0, d1, d2;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l5 = i0;
  i0 = 0u;
  l6 = i0;
  L1: 
    i0 = l6;
    i1 = p1;
    l7 = i1;
    i1 = l7;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = p1;
    i1 = l6;
    i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
    l7 = i0;
    i0 = 0u;
    l8 = i0;
    i0 = 0u;
    i0 = _lib_map_Map_i32_i32__constructor(i0);
    l9 = i0;
    i0 = 0u;
    i1 = 0u;
    i0 = _lib_array_Array_i32__constructor(i0, i1);
    l10 = i0;
    i0 = 0u;
    l11 = i0;
    L5: 
      i0 = l11;
      i1 = l7;
      l12 = i1;
      i1 = l12;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B4;}
      i0 = l7;
      i1 = l11;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 8));
      l12 = i0;
      i0 = l12;
      i0 = !(i0);
      if (i0) {
        i0 = l8;
        i1 = 1u;
        i0 += i1;
        l8 = i0;
      } else {
        i0 = l12;
        i0 = i32_load((&memory), (u64)(i0 + 12));
        i1 = 360u;
        i0 = assembly_index_streq(i0, i1);
        l13 = i0;
        if (i0) {
          i0 = l13;
        } else {
          i0 = l12;
          i0 = i32_load((&memory), (u64)(i0 + 12));
          i1 = 552u;
          i0 = assembly_index_streq(i0, i1);
        }
        if (i0) {
          i0 = l12;
          i0 = i32_load((&memory), (u64)(i0 + 8));
          l13 = i0;
          i0 = l9;
          i1 = l13;
          i0 = _lib_map_Map_i32_i32__has(i0, i1);
          i0 = !(i0);
          if (i0) {
            i0 = l9;
            i1 = l13;
            i2 = 0u;
            _lib_map_Map_i32_i32__set(i0, i1, i2);
            i0 = l9;
            i1 = l13;
            i0 = _lib_map_Map_i32_i32__get(i0, i1);
            i0 = l10;
            i1 = l13;
            i0 = _lib_array_Array_i32__push(i0, i1);
          }
          i0 = l9;
          i1 = l13;
          i2 = l9;
          i3 = l13;
          i2 = _lib_map_Map_i32_i32__get(i2, i3);
          i3 = 1u;
          i2 += i3;
          _lib_map_Map_i32_i32__set(i0, i1, i2);
        }
      }
      i0 = l11;
      i1 = 1u;
      i0 += i1;
      l11 = i0;
      goto L5;
    UNREACHABLE;
    B4:;
    i0 = l8;
    i1 = 2u;
    i0 = I32_DIV_S(i0, i1);
    d0 = (f64)(s32)(i0);
    l15 = d0;
    d0 = l15;
    d0 = floor(d0);
    l15 = d0;
    d0 = l15;
    d1 = 1;
    d0 *= d1;
    d1 = 1;
    i2 = p2;
    d2 = (f64)(s32)(i2);
    d1 += d2;
    d0 /= d1;
    l16 = d0;
    d0 = l16;
    d0 = ceil(d0);
    l16 = d0;
    d0 = assembly_index_gaussian();
    d1 = l16;
    d0 += d1;
    l17 = d0;
    d0 = l17;
    d1 = 0.5;
    d0 += d1;
    d0 = floor(d0);
    d1 = l17;
    d0 = copysign(d0, d1);
    l17 = d0;
    d0 = l17;
    l18 = d0;
    d0 = l15;
    l19 = d0;
    d0 = l18;
    d1 = l19;
    d0 = FMIN(d0, d1);
    l17 = d0;
    i0 = 1u;
    g16 = i0;
    i0 = l7;
    l11 = i0;
    i0 = l11;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = genShuff;
    i0 = CALL_INDIRECT(table, u32 (*)(u32), 6, i1, i0);
    l11 = i0;
    i0 = 3u;
    l12 = i0;
    d0 = l17;
    d1 = 0;
    i0 = d0 > d1;
    if (i0) {
      i0 = 0u;
      l13 = i0;
      L20: 
        i0 = l13;
        i1 = l10;
        l14 = i1;
        i1 = l14;
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i0 = (u32)((s32)i0 < (s32)i1);
        i0 = !(i0);
        if (i0) {goto B19;}
        i0 = l10;
        i1 = l13;
        i0 = _lib_array_Array_i32____get(i0, i1);
        l14 = i0;
        i0 = l9;
        i1 = l14;
        i0 = _lib_map_Map_i32_i32__get(i0, i1);
        i1 = 1u;
        i0 = i0 == i1;
        if (i0) {
          i0 = 5u;
          g16 = i0;
          i0 = p0;
          i1 = l7;
          i2 = l11;
          i3 = l5;
          i4 = l14;
          i5 = l12;
          CALL_INDIRECT(table, void (*)(u32, u32, u32, u32, u32), 15, i5, i0, i1, i2, i3, i4);
          d0 = l17;
          d1 = 1;
          d0 -= d1;
          l17 = d0;
          goto B19;
        }
        i0 = l13;
        i1 = 1u;
        i0 += i1;
        l13 = i0;
        goto L20;
      UNREACHABLE;
      B19:;
    }
    i0 = 0u;
    l13 = i0;
    L25: 
      d0 = l17;
      d1 = 0;
      i0 = d0 > d1;
      if (i0) {
        L29: 
          i0 = l10;
          l14 = i0;
          i0 = l14;
          i0 = i32_load((&memory), (u64)(i0 + 4));
          i1 = p1;
          l14 = i1;
          i1 = l14;
          i1 = i32_load((&memory), (u64)(i1 + 4));
          i0 = (u32)((s32)i0 < (s32)i1);
          if (i0) {
            i0 = l9;
            i1 = l13;
            i0 = _lib_map_Map_i32_i32__has(i0, i1);
            i1 = 0u;
            i0 = i0 == i1;
            if (i0) {
              goto B28;
            }
            i0 = l13;
            i1 = 1u;
            i0 += i1;
            l13 = i0;
            goto L29;
          }
        B28:;
        i0 = 5u;
        g16 = i0;
        i0 = p0;
        i1 = l7;
        i2 = l11;
        i3 = l5;
        i4 = l13;
        i5 = l12;
        CALL_INDIRECT(table, void (*)(u32, u32, u32, u32, u32), 15, i5, i0, i1, i2, i3, i4);
        i0 = 5u;
        g16 = i0;
        i0 = p0;
        i1 = l7;
        i2 = l11;
        i3 = l5;
        i4 = l13;
        i5 = l12;
        CALL_INDIRECT(table, void (*)(u32, u32, u32, u32, u32), 15, i5, i0, i1, i2, i3, i4);
        i0 = l13;
        i1 = 1u;
        i0 += i1;
        l13 = i0;
        d0 = l17;
        d1 = 1;
        d0 -= d1;
        l17 = d0;
        goto L25;
      }
    i0 = l6;
    i1 = 1u;
    i0 += i1;
    l6 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_map_Map_i32_Array_Constraint___clear(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i1 = 0u;
  i2 = 16u;
  i3 = 0u;
  i1 = _lib_arraybuffer_ArrayBuffer_constructor(i1, i2, i3);
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 4u;
  i2 = 1u;
  i1 -= i2;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i2 = 48u;
  i3 = 1u;
  i1 = _lib_arraybuffer_ArrayBuffer_constructor(i1, i2, i3);
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = 4u;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 16), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 20), i1);
  FUNC_EPILOGUE;
}

static u32 _lib_map_Map_i32_Array_Constraint___constructor(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 24u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 16), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 20), i1);
  i0 = p0;
  _lib_map_Map_i32_Array_Constraint___clear(i0);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_map_Map_i32_Array_Constraint___find(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p2;
  i2 = p0;
  i2 = i32_load((&memory), (u64)(i2 + 4));
  i1 &= i2;
  i2 = 4u;
  i1 *= i2;
  i0 += i1;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l3 = i0;
  L1: 
    i0 = l3;
    if (i0) {
      i0 = l3;
      i0 = i32_load((&memory), (u64)(i0 + 8));
      i1 = 1u;
      i0 &= i1;
      i0 = !(i0);
      l4 = i0;
      if (i0) {
        i0 = l3;
        i0 = i32_load((&memory), (u64)(i0));
        i1 = p1;
        i0 = i0 == i1;
      } else {
        i0 = l4;
      }
      if (i0) {
        i0 = l3;
        goto Bfunc;
      }
      i0 = l3;
      i0 = i32_load((&memory), (u64)(i0 + 8));
      i1 = 1u;
      i2 = 4294967295u;
      i1 ^= i2;
      i0 &= i1;
      l3 = i0;
      goto L1;
    }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_map_Map_i32_Array_Constraint___has(u32 p0, u32 p1) {
  u32 l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i1 = p1;
  i2 = p1;
  l2 = i2;
  i2 = l2;
  i2 = _lib_internal_hash_hash32(i2);
  goto B0;
  B0:;
  i0 = _lib_map_Map_i32_Array_Constraint___find(i0, i1, i2);
  i1 = 0u;
  i0 = i0 != i1;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_map_Map_i32_Array_Constraint___rehash(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, 
      l10 = 0, l11 = 0, l12 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  f64 d0, d1;
  i0 = p1;
  i1 = 1u;
  i0 += i1;
  l2 = i0;
  i0 = 0u;
  i1 = l2;
  i2 = 4u;
  i1 *= i2;
  i2 = 0u;
  i0 = _lib_arraybuffer_ArrayBuffer_constructor(i0, i1, i2);
  l3 = i0;
  i0 = l2;
  d0 = (f64)(s32)(i0);
  d1 = 2.6666666666666665;
  d0 *= d1;
  i0 = I32_TRUNC_S_F64(d0);
  l4 = i0;
  i0 = 0u;
  i1 = l4;
  i2 = 12u;
  i1 *= i2;
  i2 = 1u;
  i0 = _lib_arraybuffer_ArrayBuffer_constructor(i0, i1, i2);
  l5 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 8u;
  i0 += i1;
  l6 = i0;
  i0 = l6;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 16));
  i2 = 12u;
  i1 *= i2;
  i0 += i1;
  l7 = i0;
  i0 = l5;
  i1 = 8u;
  i0 += i1;
  l8 = i0;
  L3: 
    i0 = l6;
    i1 = l7;
    i0 = i0 != i1;
    if (i0) {
      i0 = l6;
      l9 = i0;
      i0 = l9;
      i0 = i32_load((&memory), (u64)(i0 + 8));
      i1 = 1u;
      i0 &= i1;
      i0 = !(i0);
      if (i0) {
        i0 = l8;
        l10 = i0;
        i0 = l10;
        i1 = l9;
        i1 = i32_load((&memory), (u64)(i1));
        i32_store((&memory), (u64)(i0), i1);
        i0 = l10;
        i1 = l9;
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i32_store((&memory), (u64)(i0 + 4), i1);
        i0 = l9;
        i0 = i32_load((&memory), (u64)(i0));
        l11 = i0;
        i0 = l11;
        i0 = _lib_internal_hash_hash32(i0);
        goto B7;
        B7:;
        i1 = p1;
        i0 &= i1;
        l11 = i0;
        i0 = l3;
        i1 = l11;
        i2 = 4u;
        i1 *= i2;
        i0 += i1;
        l12 = i0;
        i0 = l10;
        i1 = l12;
        i1 = i32_load((&memory), (u64)(i1 + 8));
        i32_store((&memory), (u64)(i0 + 8), i1);
        i0 = l12;
        i1 = l8;
        i32_store((&memory), (u64)(i0 + 8), i1);
        i0 = l8;
        i1 = 12u;
        i0 += i1;
        l8 = i0;
      }
      i0 = l6;
      i1 = 12u;
      i0 += i1;
      l6 = i0;
      goto L3;
    }
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = l4;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 20));
  i32_store((&memory), (u64)(i0 + 16), i1);
  FUNC_EPILOGUE;
}

static void _lib_map_Map_i32_Array_Constraint___set(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  f64 d2, d3;
  i0 = p1;
  l3 = i0;
  i0 = l3;
  i0 = _lib_internal_hash_hash32(i0);
  goto B0;
  B0:;
  l4 = i0;
  i0 = p0;
  i1 = p1;
  i2 = l4;
  i0 = _lib_map_Map_i32_Array_Constraint___find(i0, i1, i2);
  l5 = i0;
  i0 = l5;
  if (i0) {
    i0 = l5;
    i1 = p2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  } else {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 16));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 12));
    i0 = i0 == i1;
    if (i0) {
      i0 = p0;
      i1 = p0;
      i1 = i32_load((&memory), (u64)(i1 + 20));
      i2 = p0;
      i2 = i32_load((&memory), (u64)(i2 + 12));
      d2 = (f64)(s32)(i2);
      d3 = 0.75;
      d2 *= d3;
      i2 = I32_TRUNC_S_F64(d2);
      i1 = (u32)((s32)i1 < (s32)i2);
      if (i1) {
        i1 = p0;
        i1 = i32_load((&memory), (u64)(i1 + 4));
      } else {
        i1 = p0;
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i2 = 1u;
        i1 <<= (i2 & 31);
        i2 = 1u;
        i1 |= i2;
      }
      _lib_map_Map_i32_Array_Constraint___rehash(i0, i1);
    }
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 8));
    l3 = i0;
    i0 = l3;
    i1 = 8u;
    i0 += i1;
    i1 = p0;
    i2 = p0;
    i2 = i32_load((&memory), (u64)(i2 + 16));
    l6 = i2;
    i3 = 1u;
    i2 += i3;
    i32_store((&memory), (u64)(i1 + 16), i2);
    i1 = l6;
    i2 = 12u;
    i1 *= i2;
    i0 += i1;
    l5 = i0;
    i0 = l5;
    i1 = p1;
    i32_store((&memory), (u64)(i0), i1);
    i0 = l5;
    i1 = p2;
    i32_store((&memory), (u64)(i0 + 4), i1);
    i0 = p0;
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 20));
    i2 = 1u;
    i1 += i2;
    i32_store((&memory), (u64)(i0 + 20), i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = l4;
    i2 = p0;
    i2 = i32_load((&memory), (u64)(i2 + 4));
    i1 &= i2;
    i2 = 4u;
    i1 *= i2;
    i0 += i1;
    l6 = i0;
    i0 = l5;
    i1 = l6;
    i1 = i32_load((&memory), (u64)(i1 + 8));
    i32_store((&memory), (u64)(i0 + 8), i1);
    i0 = l6;
    i1 = l5;
    i32_store((&memory), (u64)(i0 + 8), i1);
  }
  FUNC_EPILOGUE;
}

static u32 _lib_map_Map_i32_Array_Constraint___get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i1 = p1;
  i2 = p1;
  l2 = i2;
  i2 = l2;
  i2 = _lib_internal_hash_hash32(i2);
  goto B0;
  B0:;
  i0 = _lib_map_Map_i32_Array_Constraint___find(i0, i1, i2);
  l3 = i0;
  i0 = l3;
  if (i0) {
    i0 = l3;
    i0 = i32_load((&memory), (u64)(i0 + 4));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Constraint__concat(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = 0u;
  i1 = p1;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i2 = p1;
  i3 = 0u;
  i2 = i2 == i3;
  i0 = i2 ? i0 : i1;
  l3 = i0;
  i0 = l2;
  i1 = l3;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  i1 = l4;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l5 = i0;
  i0 = l2;
  if (i0) {
    i0 = l5;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    l6 = i0;
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    l7 = i0;
    i0 = l2;
    i1 = 2u;
    i0 <<= (i1 & 31);
    l8 = i0;
    i0 = l6;
    i1 = l7;
    i2 = l8;
    _lib_internal_memory_memmove(i0, i1, i2);
  }
  i0 = l3;
  if (i0) {
    i0 = l5;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    i1 = l2;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    l8 = i0;
    i0 = p1;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    l7 = i0;
    i0 = l3;
    i1 = 2u;
    i0 <<= (i1 & 31);
    l6 = i0;
    i0 = l8;
    i1 = l7;
    i2 = l6;
    _lib_internal_memory_memmove(i0, i1, i2);
  }
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint2_check(u32 p0, u32 p1, u32 p2, u32 p3) {
  u32 l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0, l11 = 0, 
      l12 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  L1: 
    i0 = l5;
    i1 = p1;
    l6 = i1;
    i1 = l6;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = 0u;
    i0 = _lib_map_Map_i32_i32__constructor(i0);
    l6 = i0;
    i0 = 0u;
    i0 = _lib_map_Map_i32_Array_Constraint___constructor(i0);
    l7 = i0;
    i0 = 0u;
    i1 = 0u;
    i0 = _lib_array_Array_i32__constructor(i0, i1);
    l8 = i0;
    i0 = p1;
    i1 = l5;
    i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
    l9 = i0;
    i0 = 0u;
    l10 = i0;
    L5: 
      i0 = l10;
      i1 = l9;
      l11 = i1;
      i1 = l11;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B4;}
      i0 = l9;
      i1 = l10;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 8));
      l11 = i0;
      i0 = l11;
      i1 = 0u;
      i0 = i0 != i1;
      l12 = i0;
      if (i0) {
        i0 = l11;
        i0 = i32_load((&memory), (u64)(i0 + 12));
        i1 = 360u;
        i0 = assembly_index_streq(i0, i1);
        l12 = i0;
        if (i0) {
          i0 = l12;
        } else {
          i0 = l11;
          i0 = i32_load((&memory), (u64)(i0 + 12));
          i1 = 552u;
          i0 = assembly_index_streq(i0, i1);
        }
      } else {
        i0 = l12;
      }
      if (i0) {
        i0 = l11;
        i0 = i32_load((&memory), (u64)(i0 + 8));
        l12 = i0;
        i0 = l6;
        i1 = l12;
        i0 = _lib_map_Map_i32_i32__has(i0, i1);
        i0 = !(i0);
        if (i0) {
          i0 = l6;
          i1 = l12;
          i2 = 0u;
          _lib_map_Map_i32_i32__set(i0, i1, i2);
          i0 = l8;
          i1 = l12;
          i0 = _lib_array_Array_i32__push(i0, i1);
        }
        i0 = l11;
        i0 = i32_load((&memory), (u64)(i0 + 12));
        i1 = 552u;
        i0 = assembly_index_streq(i0, i1);
        if (i0) {
          i0 = l7;
          i1 = l12;
          i0 = _lib_map_Map_i32_Array_Constraint___has(i0, i1);
          i0 = !(i0);
          if (i0) {
            i0 = l7;
            i1 = l12;
            i2 = 0u;
            i3 = 0u;
            i2 = _lib_array_Array_Constraint__constructor(i2, i3);
            _lib_map_Map_i32_Array_Constraint___set(i0, i1, i2);
          }
          i0 = l7;
          i1 = l12;
          i0 = _lib_map_Map_i32_Array_Constraint___get(i0, i1);
          i1 = l11;
          i0 = _lib_array_Array_Constraint__push(i0, i1);
        }
        i0 = l6;
        i1 = l12;
        i2 = l6;
        i3 = l12;
        i2 = _lib_map_Map_i32_i32__get(i2, i3);
        i3 = 1u;
        i2 += i3;
        _lib_map_Map_i32_i32__set(i0, i1, i2);
      }
      i0 = l10;
      i1 = 1u;
      i0 += i1;
      l10 = i0;
      goto L5;
    UNREACHABLE;
    B4:;
    i0 = 0u;
    l10 = i0;
    L15: 
      i0 = l10;
      i1 = l8;
      l11 = i1;
      i1 = l11;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B14;}
      i0 = l8;
      i1 = l10;
      i0 = _lib_array_Array_i32____get(i0, i1);
      l11 = i0;
      i0 = l7;
      i1 = l11;
      i0 = _lib_map_Map_i32_Array_Constraint___has(i0, i1);
      l12 = i0;
      if (i0) {
        i0 = l7;
        i1 = l11;
        i0 = _lib_map_Map_i32_Array_Constraint___get(i0, i1);
        l12 = i0;
        i0 = l12;
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i1 = 0u;
        i0 = (u32)((s32)i0 > (s32)i1);
      } else {
        i0 = l12;
      }
      l12 = i0;
      if (i0) {
        i0 = l6;
        i1 = l11;
        i0 = _lib_map_Map_i32_i32__get(i0, i1);
        i1 = 2u;
        i0 = i0 != i1;
      } else {
        i0 = l12;
      }
      if (i0) {
        i0 = l4;
        i1 = l7;
        i2 = l11;
        i1 = _lib_map_Map_i32_Array_Constraint___get(i1, i2);
        i0 = _lib_array_Array_Constraint__concat(i0, i1);
        l4 = i0;
      }
      i0 = l10;
      i1 = 1u;
      i0 += i1;
      l10 = i0;
      goto L15;
    UNREACHABLE;
    B14:;
    i0 = l5;
    i1 = 1u;
    i0 += i1;
    l5 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l4;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint3_checkHelper(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l4 = i0;
  i0 = l3;
  i1 = p1;
  i1 = i32_load((&memory), (u64)(i1));
  i0 += i1;
  l3 = i0;
  i0 = l4;
  i1 = p1;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  L1: 
    i0 = l5;
    i1 = p2;
    l6 = i1;
    i1 = l6;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = p2;
    i1 = l5;
    i0 = _lib_array_Array_PathMarker____get(i0, i1);
    i0 = i32_load((&memory), (u64)(i0));
    i1 = l3;
    i0 = i0 == i1;
    l6 = i0;
    if (i0) {
      i0 = p2;
      i1 = l5;
      i0 = _lib_array_Array_PathMarker____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i1 = l4;
      i0 = i0 == i1;
    } else {
      i0 = l6;
    }
    if (i0) {
      i0 = p2;
      i1 = l5;
      i0 = _lib_array_Array_PathMarker____get(i0, i1);
      goto Bfunc;
    }
    i0 = l5;
    i1 = 1u;
    i0 += i1;
    l5 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_Array_i32____constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_Array_i32____slice(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l3 = i0;
  i0 = p1;
  i1 = 0u;
  i0 = (u32)((s32)i0 < (s32)i1);
  if (i0) {
    i0 = p1;
    i1 = l3;
    i0 += i1;
    l4 = i0;
    i1 = 0u;
    l5 = i1;
    i2 = l4;
    i3 = l5;
    i2 = (u32)((s32)i2 > (s32)i3);
    i0 = i2 ? i0 : i1;
  } else {
    i0 = p1;
    l4 = i0;
    i1 = l3;
    l5 = i1;
    i2 = l4;
    i3 = l5;
    i2 = (u32)((s32)i2 < (s32)i3);
    i0 = i2 ? i0 : i1;
  }
  p1 = i0;
  i0 = p2;
  i1 = 0u;
  i0 = (u32)((s32)i0 < (s32)i1);
  if (i0) {
    i0 = p2;
    i1 = l3;
    i0 += i1;
    l4 = i0;
    i1 = 0u;
    l5 = i1;
    i2 = l4;
    i3 = l5;
    i2 = (u32)((s32)i2 > (s32)i3);
    i0 = i2 ? i0 : i1;
  } else {
    i0 = p2;
    l4 = i0;
    i1 = l3;
    l5 = i1;
    i2 = l4;
    i3 = l5;
    i2 = (u32)((s32)i2 < (s32)i3);
    i0 = i2 ? i0 : i1;
  }
  p2 = i0;
  i0 = p2;
  i1 = p1;
  i0 -= i1;
  l4 = i0;
  i1 = 0u;
  l5 = i1;
  i2 = l4;
  i3 = l5;
  i2 = (u32)((s32)i2 > (s32)i3);
  i0 = i2 ? i0 : i1;
  l3 = i0;
  i0 = 0u;
  i1 = l3;
  i0 = _lib_array_Array_Array_Array_i32____constructor(i0, i1);
  l6 = i0;
  i0 = l3;
  if (i0) {
    i0 = l6;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    l4 = i0;
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    i1 = p1;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    l5 = i0;
    i0 = l3;
    i1 = 2u;
    i0 <<= (i1 & 31);
    l7 = i0;
    i0 = l4;
    i1 = l5;
    i2 = l7;
    _lib_internal_memory_memmove(i0, i1, i2);
  }
  i0 = l6;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_Array_i32____slice_trampoline(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = g16;
  switch (i0) {
    case 0: goto B2;
    case 1: goto B1;
    case 2: goto B0;
    default: goto B3;
  }
  B3:;
  UNREACHABLE;
  B2:;
  i0 = 0u;
  p1 = i0;
  B1:;
  i0 = g17;
  p2 = i0;
  B0:;
  i0 = p0;
  i1 = p1;
  i2 = p2;
  i0 = _lib_array_Array_Array_Array_i32____slice(i0, i1, i2);
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_Array_i32____pop(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l1 = i0;
  i0 = l1;
  i1 = 1u;
  i0 = (u32)((s32)i0 < (s32)i1);
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 244u;
    i3 = 20u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = l1;
  i1 = 1u;
  i0 -= i1;
  l1 = i0;
  l3 = i0;
  i0 = 0u;
  l4 = i0;
  i0 = l2;
  i1 = l3;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l4;
  i0 += i1;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l5 = i0;
  i0 = p0;
  i1 = l1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint3_brute(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p2;
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = 1u;
    goto Bfunc;
  }
  i0 = 1u;
  g16 = i0;
  i0 = p2;
  i1 = 1u;
  i2 = 0u;
  i0 = _lib_array_Array_Array_Array_i32____slice_trampoline(i0, i1, i2);
  p2 = i0;
  i0 = 1u;
  g16 = i0;
  i0 = p1;
  i1 = copyPath;
  i0 = CALL_INDIRECT(table, u32 (*)(u32), 6, i1, i0);
  p1 = i0;
  i0 = p2;
  i0 = _lib_array_Array_Array_Array_i32____pop(i0);
  l3 = i0;
  i0 = l3;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = 0u;
  l4 = i0;
  L6: 
    i0 = l4;
    i1 = p1;
    l5 = i1;
    i1 = l5;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B5;}
    i0 = 3u;
    g16 = i0;
    i0 = p1;
    i1 = l3;
    i2 = p1;
    i3 = l4;
    i2 = _lib_array_Array_PathMarker____get(i2, i3);
    i3 = p0;
    i0 = CALL_INDIRECT(table, u32 (*)(u32, u32, u32), 10, i3, i0, i1, i2);
    l5 = i0;
    i0 = l5;
    i1 = 0u;
    i0 = i0 == i1;
    if (i0) {
      goto B7;
    }
    i0 = l5;
    l6 = i0;
    i0 = 0u;
    l7 = i0;
    L13: 
      i0 = l7;
      i1 = l6;
      l8 = i1;
      i1 = l8;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B12;}
      i0 = l6;
      i1 = l7;
      i0 = _lib_array_Array_PathMarker____get(i0, i1);
      i1 = 1u;
      i32_store8((&memory), (u64)(i0 + 8), i1);
      i0 = l7;
      i1 = 1u;
      i0 += i1;
      l7 = i0;
      goto L13;
    UNREACHABLE;
    B12:;
    i0 = p0;
    i1 = p1;
    i2 = p2;
    i0 = assembly_index_Constraint3_brute(i0, i1, i2);
    l7 = i0;
    i0 = 0u;
    l8 = i0;
    L17: 
      i0 = l8;
      i1 = l6;
      l9 = i1;
      i1 = l9;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B16;}
      i0 = l6;
      i1 = l8;
      i0 = _lib_array_Array_PathMarker____get(i0, i1);
      i1 = 0u;
      i32_store8((&memory), (u64)(i0 + 8), i1);
      i0 = l8;
      i1 = 1u;
      i0 += i1;
      l8 = i0;
      goto L17;
    UNREACHABLE;
    B16:;
    i0 = l7;
    i1 = 0u;
    i0 = i0 != i1;
    if (i0) {
      i0 = 1u;
      goto Bfunc;
    }
    B7:;
    i0 = l4;
    i1 = 1u;
    i0 += i1;
    l4 = i0;
    goto L6;
  UNREACHABLE;
  B5:;
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_i32_____get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = 2u;
  i1 >>= (i2 & 31);
  i0 = i0 < i1;
  if (i0) {
    i0 = l2;
    l3 = i0;
    i0 = p1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = l3;
    i1 = l4;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l5;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_CoordinatePair_constructor(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint3_check_anonymous_0(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_PathMarker__constructor(i0, i1);
  l3 = i0;
  i0 = 0u;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = 1u;
  l6 = i0;
  i0 = 0u;
  l7 = i0;
  L1: 
    i0 = l7;
    i1 = p1;
    l8 = i1;
    i1 = l8;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    l8 = i0;
    if (i0) {
      i0 = l6;
    } else {
      i0 = l8;
    }
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = 0u;
    l8 = i0;
    L5: 
      i0 = l8;
      i1 = p1;
      i2 = l7;
      i1 = _lib_array_Array_Array_i32_____get(i1, i2);
      l9 = i1;
      i1 = l9;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      l9 = i0;
      if (i0) {
        i0 = l6;
      } else {
        i0 = l9;
      }
      i0 = !(i0);
      if (i0) {goto B4;}
      i0 = p1;
      i1 = l7;
      i0 = _lib_array_Array_Array_i32_____get(i0, i1);
      i1 = l8;
      i0 = _lib_array_Array_i32____get(i0, i1);
      i1 = 0u;
      i0 = i0 != i1;
      if (i0) {
        i0 = l8;
        l4 = i0;
        i0 = l7;
        l5 = i0;
        i0 = 0u;
        l6 = i0;
      }
      i0 = l8;
      i1 = 1u;
      i0 += i1;
      l8 = i0;
      goto L5;
    UNREACHABLE;
    B4:;
    i0 = l7;
    i1 = 1u;
    i0 += i1;
    l7 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = 0u;
  l7 = i0;
  L10: 
    i0 = l7;
    i1 = p1;
    l8 = i1;
    i1 = l8;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B9;}
    i0 = 0u;
    l8 = i0;
    L13: 
      i0 = l8;
      i1 = p1;
      i2 = l7;
      i1 = _lib_array_Array_Array_i32_____get(i1, i2);
      l9 = i1;
      i1 = l9;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B12;}
      i0 = p1;
      i1 = l7;
      i0 = _lib_array_Array_Array_i32_____get(i0, i1);
      i1 = l8;
      i0 = _lib_array_Array_i32____get(i0, i1);
      i1 = 0u;
      i0 = i0 != i1;
      if (i0) {
        i0 = p2;
        i1 = 0u;
        i2 = l8;
        i3 = l4;
        i2 -= i3;
        i3 = l7;
        i4 = l5;
        i3 -= i4;
        i1 = assembly_index_CoordinatePair_constructor(i1, i2, i3);
        i2 = p0;
        i0 = assembly_index_Constraint3_checkHelper(i0, i1, i2);
        l9 = i0;
        i0 = l9;
        i1 = 0u;
        i0 = i0 == i1;
        l10 = i0;
        if (i0) {
          i0 = l10;
        } else {
          i0 = l9;
          i0 = i32_load8_u((&memory), (u64)(i0 + 8));
        }
        i1 = 0u;
        i0 = i0 != i1;
        if (i0) {
          i0 = 0u;
          goto Bfunc;
        }
        i0 = l3;
        i1 = l9;
        i0 = _lib_array_Array_PathMarker__push(i0, i1);
      }
      i0 = l8;
      i1 = 1u;
      i0 += i1;
      l8 = i0;
      goto L13;
    UNREACHABLE;
    B12:;
    i0 = l7;
    i1 = 1u;
    i0 += i1;
    l7 = i0;
    goto L10;
  UNREACHABLE;
  B9:;
  i0 = l3;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Constraint3__constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Constraint3__push(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l5 = i0;
  i0 = l2;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = l2;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 182u;
      i3 = 42u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = l5;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
  }
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  l6 = i0;
  i0 = l2;
  l7 = i0;
  i0 = p1;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l6;
  i1 = l7;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l9;
  i0 += i1;
  i1 = l8;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint3_check_anonymous_1(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = 0u;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = p0;
  i2 = i32_load((&memory), (u64)(i2 + 4));
  i3 = 0u;
  i4 = 0u;
  i0 = assembly_index_PathMarker_constructor(i0, i1, i2, i3, i4);
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_arrayMap_PartitionListElement_PathMarker_(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_PathMarker__constructor(i0, i1);
  l2 = i0;
  i0 = 0u;
  l3 = i0;
  L1: 
    i0 = l3;
    i1 = p0;
    l4 = i1;
    i1 = l4;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = l2;
    i1 = 1u;
    g16 = i1;
    i1 = p0;
    i2 = l3;
    i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
    i2 = p1;
    i1 = CALL_INDIRECT(table, u32 (*)(u32), 6, i2, i1);
    i0 = _lib_array_Array_PathMarker__push(i0, i1);
    i0 = l3;
    i1 = 1u;
    i0 += i1;
    l3 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l2;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint3_check_anonymous_2(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 20));
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Constraint3____get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = 2u;
  i1 >>= (i2 & 31);
  i0 = i0 < i1;
  if (i0) {
    i0 = l2;
    l3 = i0;
    i0 = p1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = l3;
    i1 = l4;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l5;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_Array_i32____push(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l5 = i0;
  i0 = l2;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = l2;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 182u;
      i3 = 42u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = l5;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
  }
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  l6 = i0;
  i0 = l2;
  l7 = i0;
  i0 = p1;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l6;
  i1 = l7;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l9;
  i0 += i1;
  i1 = l8;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_arrayMap_Constraint3_Array_Array_i32___(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Array_Array_i32____constructor(i0, i1);
  l2 = i0;
  i0 = 0u;
  l3 = i0;
  L1: 
    i0 = l3;
    i1 = p0;
    l4 = i1;
    i1 = l4;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = l2;
    i1 = 1u;
    g16 = i1;
    i1 = p0;
    i2 = l3;
    i1 = _lib_array_Array_Constraint3____get(i1, i2);
    i2 = p1;
    i1 = CALL_INDIRECT(table, u32 (*)(u32), 6, i2, i1);
    i0 = _lib_array_Array_Array_Array_i32____push(i0, i1);
    i0 = l3;
    i1 = 1u;
    i0 += i1;
    l3 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l2;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint3_check_anonymous_3(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = 0u;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = p0;
  i2 = i32_load((&memory), (u64)(i2 + 4));
  i3 = 0u;
  i4 = 0u;
  i0 = assembly_index_PathMarker_constructor(i0, i1, i2, i3, i4);
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint3_check_anonymous_4(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 20));
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint3_check(u32 p0, u32 p1, u32 p2, u32 p3) {
  u32 l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0, l11 = 0, 
      l12 = 0, l13 = 0, l14 = 0, l15 = 0, l16 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = 4u;
  l4 = i0;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l5 = i0;
  i0 = 0u;
  l6 = i0;
  L1: 
    i0 = l6;
    i1 = p1;
    l7 = i1;
    i1 = l7;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = p1;
    i1 = l6;
    i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
    l7 = i0;
    i0 = 0u;
    i1 = 0u;
    i0 = _lib_array_Array_Constraint3__constructor(i0, i1);
    l8 = i0;
    i0 = 0u;
    l9 = i0;
    i0 = 0u;
    l10 = i0;
    L5: 
      i0 = l10;
      i1 = l7;
      l11 = i1;
      i1 = l11;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B4;}
      i0 = l7;
      i1 = l10;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 8));
      l11 = i0;
      i0 = l11;
      i1 = 0u;
      i0 = i0 != i1;
      l12 = i0;
      if (i0) {
        i0 = 0u;
      } else {
        i0 = l12;
      }
      if (i0) {
        i0 = l11;
        l12 = i0;
        i0 = l8;
        i1 = l12;
        i0 = _lib_array_Array_Constraint3__push(i0, i1);
        i0 = l12;
        i0 = i32_load((&memory), (u64)(i0 + 20));
        l13 = i0;
        i0 = 0u;
        l14 = i0;
        L11: 
          i0 = l14;
          i1 = l13;
          l15 = i1;
          i1 = l15;
          i1 = i32_load((&memory), (u64)(i1 + 4));
          i0 = (u32)((s32)i0 < (s32)i1);
          i0 = !(i0);
          if (i0) {goto B10;}
          i0 = 0u;
          l15 = i0;
          L14: 
            i0 = l15;
            i1 = l13;
            i2 = l14;
            i1 = _lib_array_Array_Array_i32_____get(i1, i2);
            l16 = i1;
            i1 = l16;
            i1 = i32_load((&memory), (u64)(i1 + 4));
            i0 = (u32)((s32)i0 < (s32)i1);
            i0 = !(i0);
            if (i0) {goto B13;}
            i0 = l13;
            i1 = l14;
            i0 = _lib_array_Array_Array_i32_____get(i0, i1);
            i1 = l15;
            i0 = _lib_array_Array_i32____get(i0, i1);
            if (i0) {
              i0 = l9;
              i1 = 1u;
              i0 += i1;
              l9 = i0;
            }
            i0 = l15;
            i1 = 1u;
            i0 += i1;
            l15 = i0;
            goto L14;
          UNREACHABLE;
          B13:;
          i0 = l14;
          i1 = 1u;
          i0 += i1;
          l14 = i0;
          goto L11;
        UNREACHABLE;
        B10:;
      }
      i0 = l10;
      i1 = 1u;
      i0 += i1;
      l10 = i0;
      goto L5;
    UNREACHABLE;
    B4:;
    i0 = l9;
    i1 = 0u;
    i0 = i0 != i1;
    l10 = i0;
    if (i0) {
      i0 = l9;
      i1 = l7;
      l10 = i1;
      i1 = l10;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = i0 != i1;
      l10 = i0;
      if (i0) {
        i0 = l10;
      } else {
        i0 = l4;
        i1 = l7;
        i2 = 7u;
        i1 = assembly_index_arrayMap_PartitionListElement_PathMarker_(i1, i2);
        i2 = l8;
        i3 = 8u;
        i2 = assembly_index_arrayMap_Constraint3_Array_Array_i32___(i2, i3);
        i0 = assembly_index_Constraint3_brute(i0, i1, i2);
        i0 = !(i0);
      }
    } else {
      i0 = l10;
    }
    if (i0) {
      i0 = l5;
      i1 = l8;
      i0 = _lib_array_Array_Constraint__concat(i0, i1);
      l5 = i0;
    }
    i0 = l6;
    i1 = 1u;
    i0 += i1;
    l6 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l6 = i0;
  i0 = l6;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_CoordinatePair__constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_array_Array_CoordinatePair____unchecked_set(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = p1;
  l4 = i0;
  i0 = p2;
  l5 = i0;
  i0 = 0u;
  l6 = i0;
  i0 = l3;
  i1 = l4;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l6;
  i0 += i1;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 _lib_array_Array_Array_PathMarker___constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_array_Array_Array_PathMarker_____set(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = p1;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = p1;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 107u;
      i3 = 41u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = p1;
    i2 = 1u;
    i1 += i2;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
    i0 = p0;
    i1 = p1;
    i2 = 1u;
    i1 += i2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  }
  i0 = l3;
  l5 = i0;
  i0 = p1;
  l6 = i0;
  i0 = p2;
  l7 = i0;
  i0 = 0u;
  l8 = i0;
  i0 = l5;
  i1 = l6;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l8;
  i0 += i1;
  i1 = l7;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 _lib_array_Array_Array_PathMarker___concat(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = 0u;
  i1 = p1;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i2 = p1;
  i3 = 0u;
  i2 = i2 == i3;
  i0 = i2 ? i0 : i1;
  l3 = i0;
  i0 = l2;
  i1 = l3;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  i1 = l4;
  i0 = _lib_array_Array_Array_PathMarker___constructor(i0, i1);
  l5 = i0;
  i0 = l2;
  if (i0) {
    i0 = l5;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    l6 = i0;
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    l7 = i0;
    i0 = l2;
    i1 = 2u;
    i0 <<= (i1 & 31);
    l8 = i0;
    i0 = l6;
    i1 = l7;
    i2 = l8;
    _lib_internal_memory_memmove(i0, i1, i2);
  }
  i0 = l3;
  if (i0) {
    i0 = l5;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    i1 = l2;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    l8 = i0;
    i0 = p1;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    l7 = i0;
    i0 = l3;
    i1 = 2u;
    i0 <<= (i1 & 31);
    l6 = i0;
    i0 = l8;
    i1 = l7;
    i2 = l6;
    _lib_internal_memory_memmove(i0, i1, i2);
  }
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_array_Array_PathMarker____set(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = p1;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = p1;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 107u;
      i3 = 41u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = p1;
    i2 = 1u;
    i1 += i2;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
    i0 = p0;
    i1 = p1;
    i2 = 1u;
    i1 += i2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  }
  i0 = l3;
  l5 = i0;
  i0 = p1;
  l6 = i0;
  i0 = p2;
  l7 = i0;
  i0 = 0u;
  l8 = i0;
  i0 = l5;
  i1 = l6;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l8;
  i0 += i1;
  i1 = l7;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 _lib_array_Array_PathMarker__pop(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l1 = i0;
  i0 = l1;
  i1 = 1u;
  i0 = (u32)((s32)i0 < (s32)i1);
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 244u;
    i3 = 20u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = l1;
  i1 = 1u;
  i0 -= i1;
  l1 = i0;
  l3 = i0;
  i0 = 0u;
  l4 = i0;
  i0 = l2;
  i1 = l3;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l4;
  i0 += i1;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l5 = i0;
  i0 = p0;
  i1 = l1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_CoordinatePair____get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = 2u;
  i1 >>= (i2 & 31);
  i0 = i0 < i1;
  if (i0) {
    i0 = l2;
    l3 = i0;
    i0 = p1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = l3;
    i1 = l4;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l5;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_PathMarker__concat(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = 0u;
  i1 = p1;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i2 = p1;
  i3 = 0u;
  i2 = i2 == i3;
  i0 = i2 ? i0 : i1;
  l3 = i0;
  i0 = l2;
  i1 = l3;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  i1 = l4;
  i0 = _lib_array_Array_PathMarker__constructor(i0, i1);
  l5 = i0;
  i0 = l2;
  if (i0) {
    i0 = l5;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    l6 = i0;
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    l7 = i0;
    i0 = l2;
    i1 = 2u;
    i0 <<= (i1 & 31);
    l8 = i0;
    i0 = l6;
    i1 = l7;
    i2 = l8;
    _lib_internal_memory_memmove(i0, i1, i2);
  }
  i0 = l3;
  if (i0) {
    i0 = l5;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    i1 = l2;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    l8 = i0;
    i0 = p1;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = 8u;
    i0 += i1;
    l7 = i0;
    i0 = l3;
    i1 = 2u;
    i0 <<= (i1 & 31);
    l6 = i0;
    i0 = l8;
    i1 = l7;
    i2 = l6;
    _lib_internal_memory_memmove(i0, i1, i2);
  }
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint3_formShape(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4, u32 p5) {
  u32 l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0, l11 = 0, l12 = 0, l13 = 0, 
      l14 = 0, l15 = 0, l16 = 0;
  f64 l17 = 0, l18 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5, i6;
  f64 d4, d5;
  i0 = 0u;
  i1 = 4u;
  i0 = _lib_array_Array_CoordinatePair__constructor(i0, i1);
  l6 = i0;
  i0 = l6;
  i1 = 0u;
  i2 = 0u;
  i3 = 1u;
  i4 = 0u;
  i2 = assembly_index_CoordinatePair_constructor(i2, i3, i4);
  _lib_array_Array_CoordinatePair____unchecked_set(i0, i1, i2);
  i0 = l6;
  i1 = 1u;
  i2 = 0u;
  i3 = 0u;
  i4 = 1u;
  i2 = assembly_index_CoordinatePair_constructor(i2, i3, i4);
  _lib_array_Array_CoordinatePair____unchecked_set(i0, i1, i2);
  i0 = l6;
  i1 = 2u;
  i2 = 0u;
  i3 = 4294967295u;
  i4 = 0u;
  i2 = assembly_index_CoordinatePair_constructor(i2, i3, i4);
  _lib_array_Array_CoordinatePair____unchecked_set(i0, i1, i2);
  i0 = l6;
  i1 = 3u;
  i2 = 0u;
  i3 = 0u;
  i4 = 4294967295u;
  i2 = assembly_index_CoordinatePair_constructor(i2, i3, i4);
  _lib_array_Array_CoordinatePair____unchecked_set(i0, i1, i2);
  i0 = l6;
  l6 = i0;
  i0 = 1u;
  g16 = i0;
  i0 = p3;
  i1 = copyPath;
  i0 = CALL_INDIRECT(table, u32 (*)(u32), 6, i1, i0);
  l7 = i0;
  i0 = p5;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = 0u;
    i1 = 1u;
    i0 = _lib_array_Array_Array_PathMarker___constructor(i0, i1);
    l8 = i0;
    i0 = l8;
    i1 = 0u;
    i2 = l7;
    _lib_array_Array_Array_PathMarker_____set(i0, i1, i2);
    i0 = p2;
    i1 = l8;
    i0 = _lib_array_Array_Array_PathMarker___concat(i0, i1);
    goto Bfunc;
  }
  i0 = p4;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = 0u;
    l8 = i0;
    L5: 
      i0 = l8;
      i1 = p1;
      l9 = i1;
      i1 = l9;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B4;}
      i0 = 0u;
      i1 = 1u;
      i0 = _lib_array_Array_PathMarker__constructor(i0, i1);
      l9 = i0;
      i0 = l9;
      i1 = 0u;
      i2 = p1;
      i3 = l8;
      i2 = _lib_array_Array_PathMarker____get(i2, i3);
      _lib_array_Array_PathMarker____set(i0, i1, i2);
      i0 = 0u;
      i1 = 1u;
      i0 = _lib_array_Array_Array_PathMarker___constructor(i0, i1);
      l10 = i0;
      i0 = l10;
      i1 = 0u;
      i2 = l7;
      _lib_array_Array_Array_PathMarker_____set(i0, i1, i2);
      i0 = p0;
      i1 = l9;
      i2 = p2;
      i3 = l10;
      i2 = _lib_array_Array_Array_PathMarker___concat(i2, i3);
      i3 = 0u;
      i4 = 0u;
      i3 = _lib_array_Array_PathMarker__constructor(i3, i4);
      d4 = 4;
      l17 = d4;
      i4 = p5;
      d4 = (f64)(s32)(i4);
      l18 = d4;
      d4 = l17;
      d5 = l18;
      d4 = FMIN(d4, d5);
      i4 = I32_TRUNC_S_F64(d4);
      i5 = p5;
      i0 = assembly_index_Constraint3_formShape(i0, i1, i2, i3, i4, i5);
      l11 = i0;
      i0 = l11;
      i1 = 0u;
      i0 = i0 != i1;
      if (i0) {
        i0 = l11;
        goto Bfunc;
      }
      i0 = l8;
      i1 = 1u;
      i0 += i1;
      l8 = i0;
      goto L5;
    UNREACHABLE;
    B4:;
    i0 = 0u;
    goto Bfunc;
  }
  i0 = 1u;
  g16 = i0;
  i0 = p1;
  i1 = copyPath;
  i0 = CALL_INDIRECT(table, u32 (*)(u32), 6, i1, i0);
  p1 = i0;
  i0 = 1u;
  g16 = i0;
  i0 = p0;
  i1 = copyPath;
  i0 = CALL_INDIRECT(table, u32 (*)(u32), 6, i1, i0);
  l8 = i0;
  L13: 
    i0 = p1;
    l11 = i0;
    i0 = l11;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = 0u;
    i0 = (u32)((s32)i0 > (s32)i1);
    if (i0) {
      i0 = p1;
      i0 = _lib_array_Array_PathMarker__pop(i0);
      l11 = i0;
      i0 = l11;
      i1 = 0u;
      i2 = 0u;
      i3 = 0u;
      i1 = assembly_index_CoordinatePair_constructor(i1, i2, i3);
      i2 = l8;
      i0 = assembly_index_Constraint3_checkHelper(i0, i1, i2);
      l10 = i0;
      i0 = l10;
      i1 = 0u;
      i0 = i0 == i1;
      l9 = i0;
      if (i0) {
        i0 = l9;
      } else {
        i0 = l10;
        i0 = i32_load8_u((&memory), (u64)(i0 + 8));
      }
      i1 = 0u;
      i0 = i0 != i1;
      if (i0) {
        goto L13;
      }
      i0 = l10;
      i1 = 1u;
      i32_store8((&memory), (u64)(i0 + 8), i1);
      i0 = l10;
      i1 = 1u;
      i32_store8((&memory), (u64)(i0 + 9), i1);
      i0 = 0u;
      i1 = 0u;
      i0 = _lib_array_Array_PathMarker__constructor(i0, i1);
      l9 = i0;
      i0 = 1u;
      g16 = i0;
      i0 = 4u;
      i1 = genShuff;
      i0 = CALL_INDIRECT(table, u32 (*)(u32), 6, i1, i0);
      l12 = i0;
      i0 = 0u;
      l13 = i0;
      L21: 
        i0 = l13;
        i1 = l12;
        l14 = i1;
        i1 = l14;
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i0 = (u32)((s32)i0 < (s32)i1);
        i0 = !(i0);
        if (i0) {goto B20;}
        i0 = l12;
        i1 = l13;
        i0 = _lib_array_Array_i32____get(i0, i1);
        l14 = i0;
        i0 = l11;
        i1 = l6;
        i2 = l14;
        i1 = _lib_array_Array_CoordinatePair____get(i1, i2);
        i2 = l8;
        i0 = assembly_index_Constraint3_checkHelper(i0, i1, i2);
        l15 = i0;
        i0 = l15;
        i1 = 0u;
        i0 = i0 != i1;
        l16 = i0;
        if (i0) {
          i0 = l15;
          i0 = i32_load8_u((&memory), (u64)(i0 + 9));
          i1 = 0u;
          i0 = i0 != i1;
          i0 = !(i0);
        } else {
          i0 = l16;
        }
        l16 = i0;
        if (i0) {
          i0 = l15;
          i0 = i32_load8_u((&memory), (u64)(i0 + 8));
          i1 = 0u;
          i0 = i0 != i1;
          i0 = !(i0);
        } else {
          i0 = l16;
        }
        if (i0) {
          i0 = l9;
          i1 = l15;
          i0 = _lib_array_Array_PathMarker__push(i0, i1);
        }
        i0 = l13;
        i1 = 1u;
        i0 += i1;
        l13 = i0;
        goto L21;
      UNREACHABLE;
      B20:;
      i0 = 0u;
      i1 = 1u;
      i0 = _lib_array_Array_PathMarker__constructor(i0, i1);
      l13 = i0;
      i0 = l13;
      i1 = 0u;
      i2 = l10;
      _lib_array_Array_PathMarker____set(i0, i1, i2);
      i0 = l8;
      i1 = p1;
      i2 = l9;
      i1 = _lib_array_Array_PathMarker__concat(i1, i2);
      i2 = p2;
      i3 = l7;
      i4 = l13;
      i3 = _lib_array_Array_PathMarker__concat(i3, i4);
      i4 = p4;
      i5 = 1u;
      i4 -= i5;
      i5 = p5;
      i6 = 1u;
      i5 -= i6;
      i0 = assembly_index_Constraint3_formShape(i0, i1, i2, i3, i4, i5);
      l15 = i0;
      i0 = l10;
      i1 = 0u;
      i32_store8((&memory), (u64)(i0 + 8), i1);
      i0 = l15;
      if (i0) {
        i0 = l15;
        goto Bfunc;
      }
      goto L13;
    }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_PathMarker_____get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = 2u;
  i1 >>= (i2 & 31);
  i0 = i0 < i1;
  if (i0) {
    i0 = l2;
    l3 = i0;
    i0 = p1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = l3;
    i1 = l4;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l5;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_i32___constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_array_Array_Array_i32_____set(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = p1;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = p1;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 107u;
      i3 = 41u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = p1;
    i2 = 1u;
    i1 += i2;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
    i0 = p0;
    i1 = p1;
    i2 = 1u;
    i1 += i2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  }
  i0 = l3;
  l5 = i0;
  i0 = p1;
  l6 = i0;
  i0 = p2;
  l7 = i0;
  i0 = 0u;
  l8 = i0;
  i0 = l5;
  i1 = l6;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l8;
  i0 += i1;
  i1 = l7;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 assembly_index_Constraint3_gen_anonymous_0(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, 
      l9 = 0, l10 = 0, l11 = 0;
  f64 l12 = 0, l13 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  f64 d4, d5;
  i0 = 0u;
  l1 = i0;
  i0 = 0u;
  l2 = i0;
  L1: 
    i0 = l2;
    i1 = p0;
    l3 = i1;
    i1 = l3;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = 0u;
    i1 = 0u;
    i0 = _lib_array_Array_PathMarker__constructor(i0, i1);
    l3 = i0;
    i0 = l3;
    i1 = p0;
    i2 = l2;
    i1 = _lib_array_Array_PathMarker____get(i1, i2);
    i0 = _lib_array_Array_PathMarker__push(i0, i1);
    i0 = p0;
    i1 = l3;
    i2 = 0u;
    i3 = 0u;
    i2 = _lib_array_Array_Array_PathMarker___constructor(i2, i3);
    i3 = 0u;
    i4 = 0u;
    i3 = _lib_array_Array_PathMarker__constructor(i3, i4);
    d4 = 4;
    l12 = d4;
    i4 = p0;
    l4 = i4;
    i4 = l4;
    i4 = i32_load((&memory), (u64)(i4 + 4));
    d4 = (f64)(s32)(i4);
    l13 = d4;
    d4 = l12;
    d5 = l13;
    d4 = FMIN(d4, d5);
    i4 = I32_TRUNC_S_F64(d4);
    i5 = p0;
    l4 = i5;
    i5 = l4;
    i5 = i32_load((&memory), (u64)(i5 + 4));
    i0 = assembly_index_Constraint3_formShape(i0, i1, i2, i3, i4, i5);
    l1 = i0;
    i0 = l1;
    i1 = 0u;
    i0 = i0 != i1;
    if (i0) {
      goto B0;
    }
    i0 = l2;
    i1 = 1u;
    i0 += i1;
    l2 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l1;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  } else {
  }
  i0 = l1;
  l2 = i0;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Array_Array_i32____constructor(i0, i1);
  l3 = i0;
  i0 = 0u;
  l4 = i0;
  L10: 
    i0 = l4;
    i1 = l2;
    l5 = i1;
    i1 = l5;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B9;}
    i0 = 0u;
    l5 = i0;
    i0 = 10000u;
    l6 = i0;
    i0 = 0u;
    l7 = i0;
    i0 = 10000u;
    l8 = i0;
    i0 = 0u;
    l9 = i0;
    L14: 
      i0 = l9;
      i1 = l2;
      i2 = l4;
      i1 = _lib_array_Array_Array_PathMarker_____get(i1, i2);
      l10 = i1;
      i1 = l10;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B13;}
      i0 = l2;
      i1 = l4;
      i0 = _lib_array_Array_Array_PathMarker_____get(i0, i1);
      i1 = l9;
      i0 = _lib_array_Array_PathMarker____get(i0, i1);
      l10 = i0;
      i0 = l10;
      i0 = i32_load((&memory), (u64)(i0));
      i1 = l5;
      i0 = (u32)((s32)i0 > (s32)i1);
      if (i0) {
        i0 = l10;
        i0 = i32_load((&memory), (u64)(i0));
        l5 = i0;
      }
      i0 = l10;
      i0 = i32_load((&memory), (u64)(i0));
      i1 = l6;
      i0 = (u32)((s32)i0 < (s32)i1);
      if (i0) {
        i0 = l10;
        i0 = i32_load((&memory), (u64)(i0));
        l6 = i0;
      }
      i0 = l10;
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i1 = l7;
      i0 = (u32)((s32)i0 > (s32)i1);
      if (i0) {
        i0 = l10;
        i0 = i32_load((&memory), (u64)(i0 + 4));
        l7 = i0;
      }
      i0 = l10;
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i1 = l8;
      i0 = (u32)((s32)i0 < (s32)i1);
      if (i0) {
        i0 = l10;
        i0 = i32_load((&memory), (u64)(i0 + 4));
        l8 = i0;
      }
      i0 = l9;
      i1 = 1u;
      i0 += i1;
      l9 = i0;
      goto L14;
    UNREACHABLE;
    B13:;
    i0 = 0u;
    i1 = 0u;
    i0 = _lib_array_Array_Array_i32___constructor(i0, i1);
    l9 = i0;
    i0 = 0u;
    l10 = i0;
    L22: 
      i0 = l10;
      i1 = l7;
      i2 = l8;
      i1 -= i2;
      i2 = 1u;
      i1 += i2;
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B21;}
      i0 = l9;
      i1 = l10;
      i2 = 0u;
      i3 = 0u;
      i2 = _lib_array_Array_i32__constructor(i2, i3);
      _lib_array_Array_Array_i32_____set(i0, i1, i2);
      i0 = 0u;
      l11 = i0;
      L25: 
        i0 = l11;
        i1 = l5;
        i2 = l6;
        i1 -= i2;
        i2 = 1u;
        i1 += i2;
        i0 = (u32)((s32)i0 < (s32)i1);
        i0 = !(i0);
        if (i0) {goto B24;}
        i0 = l9;
        i1 = l10;
        i0 = _lib_array_Array_Array_i32_____get(i0, i1);
        i1 = l11;
        i2 = 0u;
        _lib_array_Array_i32____set(i0, i1, i2);
        i0 = l11;
        i1 = 1u;
        i0 += i1;
        l11 = i0;
        goto L25;
      UNREACHABLE;
      B24:;
      i0 = l10;
      i1 = 1u;
      i0 += i1;
      l10 = i0;
      goto L22;
    UNREACHABLE;
    B21:;
    i0 = 0u;
    l10 = i0;
    L27: 
      i0 = l10;
      i1 = l2;
      i2 = l4;
      i1 = _lib_array_Array_Array_PathMarker_____get(i1, i2);
      l11 = i1;
      i1 = l11;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B26;}
      i0 = l9;
      i1 = l2;
      i2 = l4;
      i1 = _lib_array_Array_Array_PathMarker_____get(i1, i2);
      i2 = l10;
      i1 = _lib_array_Array_PathMarker____get(i1, i2);
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i2 = l8;
      i1 -= i2;
      i0 = _lib_array_Array_Array_i32_____get(i0, i1);
      i1 = l2;
      i2 = l4;
      i1 = _lib_array_Array_Array_PathMarker_____get(i1, i2);
      i2 = l10;
      i1 = _lib_array_Array_PathMarker____get(i1, i2);
      i1 = i32_load((&memory), (u64)(i1));
      i2 = l6;
      i1 -= i2;
      i2 = 1u;
      _lib_array_Array_i32____set(i0, i1, i2);
      i0 = l10;
      i1 = 1u;
      i0 += i1;
      l10 = i0;
      goto L27;
    UNREACHABLE;
    B26:;
    i0 = l3;
    i1 = l9;
    i0 = _lib_array_Array_Array_Array_i32____push(i0, i1);
    i0 = l4;
    i1 = 1u;
    i0 += i1;
    l4 = i0;
    goto L10;
  UNREACHABLE;
  B9:;
  i0 = l3;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint3_gen_anonymous_1(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = 0u;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = p0;
  i2 = i32_load((&memory), (u64)(i2 + 4));
  i3 = 0u;
  i4 = 0u;
  i0 = assembly_index_PathMarker_constructor(i0, i1, i2, i3, i4);
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_Array_i32______get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = 2u;
  i1 >>= (i2 & 31);
  i0 = i0 < i1;
  if (i0) {
    i0 = l2;
    l3 = i0;
    i0 = p1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = l3;
    i1 = l4;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l5;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_internal_number_decimalCount32(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i1 = 100000u;
  i0 = i0 < i1;
  if (i0) {
    i0 = p0;
    i1 = 100u;
    i0 = i0 < i1;
    if (i0) {
      i0 = 1u;
      i1 = 2u;
      i2 = p0;
      i3 = 10u;
      i2 = i2 < i3;
      i0 = i2 ? i0 : i1;
      goto Bfunc;
    } else {
      i0 = 4u;
      i1 = 5u;
      i2 = p0;
      i3 = 10000u;
      i2 = i2 < i3;
      i0 = i2 ? i0 : i1;
      l1 = i0;
      i0 = 3u;
      i1 = l1;
      i2 = p0;
      i3 = 1000u;
      i2 = i2 < i3;
      i0 = i2 ? i0 : i1;
      goto Bfunc;
    }
    UNREACHABLE;
  } else {
    i0 = p0;
    i1 = 10000000u;
    i0 = i0 < i1;
    if (i0) {
      i0 = 6u;
      i1 = 7u;
      i2 = p0;
      i3 = 1000000u;
      i2 = i2 < i3;
      i0 = i2 ? i0 : i1;
      goto Bfunc;
    } else {
      i0 = 9u;
      i1 = 10u;
      i2 = p0;
      i3 = 1000000000u;
      i2 = i2 < i3;
      i0 = i2 ? i0 : i1;
      l1 = i0;
      i0 = 8u;
      i1 = l1;
      i2 = p0;
      i3 = 100000000u;
      i2 = i2 < i3;
      i0 = i2 ? i0 : i1;
      goto Bfunc;
    }
    UNREACHABLE;
  }
  UNREACHABLE;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_internal_string_allocateUnsafe(u32 p0) {
  u32 l1 = 0, l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i1 = 0u;
  i0 = (u32)((s32)i0 > (s32)i1);
  l1 = i0;
  if (i0) {
    i0 = p0;
    i1 = 536870910u;
    i0 = (u32)((s32)i0 <= (s32)i1);
  } else {
    i0 = l1;
  }
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 600u;
    i2 = 14u;
    i3 = 2u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = 4u;
  i1 = p0;
  i2 = 1u;
  i1 <<= (i2 & 31);
  i0 += i1;
  l1 = i0;
  i0 = l1;
  i0 = _lib_allocator_arena___memory_allocate(i0);
  goto B2;
  B2:;
  l2 = i0;
  i0 = l2;
  i1 = p0;
  i32_store((&memory), (u64)(i0), i1);
  i0 = l2;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_internal_number_utoa32_lut(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0;
  u64 l11 = 0, l12 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  u64 j0, j1, j2, j3;
  i0 = 1168u;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  L1: 
    i0 = p1;
    i1 = 10000u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = p1;
      i1 = 10000u;
      i0 = DIV_U(i0, i1);
      l4 = i0;
      i0 = p1;
      i1 = 10000u;
      i0 = REM_U(i0, i1);
      l5 = i0;
      i0 = l4;
      p1 = i0;
      i0 = l5;
      i1 = 100u;
      i0 = DIV_U(i0, i1);
      l6 = i0;
      i0 = l5;
      i1 = 100u;
      i0 = REM_U(i0, i1);
      l7 = i0;
      i0 = l3;
      l8 = i0;
      i0 = l6;
      l9 = i0;
      i0 = 0u;
      l10 = i0;
      i0 = l8;
      i1 = l9;
      i2 = 2u;
      i1 <<= (i2 & 31);
      i0 += i1;
      i1 = l10;
      i0 += i1;
      j0 = i64_load32_u((&memory), (u64)(i0 + 8));
      l11 = j0;
      i0 = l3;
      l10 = i0;
      i0 = l7;
      l9 = i0;
      i0 = 0u;
      l8 = i0;
      i0 = l10;
      i1 = l9;
      i2 = 2u;
      i1 <<= (i2 & 31);
      i0 += i1;
      i1 = l8;
      i0 += i1;
      j0 = i64_load32_u((&memory), (u64)(i0 + 8));
      l12 = j0;
      i0 = p2;
      i1 = 4u;
      i0 -= i1;
      p2 = i0;
      i0 = p0;
      i1 = p2;
      i2 = 1u;
      i1 <<= (i2 & 31);
      i0 += i1;
      j1 = l11;
      j2 = l12;
      j3 = 32ull;
      j2 <<= (j3 & 63);
      j1 |= j2;
      i64_store((&memory), (u64)(i0 + 4), j1);
      goto L1;
    }
  i0 = p1;
  i1 = 100u;
  i0 = i0 >= i1;
  if (i0) {
    i0 = p1;
    i1 = 100u;
    i0 = DIV_U(i0, i1);
    l7 = i0;
    i0 = p1;
    i1 = 100u;
    i0 = REM_U(i0, i1);
    l6 = i0;
    i0 = l7;
    p1 = i0;
    i0 = p2;
    i1 = 2u;
    i0 -= i1;
    p2 = i0;
    i0 = l3;
    l5 = i0;
    i0 = l6;
    l4 = i0;
    i0 = 0u;
    l8 = i0;
    i0 = l5;
    i1 = l4;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l8;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
    l8 = i0;
    i0 = p0;
    i1 = p2;
    i2 = 1u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l8;
    i32_store((&memory), (u64)(i0 + 4), i1);
  }
  i0 = p1;
  i1 = 10u;
  i0 = i0 >= i1;
  if (i0) {
    i0 = p2;
    i1 = 2u;
    i0 -= i1;
    p2 = i0;
    i0 = l3;
    l8 = i0;
    i0 = p1;
    l6 = i0;
    i0 = 0u;
    l7 = i0;
    i0 = l8;
    i1 = l6;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l7;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
    l7 = i0;
    i0 = p0;
    i1 = p2;
    i2 = 1u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l7;
    i32_store((&memory), (u64)(i0 + 4), i1);
  } else {
    i0 = p2;
    i1 = 1u;
    i0 -= i1;
    p2 = i0;
    i0 = 48u;
    i1 = p1;
    i0 += i1;
    l7 = i0;
    i0 = p0;
    i1 = p2;
    i2 = 1u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l7;
    i32_store16((&memory), (u64)(i0 + 4), i1);
  }
  FUNC_EPILOGUE;
}

static u32 _lib_internal_number_itoa32(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 56u;
    goto Bfunc;
  }
  i0 = p0;
  i1 = 0u;
  i0 = (u32)((s32)i0 < (s32)i1);
  l1 = i0;
  i0 = l1;
  if (i0) {
    i0 = 0u;
    i1 = p0;
    i0 -= i1;
    p0 = i0;
  }
  i0 = p0;
  i0 = _lib_internal_number_decimalCount32(i0);
  i1 = l1;
  i0 += i1;
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_string_allocateUnsafe(i0);
  l3 = i0;
  i0 = l3;
  l4 = i0;
  i0 = p0;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_number_utoa32_lut(i0, i1, i2);
  i0 = l1;
  if (i0) {
    i0 = l3;
    i1 = 45u;
    i32_store16((&memory), (u64)(i0 + 4), i1);
  }
  i0 = l3;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_internal_number_itoa_i32_(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = _lib_internal_number_itoa32(i0);
  goto Bfunc;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_number_I32_toString(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = _lib_internal_number_itoa_i32_(i0);
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_bool____get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1));
  i2 = 0u;
  i1 >>= (i2 & 31);
  i0 = i0 < i1;
  if (i0) {
    i0 = l2;
    l3 = i0;
    i0 = p1;
    l4 = i0;
    i0 = 0u;
    l5 = i0;
    i0 = l3;
    i1 = l4;
    i2 = 0u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l5;
    i0 += i1;
    i0 = i32_load8_u((&memory), (u64)(i0 + 8));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_String__push(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l5 = i0;
  i0 = l2;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = l2;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 182u;
      i3 = 42u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = l5;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
  }
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  l6 = i0;
  i0 = l2;
  l7 = i0;
  i0 = p1;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l6;
  i1 = l7;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l9;
  i0 += i1;
  i1 = l8;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = p1;
  i0 = _lib_array_Array_String__push(i0, i1);
  FUNC_EPILOGUE;
}

static void _lib_array_Array_bool____set(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 0u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = p1;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = p1;
    i1 = 1073741816u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 107u;
      i3 = 41u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = p1;
    i2 = 1u;
    i1 += i2;
    i2 = 0u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
    i0 = p0;
    i1 = p1;
    i2 = 1u;
    i1 += i2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  }
  i0 = l3;
  l5 = i0;
  i0 = p1;
  l6 = i0;
  i0 = p2;
  l7 = i0;
  i0 = 0u;
  l8 = i0;
  i0 = l5;
  i1 = l6;
  i2 = 0u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l8;
  i0 += i1;
  i1 = l7;
  i32_store8((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 _lib_internal_string_compareUnsafe(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4) {
  u32 l5 = 0, l6 = 0, l7 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 0u;
  l5 = i0;
  i0 = p0;
  i1 = p1;
  i2 = 1u;
  i1 <<= (i2 & 31);
  i0 += i1;
  l6 = i0;
  i0 = p2;
  i1 = p3;
  i2 = 1u;
  i1 <<= (i2 & 31);
  i0 += i1;
  l7 = i0;
  L1: 
    i0 = p4;
    if (i0) {
      i0 = l6;
      i0 = i32_load16_u((&memory), (u64)(i0 + 4));
      i1 = l7;
      i1 = i32_load16_u((&memory), (u64)(i1 + 4));
      i0 -= i1;
      l5 = i0;
      i0 = !(i0);
    } else {
      i0 = p4;
    }
    if (i0) {
      i0 = p4;
      i1 = 1u;
      i0 -= i1;
      p4 = i0;
      i0 = l6;
      i1 = 2u;
      i0 += i1;
      l6 = i0;
      i0 = l7;
      i1 = 2u;
      i0 += i1;
      l7 = i0;
      goto L1;
    }
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_string_String___eq(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = p0;
  i1 = p1;
  i0 = i0 == i1;
  if (i0) {
    i0 = 1u;
    goto Bfunc;
  }
  i0 = p0;
  i1 = 0u;
  i0 = i0 == i1;
  l2 = i0;
  if (i0) {
    i0 = l2;
  } else {
    i0 = p1;
    i1 = 0u;
    i0 = i0 == i1;
  }
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i1 = p1;
  i1 = i32_load((&memory), (u64)(i1));
  i0 = i0 != i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = p0;
  i1 = 0u;
  i2 = p1;
  i3 = 0u;
  i4 = l3;
  i0 = _lib_internal_string_compareUnsafe(i0, i1, i2, i3, i4);
  i0 = !(i0);
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_string_String___ne(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i0 = _lib_string_String___eq(i0, i1);
  i0 = !(i0);
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_internal_string_copyUnsafe(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4) {
  u32 l5 = 0, l6 = 0, l7 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i1 = p1;
  i2 = 1u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = 4u;
  i0 += i1;
  l5 = i0;
  i0 = p2;
  i1 = p3;
  i2 = 1u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = 4u;
  i0 += i1;
  l6 = i0;
  i0 = p4;
  i1 = 1u;
  i0 <<= (i1 & 31);
  l7 = i0;
  i0 = l5;
  i1 = l6;
  i2 = l7;
  _lib_internal_memory_memmove(i0, i1, i2);
  FUNC_EPILOGUE;
}

static u32 _lib_string_String_substring(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = p0;
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 64u;
    i2 = 249u;
    i3 = 4u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = p1;
  l4 = i0;
  i1 = 0u;
  l5 = i1;
  i2 = l4;
  i3 = l5;
  i2 = (u32)((s32)i2 > (s32)i3);
  i0 = i2 ? i0 : i1;
  l4 = i0;
  i1 = l3;
  l5 = i1;
  i2 = l4;
  i3 = l5;
  i2 = (u32)((s32)i2 < (s32)i3);
  i0 = i2 ? i0 : i1;
  l6 = i0;
  i0 = p2;
  l4 = i0;
  i1 = 0u;
  l5 = i1;
  i2 = l4;
  i3 = l5;
  i2 = (u32)((s32)i2 > (s32)i3);
  i0 = i2 ? i0 : i1;
  l4 = i0;
  i1 = l3;
  l5 = i1;
  i2 = l4;
  i3 = l5;
  i2 = (u32)((s32)i2 < (s32)i3);
  i0 = i2 ? i0 : i1;
  l7 = i0;
  i0 = l6;
  l4 = i0;
  i1 = l7;
  l5 = i1;
  i2 = l4;
  i3 = l5;
  i2 = (u32)((s32)i2 < (s32)i3);
  i0 = i2 ? i0 : i1;
  l8 = i0;
  i0 = l6;
  l4 = i0;
  i1 = l7;
  l5 = i1;
  i2 = l4;
  i3 = l5;
  i2 = (u32)((s32)i2 > (s32)i3);
  i0 = i2 ? i0 : i1;
  l9 = i0;
  i0 = l9;
  i1 = l8;
  i0 -= i1;
  l3 = i0;
  i0 = l3;
  i0 = !(i0);
  if (i0) {
    i0 = 312u;
    goto Bfunc;
  }
  i0 = l8;
  i0 = !(i0);
  l4 = i0;
  if (i0) {
    i0 = l9;
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1));
    i0 = i0 == i1;
  } else {
    i0 = l4;
  }
  if (i0) {
    i0 = p0;
    goto Bfunc;
  }
  i0 = l3;
  i0 = _lib_internal_string_allocateUnsafe(i0);
  l10 = i0;
  i0 = l10;
  i1 = 0u;
  i2 = p0;
  i3 = l8;
  i4 = l3;
  _lib_internal_string_copyUnsafe(i0, i1, i2, i3, i4);
  i0 = l10;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_string_String_concat(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = p0;
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 64u;
    i2 = 110u;
    i3 = 4u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = 40u;
    p1 = i0;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = p1;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l2;
  i1 = l3;
  i0 += i1;
  l4 = i0;
  i0 = l4;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = 312u;
    goto Bfunc;
  }
  i0 = l4;
  i0 = _lib_internal_string_allocateUnsafe(i0);
  l5 = i0;
  i0 = l5;
  i1 = 0u;
  i2 = p0;
  i3 = 0u;
  i4 = l2;
  _lib_internal_string_copyUnsafe(i0, i1, i2, i3, i4);
  i0 = l5;
  i1 = l2;
  i2 = p1;
  i3 = 0u;
  i4 = l3;
  _lib_internal_string_copyUnsafe(i0, i1, i2, i3, i4);
  i0 = l5;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_string_String___concat(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 40u;
    p0 = i0;
  }
  i0 = p0;
  i1 = p1;
  i0 = _lib_string_String_concat(i0, i1);
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_writeString(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i1 = 1184u;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
  i0 = 0u;
  l2 = i0;
  i0 = 0u;
  l3 = i0;
  L1: 
    i0 = l3;
    i1 = p1;
    i1 = i32_load((&memory), (u64)(i1));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = p1;
    i1 = l3;
    i0 = _lib_string_String_charCodeAt(i0, i1);
    l4 = i0;
    i0 = l4;
    i1 = 32u;
    i0 = (u32)((s32)i0 < (s32)i1);
    l5 = i0;
    if (i0) {
      i0 = l5;
    } else {
      i0 = l4;
      i1 = 1184u;
      i2 = 0u;
      i1 = _lib_string_String_charCodeAt(i1, i2);
      i0 = i0 == i1;
    }
    l5 = i0;
    if (i0) {
      i0 = l5;
    } else {
      i0 = l4;
      i1 = 1192u;
      i2 = 0u;
      i1 = _lib_string_String_charCodeAt(i1, i2);
      i0 = i0 == i1;
    }
    l5 = i0;
    i0 = l5;
    i1 = 0u;
    i0 = i0 != i1;
    if (i0) {
      i0 = p0;
      i1 = p1;
      i2 = l2;
      i3 = l3;
      i1 = _lib_string_String_substring(i1, i2, i3);
      ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
      i0 = l3;
      i1 = 1u;
      i0 += i1;
      l2 = i0;
      i0 = l4;
      i1 = 1184u;
      i2 = 0u;
      i1 = _lib_string_String_charCodeAt(i1, i2);
      i0 = i0 == i1;
      if (i0) {
        i0 = p0;
        i1 = 1200u;
        ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
      } else {
        i0 = l4;
        i1 = 1192u;
        i2 = 0u;
        i1 = _lib_string_String_charCodeAt(i1, i2);
        i0 = i0 == i1;
        if (i0) {
          i0 = p0;
          i1 = 1208u;
          ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
        } else {
          i0 = l4;
          i1 = 1216u;
          i2 = 0u;
          i1 = _lib_string_String_charCodeAt(i1, i2);
          i0 = i0 == i1;
          if (i0) {
            i0 = p0;
            i1 = 1224u;
            ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
          } else {
            i0 = l4;
            i1 = 1232u;
            i2 = 0u;
            i1 = _lib_string_String_charCodeAt(i1, i2);
            i0 = i0 == i1;
            if (i0) {
              i0 = p0;
              i1 = 1240u;
              ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
            } else {
              i0 = l4;
              i1 = 1248u;
              i2 = 0u;
              i1 = _lib_string_String_charCodeAt(i1, i2);
              i0 = i0 == i1;
              if (i0) {
                i0 = p0;
                i1 = 1256u;
                ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
              } else {
                i0 = l4;
                i1 = 1264u;
                i2 = 0u;
                i1 = _lib_string_String_charCodeAt(i1, i2);
                i0 = i0 == i1;
                if (i0) {
                  i0 = p0;
                  i1 = 1272u;
                  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
                } else {
                  i0 = 0u;
                  i0 = !(i0);
                  if (i0) {
                    i0 = 1280u;
                    i1 = l4;
                    i1 = _lib_number_I32_toString(i1);
                    i0 = _lib_string_String___concat(i0, i1);
                    i1 = 1360u;
                    i2 = 104u;
                    i3 = 20u;
                    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
                    UNREACHABLE;
                  }
                }
              }
            }
          }
        }
      }
    }
    i0 = l3;
    i1 = 1u;
    i0 += i1;
    l3 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = p0;
  i1 = p1;
  i2 = l2;
  i3 = p1;
  i3 = i32_load((&memory), (u64)(i3));
  i1 = _lib_string_String_substring(i1, i2, i3);
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
  i0 = p0;
  i1 = 1184u;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
  FUNC_EPILOGUE;
}

static void ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_writeKey(u32 p0, u32 p1) {
  u32 l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1));
  l2 = i1;
  i1 = l2;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i2 = 1u;
  i1 -= i2;
  i0 = _lib_array_Array_bool____get(i0, i1);
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = p0;
    i1 = 1176u;
    ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
  } else {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1));
    l2 = i1;
    i1 = l2;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i2 = 1u;
    i1 -= i2;
    i2 = 0u;
    _lib_array_Array_bool____set(i0, i1, i2);
  }
  i0 = p1;
  i1 = 0u;
  i0 = _lib_string_String___ne(i0, i1);
  if (i0) {
    i0 = p0;
    i1 = p1;
    ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_writeString(i0, i1);
    i0 = p0;
    i1 = 1480u;
    ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
  }
  FUNC_EPILOGUE;
}

static void ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_setString(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_writeKey(i0, i1);
  i0 = p0;
  i1 = p2;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_writeString(i0, i1);
  FUNC_EPILOGUE;
}

static void assembly_index_encodeI32(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i1 = 584u;
  i2 = p1;
  i2 = _lib_number_I32_toString(i2);
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_setString(i0, i1, i2);
  FUNC_EPILOGUE;
}

static u32 _lib_array_Array_bool__constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 1073741816u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 0u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_String__constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_constructor(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i2 = 1u;
  i1 = _lib_array_Array_bool__constructor(i1, i2);
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i2 = 0u;
  i1 = _lib_array_Array_String__constructor(i1, i2);
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 0u;
  i2 = 1u;
  _lib_array_Array_bool____set(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_bool__push(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 0u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l5 = i0;
  i0 = l2;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = l2;
    i1 = 1073741816u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 182u;
      i3 = 42u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = l5;
    i2 = 0u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
  }
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  l6 = i0;
  i0 = l2;
  l7 = i0;
  i0 = p1;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l6;
  i1 = l7;
  i2 = 0u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l9;
  i0 += i1;
  i1 = l8;
  i32_store8((&memory), (u64)(i0 + 8), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushArray(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_writeKey(i0, i1);
  i0 = p0;
  i1 = 1488u;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 1u;
  i0 = _lib_array_Array_bool__push(i0, i1);
  i0 = 1u;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushObject(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_writeKey(i0, i1);
  i0 = p0;
  i1 = 1496u;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 1u;
  i0 = _lib_array_Array_bool__push(i0, i1);
  i0 = 1u;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_bool__pop(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l1 = i0;
  i0 = l1;
  i1 = 1u;
  i0 = (u32)((s32)i0 < (s32)i1);
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 244u;
    i3 = 20u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = l1;
  i1 = 1u;
  i0 -= i1;
  l1 = i0;
  l3 = i0;
  i0 = 0u;
  l4 = i0;
  i0 = l2;
  i1 = l3;
  i2 = 0u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l4;
  i0 += i1;
  i0 = i32_load8_u((&memory), (u64)(i0 + 8));
  l5 = i0;
  i0 = p0;
  i1 = l1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popObject(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = 1504u;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i0 = _lib_array_Array_bool__pop(i0);
  FUNC_EPILOGUE;
}

static void ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popArray(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = 1512u;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_write(i0, i1);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i0 = _lib_array_Array_bool__pop(i0);
  FUNC_EPILOGUE;
}

static u32 _lib_array_Array_String__join(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, 
      l10 = 0, l11 = 0, l12 = 0, l13 = 0, l14 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 1u;
  i0 -= i1;
  l2 = i0;
  i0 = l2;
  i1 = 0u;
  i0 = (u32)((s32)i0 < (s32)i1);
  if (i0) {
    i0 = 312u;
    goto Bfunc;
  }
  i0 = 312u;
  l3 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l5 = i0;
  i0 = p1;
  i0 = i32_load((&memory), (u64)(i0));
  l6 = i0;
  i0 = l6;
  i1 = 0u;
  i0 = i0 != i1;
  l7 = i0;
  i0 = l2;
  i0 = !(i0);
  if (i0) {
    i0 = l5;
    l8 = i0;
    i0 = 0u;
    l9 = i0;
    i0 = 0u;
    l10 = i0;
    i0 = l8;
    i1 = l9;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l10;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
    goto Bfunc;
  }
  i0 = 0u;
  l10 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l8 = i0;
  L5: 
    i0 = l9;
    i1 = l8;
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B3;}
    i0 = l10;
    i1 = l5;
    l11 = i1;
    i1 = l9;
    l12 = i1;
    i1 = 0u;
    l13 = i1;
    i1 = l11;
    i2 = l12;
    i3 = 2u;
    i2 <<= (i3 & 31);
    i1 += i2;
    i2 = l13;
    i1 += i2;
    i1 = i32_load((&memory), (u64)(i1 + 8));
    i1 = i32_load((&memory), (u64)(i1));
    i0 += i1;
    l10 = i0;
    i0 = l9;
    i1 = 1u;
    i0 += i1;
    l9 = i0;
    goto L5;
  UNREACHABLE;
  B3:;
  i0 = 0u;
  l8 = i0;
  i0 = l10;
  i1 = l6;
  i2 = l2;
  i1 *= i2;
  i0 += i1;
  i0 = _lib_internal_string_allocateUnsafe(i0);
  l9 = i0;
  i0 = 0u;
  l13 = i0;
  L8: 
    i0 = l13;
    i1 = l2;
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B7;}
    i0 = l5;
    l12 = i0;
    i0 = l13;
    l11 = i0;
    i0 = 0u;
    l14 = i0;
    i0 = l12;
    i1 = l11;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 += i1;
    i1 = l14;
    i0 += i1;
    i0 = i32_load((&memory), (u64)(i0 + 8));
    l4 = i0;
    i0 = l4;
    if (i0) {
      i0 = l4;
      i0 = i32_load((&memory), (u64)(i0));
      l14 = i0;
      i0 = l9;
      i1 = l8;
      i2 = l4;
      i3 = 0u;
      i4 = l14;
      _lib_internal_string_copyUnsafe(i0, i1, i2, i3, i4);
      i0 = l8;
      i1 = l14;
      i0 += i1;
      l8 = i0;
    }
    i0 = l7;
    if (i0) {
      i0 = l9;
      i1 = l8;
      i2 = p1;
      i3 = 0u;
      i4 = l6;
      _lib_internal_string_copyUnsafe(i0, i1, i2, i3, i4);
      i0 = l8;
      i1 = l6;
      i0 += i1;
      l8 = i0;
    }
    i0 = l13;
    i1 = 1u;
    i0 += i1;
    l13 = i0;
    goto L8;
  UNREACHABLE;
  B7:;
  i0 = l5;
  l13 = i0;
  i0 = l2;
  l14 = i0;
  i0 = 0u;
  l11 = i0;
  i0 = l13;
  i1 = l14;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l11;
  i0 += i1;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l4 = i0;
  i0 = l4;
  if (i0) {
    i0 = l4;
    i0 = i32_load((&memory), (u64)(i0));
    l11 = i0;
    i0 = l9;
    i1 = l8;
    i2 = l4;
    i3 = 0u;
    i4 = l11;
    _lib_internal_string_copyUnsafe(i0, i1, i2, i3, i4);
  }
  i0 = l9;
  goto Bfunc;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_toString(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 312u;
  i0 = _lib_array_Array_String__join(i0, i1);
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_string_String_get_lengthUTF8(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 1u;
  l1 = i0;
  i0 = 0u;
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  L1: 
    i0 = l2;
    i1 = l3;
    i0 = i0 < i1;
    if (i0) {
      i0 = p0;
      i1 = l2;
      i2 = 1u;
      i1 <<= (i2 & 31);
      i0 += i1;
      i0 = i32_load16_u((&memory), (u64)(i0 + 4));
      l4 = i0;
      i0 = l4;
      i1 = 128u;
      i0 = i0 < i1;
      if (i0) {
        i0 = l1;
        i1 = 1u;
        i0 += i1;
        l1 = i0;
        i0 = l2;
        i1 = 1u;
        i0 += i1;
        l2 = i0;
      } else {
        i0 = l4;
        i1 = 2048u;
        i0 = i0 < i1;
        if (i0) {
          i0 = l1;
          i1 = 2u;
          i0 += i1;
          l1 = i0;
          i0 = l2;
          i1 = 1u;
          i0 += i1;
          l2 = i0;
        } else {
          i0 = l4;
          i1 = 64512u;
          i0 &= i1;
          i1 = 55296u;
          i0 = i0 == i1;
          l5 = i0;
          if (i0) {
            i0 = l2;
            i1 = 1u;
            i0 += i1;
            i1 = l3;
            i0 = i0 < i1;
          } else {
            i0 = l5;
          }
          l5 = i0;
          if (i0) {
            i0 = p0;
            i1 = l2;
            i2 = 1u;
            i1 += i2;
            i2 = 1u;
            i1 <<= (i2 & 31);
            i0 += i1;
            i0 = i32_load16_u((&memory), (u64)(i0 + 4));
            i1 = 64512u;
            i0 &= i1;
            i1 = 56320u;
            i0 = i0 == i1;
          } else {
            i0 = l5;
          }
          if (i0) {
            i0 = l1;
            i1 = 4u;
            i0 += i1;
            l1 = i0;
            i0 = l2;
            i1 = 2u;
            i0 += i1;
            l2 = i0;
          } else {
            i0 = l1;
            i1 = 3u;
            i0 += i1;
            l1 = i0;
            i0 = l2;
            i1 = 1u;
            i0 += i1;
            l2 = i0;
          }
        }
      }
      goto L1;
    }
  i0 = l1;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_string_String_toUTF8(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = _lib_string_String_get_lengthUTF8(i0);
  l1 = i0;
  i0 = l1;
  i0 = _lib_allocator_arena___memory_allocate(i0);
  goto B0;
  B0:;
  l2 = i0;
  i0 = 0u;
  l3 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  L2: 
    i0 = l3;
    i1 = l4;
    i0 = i0 < i1;
    if (i0) {
      i0 = p0;
      i1 = l3;
      i2 = 1u;
      i1 <<= (i2 & 31);
      i0 += i1;
      i0 = i32_load16_u((&memory), (u64)(i0 + 4));
      l1 = i0;
      i0 = l1;
      i1 = 128u;
      i0 = i0 < i1;
      if (i0) {
        i0 = l2;
        i1 = l5;
        i0 += i1;
        i1 = l1;
        i32_store8((&memory), (u64)(i0), i1);
        i0 = l5;
        i1 = 1u;
        i0 += i1;
        l5 = i0;
        i0 = l3;
        i1 = 1u;
        i0 += i1;
        l3 = i0;
      } else {
        i0 = l1;
        i1 = 2048u;
        i0 = i0 < i1;
        if (i0) {
          i0 = l2;
          i1 = l5;
          i0 += i1;
          l6 = i0;
          i0 = l6;
          i1 = l1;
          i2 = 6u;
          i1 >>= (i2 & 31);
          i2 = 192u;
          i1 |= i2;
          i32_store8((&memory), (u64)(i0), i1);
          i0 = l6;
          i1 = l1;
          i2 = 63u;
          i1 &= i2;
          i2 = 128u;
          i1 |= i2;
          i32_store8((&memory), (u64)(i0 + 1), i1);
          i0 = l5;
          i1 = 2u;
          i0 += i1;
          l5 = i0;
          i0 = l3;
          i1 = 1u;
          i0 += i1;
          l3 = i0;
        } else {
          i0 = l2;
          i1 = l5;
          i0 += i1;
          l6 = i0;
          i0 = l1;
          i1 = 64512u;
          i0 &= i1;
          i1 = 55296u;
          i0 = i0 == i1;
          l7 = i0;
          if (i0) {
            i0 = l3;
            i1 = 1u;
            i0 += i1;
            i1 = l4;
            i0 = i0 < i1;
          } else {
            i0 = l7;
          }
          if (i0) {
            i0 = p0;
            i1 = l3;
            i2 = 1u;
            i1 += i2;
            i2 = 1u;
            i1 <<= (i2 & 31);
            i0 += i1;
            i0 = i32_load16_u((&memory), (u64)(i0 + 4));
            l7 = i0;
            i0 = l7;
            i1 = 64512u;
            i0 &= i1;
            i1 = 56320u;
            i0 = i0 == i1;
            if (i0) {
              i0 = 65536u;
              i1 = l1;
              i2 = 1023u;
              i1 &= i2;
              i2 = 10u;
              i1 <<= (i2 & 31);
              i0 += i1;
              i1 = l7;
              i2 = 1023u;
              i1 &= i2;
              i0 += i1;
              l1 = i0;
              i0 = l6;
              i1 = l1;
              i2 = 18u;
              i1 >>= (i2 & 31);
              i2 = 240u;
              i1 |= i2;
              i32_store8((&memory), (u64)(i0), i1);
              i0 = l6;
              i1 = l1;
              i2 = 12u;
              i1 >>= (i2 & 31);
              i2 = 63u;
              i1 &= i2;
              i2 = 128u;
              i1 |= i2;
              i32_store8((&memory), (u64)(i0 + 1), i1);
              i0 = l6;
              i1 = l1;
              i2 = 6u;
              i1 >>= (i2 & 31);
              i2 = 63u;
              i1 &= i2;
              i2 = 128u;
              i1 |= i2;
              i32_store8((&memory), (u64)(i0 + 2), i1);
              i0 = l6;
              i1 = l1;
              i2 = 63u;
              i1 &= i2;
              i2 = 128u;
              i1 |= i2;
              i32_store8((&memory), (u64)(i0 + 3), i1);
              i0 = l5;
              i1 = 4u;
              i0 += i1;
              l5 = i0;
              i0 = l3;
              i1 = 2u;
              i0 += i1;
              l3 = i0;
              goto L2;
            }
          }
          i0 = l6;
          i1 = l1;
          i2 = 12u;
          i1 >>= (i2 & 31);
          i2 = 224u;
          i1 |= i2;
          i32_store8((&memory), (u64)(i0), i1);
          i0 = l6;
          i1 = l1;
          i2 = 6u;
          i1 >>= (i2 & 31);
          i2 = 63u;
          i1 &= i2;
          i2 = 128u;
          i1 |= i2;
          i32_store8((&memory), (u64)(i0 + 1), i1);
          i0 = l6;
          i1 = l1;
          i2 = 63u;
          i1 &= i2;
          i2 = 128u;
          i1 |= i2;
          i32_store8((&memory), (u64)(i0 + 2), i1);
          i0 = l5;
          i1 = 3u;
          i0 += i1;
          l5 = i0;
          i0 = l3;
          i1 = 1u;
          i0 += i1;
          l3 = i0;
        }
      }
      goto L2;
    }
  i0 = l2;
  i1 = l5;
  i0 += i1;
  i1 = 0u;
  i32_store8((&memory), (u64)(i0), i1);
  i0 = l2;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_serialize(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_toString(i0);
  l1 = i0;
  i0 = l1;
  i0 = _lib_string_String_toUTF8(i0);
  l2 = i0;
  i0 = 0u;
  i1 = l1;
  i1 = _lib_string_String_get_lengthUTF8(i1);
  i2 = 1u;
  i1 -= i2;
  i0 = _lib_typedarray_Uint8Array_constructor(i0, i1);
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  l4 = i0;
  i0 = l4;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = l2;
  l5 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memmove(i0, i1, i2);
  i0 = l3;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_MatrixEncoder_i32_(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 0u;
  i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_constructor(i0);
  l2 = i0;
  i0 = l2;
  i1 = 0u;
  i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushArray(i0, i1);
  i0 = 0u;
  l3 = i0;
  L1: 
    i0 = l3;
    i1 = p0;
    l4 = i1;
    i1 = l4;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = l2;
    i1 = 0u;
    i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushArray(i0, i1);
    i0 = 0u;
    l4 = i0;
    L5: 
      i0 = l4;
      i1 = p0;
      i2 = l3;
      i1 = _lib_array_Array_Array_i32_____get(i1, i2);
      l5 = i1;
      i1 = l5;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B4;}
      i0 = l2;
      i1 = 0u;
      i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushObject(i0, i1);
      i0 = 2u;
      g16 = i0;
      i0 = l2;
      i1 = p0;
      i2 = l3;
      i1 = _lib_array_Array_Array_i32_____get(i1, i2);
      i2 = l4;
      i1 = _lib_array_Array_i32____get(i1, i2);
      i2 = p1;
      CALL_INDIRECT(table, void (*)(u32, u32), 14, i2, i0, i1);
      i0 = l2;
      ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popObject(i0);
      i0 = l4;
      i1 = 1u;
      i0 += i1;
      l4 = i0;
      goto L5;
    UNREACHABLE;
    B4:;
    i0 = l2;
    ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popArray(i0);
    i0 = l3;
    i1 = 1u;
    i0 += i1;
    l3 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l2;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popArray(i0);
  i0 = l2;
  i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_serialize(i0);
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_serializeI32(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = 11u;
  i0 = assembly_index_MatrixEncoder_i32_(i0, i1);
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_string_String_fromCharCode(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = 1u;
  i0 = _lib_internal_string_allocateUnsafe(i0);
  l1 = i0;
  i0 = l1;
  i1 = p0;
  i32_store16((&memory), (u64)(i0 + 4), i1);
  i0 = l1;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_array_Array_String____set(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = p1;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = p1;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 107u;
      i3 = 41u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = p1;
    i2 = 1u;
    i1 += i2;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
    i0 = p0;
    i1 = p1;
    i2 = 1u;
    i1 += i2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  }
  i0 = l3;
  l5 = i0;
  i0 = p1;
  l6 = i0;
  i0 = p2;
  l7 = i0;
  i0 = 0u;
  l8 = i0;
  i0 = l5;
  i1 = l6;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l8;
  i0 += i1;
  i1 = l7;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 assembly_index_uint8ArrayToString(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = 0u;
  i1 = p0;
  l1 = i1;
  i1 = l1;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = 0u;
  i1 >>= (i2 & 31);
  i0 = _lib_array_Array_String__constructor(i0, i1);
  l1 = i0;
  i0 = 0u;
  l2 = i0;
  L2: 
    i0 = l2;
    i1 = p0;
    l3 = i1;
    i1 = l3;
    i1 = i32_load((&memory), (u64)(i1 + 8));
    i2 = 0u;
    i1 >>= (i2 & 31);
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B1;}
    i0 = l1;
    i1 = l2;
    i2 = p0;
    i3 = l2;
    i2 = _lib_internal_typedarray_TypedArray_u8____get(i2, i3);
    i3 = 255u;
    i2 &= i3;
    i2 = _lib_string_String_fromCharCode(i2);
    _lib_array_Array_String____set(i0, i1, i2);
    i0 = l2;
    i1 = 1u;
    i0 += i1;
    l2 = i0;
    goto L2;
  UNREACHABLE;
  B1:;
  i0 = l1;
  i1 = 312u;
  i0 = _lib_array_Array_String__join(i0, i1);
  l2 = i0;
  i0 = l2;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_constructor(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_MatrixDecoder_i32__constructor(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  if (i0) {
    i0 = p0;
  } else {
    i0 = 16u;
    i0 = _lib_memory_memory_allocate(i0);
  }
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_constructor(i0);
  p0 = i0;
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = 0u;
  i2 = 0u;
  i1 = _lib_array_Array_Array_i32___constructor(i1, i2);
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_internal_hash_hashStr(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 2166136261u;
  l1 = i0;
  i0 = 0u;
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 1u;
  i0 <<= (i1 & 31);
  l3 = i0;
  L2: 
    i0 = l2;
    i1 = l3;
    i0 = i0 < i1;
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = l1;
    i1 = p0;
    i2 = l2;
    i1 += i2;
    i1 = i32_load8_u((&memory), (u64)(i1 + 4));
    i0 ^= i1;
    i1 = 16777619u;
    i0 *= i1;
    l1 = i0;
    i0 = l2;
    i1 = 1u;
    i0 += i1;
    l2 = i0;
    goto L2;
  UNREACHABLE;
  B0:;
  i0 = l1;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_map_Map_String_String__find(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p2;
  i2 = p0;
  i2 = i32_load((&memory), (u64)(i2 + 4));
  i1 &= i2;
  i2 = 4u;
  i1 *= i2;
  i0 += i1;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l3 = i0;
  L1: 
    i0 = l3;
    if (i0) {
      i0 = l3;
      i0 = i32_load((&memory), (u64)(i0 + 8));
      i1 = 1u;
      i0 &= i1;
      i0 = !(i0);
      l4 = i0;
      if (i0) {
        i0 = l3;
        i0 = i32_load((&memory), (u64)(i0));
        i1 = p1;
        i0 = _lib_string_String___eq(i0, i1);
      } else {
        i0 = l4;
      }
      if (i0) {
        i0 = l3;
        goto Bfunc;
      }
      i0 = l3;
      i0 = i32_load((&memory), (u64)(i0 + 8));
      i1 = 1u;
      i2 = 4294967295u;
      i1 ^= i2;
      i0 &= i1;
      l3 = i0;
      goto L1;
    }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_map_Map_String_String__get(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i1 = p1;
  i2 = p1;
  l2 = i2;
  i2 = l2;
  i2 = _lib_internal_hash_hashStr(i2);
  goto B0;
  B0:;
  i0 = _lib_map_Map_String_String__find(i0, i1, i2);
  l3 = i0;
  i0 = l3;
  if (i0) {
    i0 = l3;
    i0 = i32_load((&memory), (u64)(i0 + 4));
  } else {
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_internal_string_parse_i32_(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  f64 d0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l2 = i0;
  i0 = l2;
  i0 = !(i0);
  if (i0) {
    d0 = f64_reinterpret_i64(0x7ff8000000000000) /* nan:0x8000000000000 */;
    i0 = I32_TRUNC_S_F64(d0);
    goto Bfunc;
  }
  i0 = p0;
  l3 = i0;
  i0 = l3;
  i0 = i32_load16_u((&memory), (u64)(i0 + 4));
  l4 = i0;
  i0 = l4;
  i1 = 45u;
  i0 = i0 == i1;
  if (i0) {
    i0 = l2;
    i1 = 1u;
    i0 -= i1;
    l2 = i0;
    i0 = !(i0);
    if (i0) {
      d0 = f64_reinterpret_i64(0x7ff8000000000000) /* nan:0x8000000000000 */;
      i0 = I32_TRUNC_S_F64(d0);
      goto Bfunc;
    }
    i0 = l3;
    i1 = 2u;
    i0 += i1;
    l3 = i0;
    i0 = i32_load16_u((&memory), (u64)(i0 + 4));
    l4 = i0;
    i0 = 4294967295u;
    l5 = i0;
  } else {
    i0 = l4;
    i1 = 43u;
    i0 = i0 == i1;
    if (i0) {
      i0 = l2;
      i1 = 1u;
      i0 -= i1;
      l2 = i0;
      i0 = !(i0);
      if (i0) {
        d0 = f64_reinterpret_i64(0x7ff8000000000000) /* nan:0x8000000000000 */;
        i0 = I32_TRUNC_S_F64(d0);
        goto Bfunc;
      }
      i0 = l3;
      i1 = 2u;
      i0 += i1;
      l3 = i0;
      i0 = i32_load16_u((&memory), (u64)(i0 + 4));
      l4 = i0;
      i0 = 1u;
      l5 = i0;
    } else {
      i0 = 1u;
      l5 = i0;
    }
  }
  i0 = p1;
  i0 = !(i0);
  if (i0) {
    i0 = l4;
    i1 = 48u;
    i0 = i0 == i1;
    l6 = i0;
    if (i0) {
      i0 = l2;
      i1 = 2u;
      i0 = (u32)((s32)i0 > (s32)i1);
    } else {
      i0 = l6;
    }
    if (i0) {
      i0 = l3;
      i1 = 2u;
      i0 += i1;
      i0 = i32_load16_u((&memory), (u64)(i0 + 4));
      l6 = i0;
      i0 = l6;
      i1 = 66u;
      i0 = i0 == i1;
      if (i0) {goto B15;}
      i0 = l6;
      i1 = 98u;
      i0 = i0 == i1;
      if (i0) {goto B14;}
      i0 = l6;
      i1 = 79u;
      i0 = i0 == i1;
      if (i0) {goto B13;}
      i0 = l6;
      i1 = 111u;
      i0 = i0 == i1;
      if (i0) {goto B12;}
      i0 = l6;
      i1 = 88u;
      i0 = i0 == i1;
      if (i0) {goto B11;}
      i0 = l6;
      i1 = 120u;
      i0 = i0 == i1;
      if (i0) {goto B10;}
      goto B9;
      B15:;
      B14:;
      i0 = l3;
      i1 = 4u;
      i0 += i1;
      l3 = i0;
      i0 = l2;
      i1 = 2u;
      i0 -= i1;
      l2 = i0;
      i0 = 2u;
      p1 = i0;
      goto B8;
      UNREACHABLE;
      B13:;
      B12:;
      i0 = l3;
      i1 = 4u;
      i0 += i1;
      l3 = i0;
      i0 = l2;
      i1 = 2u;
      i0 -= i1;
      l2 = i0;
      i0 = 8u;
      p1 = i0;
      goto B8;
      UNREACHABLE;
      B11:;
      B10:;
      i0 = l3;
      i1 = 4u;
      i0 += i1;
      l3 = i0;
      i0 = l2;
      i1 = 2u;
      i0 -= i1;
      l2 = i0;
      i0 = 16u;
      p1 = i0;
      goto B8;
      UNREACHABLE;
      B9:;
      i0 = 10u;
      p1 = i0;
      B8:;
    } else {
      i0 = 10u;
      p1 = i0;
    }
  } else {
    i0 = p1;
    i1 = 2u;
    i0 = (u32)((s32)i0 < (s32)i1);
    l6 = i0;
    if (i0) {
      i0 = l6;
    } else {
      i0 = p1;
      i1 = 36u;
      i0 = (u32)((s32)i0 > (s32)i1);
    }
    if (i0) {
      d0 = f64_reinterpret_i64(0x7ff8000000000000) /* nan:0x8000000000000 */;
      i0 = I32_TRUNC_S_F64(d0);
      goto Bfunc;
    }
  }
  i0 = 0u;
  l7 = i0;
  L22: 
    i0 = l2;
    l6 = i0;
    i1 = 1u;
    i0 -= i1;
    l2 = i0;
    i0 = l6;
    if (i0) {
      i0 = l3;
      i0 = i32_load16_u((&memory), (u64)(i0 + 4));
      l4 = i0;
      i0 = l4;
      i1 = 48u;
      i0 = (u32)((s32)i0 >= (s32)i1);
      l6 = i0;
      if (i0) {
        i0 = l4;
        i1 = 57u;
        i0 = (u32)((s32)i0 <= (s32)i1);
      } else {
        i0 = l6;
      }
      if (i0) {
        i0 = l4;
        i1 = 48u;
        i0 -= i1;
        l4 = i0;
      } else {
        i0 = l4;
        i1 = 65u;
        i0 = (u32)((s32)i0 >= (s32)i1);
        l6 = i0;
        if (i0) {
          i0 = l4;
          i1 = 90u;
          i0 = (u32)((s32)i0 <= (s32)i1);
        } else {
          i0 = l6;
        }
        if (i0) {
          i0 = l4;
          i1 = 65u;
          i2 = 10u;
          i1 -= i2;
          i0 -= i1;
          l4 = i0;
        } else {
          i0 = l4;
          i1 = 97u;
          i0 = (u32)((s32)i0 >= (s32)i1);
          l6 = i0;
          if (i0) {
            i0 = l4;
            i1 = 122u;
            i0 = (u32)((s32)i0 <= (s32)i1);
          } else {
            i0 = l6;
          }
          if (i0) {
            i0 = l4;
            i1 = 97u;
            i2 = 10u;
            i1 -= i2;
            i0 -= i1;
            l4 = i0;
          } else {
            goto B21;
          }
        }
      }
      i0 = l4;
      i1 = p1;
      i0 = (u32)((s32)i0 >= (s32)i1);
      if (i0) {
        goto B21;
      }
      i0 = l7;
      i1 = p1;
      i0 *= i1;
      i1 = l4;
      i0 += i1;
      l7 = i0;
      i0 = l3;
      i1 = 2u;
      i0 += i1;
      l3 = i0;
      goto L22;
    }
  B21:;
  i0 = l5;
  i1 = l7;
  i0 *= i1;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_string_parseI32(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i0 = _lib_internal_string_parse_i32_(i0, i1);
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_decodeI32(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = 584u;
  i0 = _lib_map_Map_String_String__get(i0, i1);
  l1 = i0;
  i0 = l1;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    UNREACHABLE;
  }
  i0 = l1;
  i1 = 0u;
  i0 = _lib_string_parseI32(i0, i1);
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___constructor(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_DecoderState_constructor(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 12u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i1 = i32_load((&memory), (u64)(i1 + 4));
  l1 = i1;
  i1 = l1;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = 0u;
  i1 >>= (i2 & 31);
  i0 = (u32)((s32)i0 >= (s32)i1);
  if (i0) {
    i0 = 4294967295u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i1 = i32_load((&memory), (u64)(i1));
  i0 = _lib_internal_typedarray_TypedArray_u8____get(i0, i1);
  i1 = 255u;
  i0 &= i1;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___isWhitespace(u32 p0, u32 p1) {
  u32 l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p1;
  i1 = 9u;
  i0 = i0 == i1;
  l2 = i0;
  if (i0) {
    i0 = l2;
  } else {
    i0 = p1;
    i1 = 10u;
    i0 = i0 == i1;
  }
  l2 = i0;
  if (i0) {
    i0 = l2;
  } else {
    i0 = p1;
    i1 = 13u;
    i0 = i0 == i1;
  }
  l2 = i0;
  if (i0) {
    i0 = l2;
  } else {
    i0 = p1;
    i1 = 32u;
    i0 = i0 == i1;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i1 = i32_load((&memory), (u64)(i1 + 4));
  l1 = i1;
  i1 = l1;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = 0u;
  i1 >>= (i2 & 31);
  i0 = (u32)((s32)i0 < (s32)i1);
  i0 = !(i0);
  if (i0) {
    i0 = 1552u;
    i1 = 1600u;
    i2 = 114u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i2 = p0;
  i2 = i32_load((&memory), (u64)(i2 + 4));
  i2 = i32_load((&memory), (u64)(i2));
  l1 = i2;
  i3 = 1u;
  i2 += i3;
  i32_store((&memory), (u64)(i1), i2);
  i1 = l1;
  i0 = _lib_internal_typedarray_TypedArray_u8____get(i0, i1);
  i1 = 255u;
  i0 &= i1;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___skipWhitespace(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  L0: 
    i0 = p0;
    i1 = p0;
    i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(i1);
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___isWhitespace(i0, i1);
    if (i0) {
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
      goto L0;
    }
  FUNC_EPILOGUE;
}

static void _lib_map_Map_String_String__clear(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i1 = 0u;
  i2 = 16u;
  i3 = 0u;
  i1 = _lib_arraybuffer_ArrayBuffer_constructor(i1, i2, i3);
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 4u;
  i2 = 1u;
  i1 -= i2;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i2 = 48u;
  i3 = 1u;
  i1 = _lib_arraybuffer_ArrayBuffer_constructor(i1, i2, i3);
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = 4u;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 16), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 20), i1);
  FUNC_EPILOGUE;
}

static u32 _lib_map_Map_String_String__constructor(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 24u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 16), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 20), i1);
  i0 = p0;
  _lib_map_Map_String_String__clear(i0);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_MatrixDecoder_i32__pushObject(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 0u;
  i0 = i0 == i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 320u;
    i2 = 1005u;
    i3 = 2u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i1 = 0u;
  i1 = _lib_map_Map_String_String__constructor(i1);
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = 1u;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_string_String_fromUTF8(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = p1;
  i1 = 1u;
  i0 = i0 < i1;
  if (i0) {
    i0 = 312u;
    goto Bfunc;
  }
  i0 = 0u;
  l2 = i0;
  i0 = p1;
  i1 = 1u;
  i0 <<= (i1 & 31);
  l3 = i0;
  i0 = l3;
  i0 = _lib_allocator_arena___memory_allocate(i0);
  goto B1;
  B1:;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  L3: 
    i0 = l2;
    i1 = p1;
    i0 = i0 < i1;
    if (i0) {
      i0 = p0;
      i1 = l2;
      l3 = i1;
      i2 = 1u;
      i1 += i2;
      l2 = i1;
      i1 = l3;
      i0 += i1;
      i0 = i32_load8_u((&memory), (u64)(i0));
      l3 = i0;
      i0 = l3;
      i1 = 128u;
      i0 = i0 < i1;
      if (i0) {
        i0 = l4;
        i1 = l5;
        i0 += i1;
        i1 = l3;
        i32_store16((&memory), (u64)(i0), i1);
        i0 = l5;
        i1 = 2u;
        i0 += i1;
        l5 = i0;
      } else {
        i0 = l3;
        i1 = 191u;
        i0 = i0 > i1;
        l6 = i0;
        if (i0) {
          i0 = l3;
          i1 = 224u;
          i0 = i0 < i1;
        } else {
          i0 = l6;
        }
        if (i0) {
          i0 = l2;
          i1 = 1u;
          i0 += i1;
          i1 = p1;
          i0 = i0 <= i1;
          i0 = !(i0);
          if (i0) {
            i0 = 0u;
            i1 = 64u;
            i2 = 507u;
            i3 = 8u;
            (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
            UNREACHABLE;
          }
          i0 = l4;
          i1 = l5;
          i0 += i1;
          i1 = l3;
          i2 = 31u;
          i1 &= i2;
          i2 = 6u;
          i1 <<= (i2 & 31);
          i2 = p0;
          i3 = l2;
          l6 = i3;
          i4 = 1u;
          i3 += i4;
          l2 = i3;
          i3 = l6;
          i2 += i3;
          i2 = i32_load8_u((&memory), (u64)(i2));
          i3 = 63u;
          i2 &= i3;
          i1 |= i2;
          i32_store16((&memory), (u64)(i0), i1);
          i0 = l5;
          i1 = 2u;
          i0 += i1;
          l5 = i0;
        } else {
          i0 = l3;
          i1 = 239u;
          i0 = i0 > i1;
          l6 = i0;
          if (i0) {
            i0 = l3;
            i1 = 365u;
            i0 = i0 < i1;
          } else {
            i0 = l6;
          }
          if (i0) {
            i0 = l2;
            i1 = 3u;
            i0 += i1;
            i1 = p1;
            i0 = i0 <= i1;
            i0 = !(i0);
            if (i0) {
              i0 = 0u;
              i1 = 64u;
              i2 = 511u;
              i3 = 8u;
              (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
              UNREACHABLE;
            }
            i0 = l3;
            i1 = 7u;
            i0 &= i1;
            i1 = 18u;
            i0 <<= (i1 & 31);
            i1 = p0;
            i2 = l2;
            l6 = i2;
            i3 = 1u;
            i2 += i3;
            l2 = i2;
            i2 = l6;
            i1 += i2;
            i1 = i32_load8_u((&memory), (u64)(i1));
            i2 = 63u;
            i1 &= i2;
            i2 = 12u;
            i1 <<= (i2 & 31);
            i0 |= i1;
            i1 = p0;
            i2 = l2;
            l6 = i2;
            i3 = 1u;
            i2 += i3;
            l2 = i2;
            i2 = l6;
            i1 += i2;
            i1 = i32_load8_u((&memory), (u64)(i1));
            i2 = 63u;
            i1 &= i2;
            i2 = 6u;
            i1 <<= (i2 & 31);
            i0 |= i1;
            i1 = p0;
            i2 = l2;
            l6 = i2;
            i3 = 1u;
            i2 += i3;
            l2 = i2;
            i2 = l6;
            i1 += i2;
            i1 = i32_load8_u((&memory), (u64)(i1));
            i2 = 63u;
            i1 &= i2;
            i0 |= i1;
            i1 = 65536u;
            i0 -= i1;
            l3 = i0;
            i0 = l4;
            i1 = l5;
            i0 += i1;
            i1 = 55296u;
            i2 = l3;
            i3 = 10u;
            i2 >>= (i3 & 31);
            i1 += i2;
            i32_store16((&memory), (u64)(i0), i1);
            i0 = l5;
            i1 = 2u;
            i0 += i1;
            l5 = i0;
            i0 = l4;
            i1 = l5;
            i0 += i1;
            i1 = 56320u;
            i2 = l3;
            i3 = 1023u;
            i2 &= i3;
            i1 += i2;
            i32_store16((&memory), (u64)(i0), i1);
            i0 = l5;
            i1 = 2u;
            i0 += i1;
            l5 = i0;
          } else {
            i0 = l2;
            i1 = 2u;
            i0 += i1;
            i1 = p1;
            i0 = i0 <= i1;
            i0 = !(i0);
            if (i0) {
              i0 = 0u;
              i1 = 64u;
              i2 = 523u;
              i3 = 8u;
              (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
              UNREACHABLE;
            }
            i0 = l4;
            i1 = l5;
            i0 += i1;
            i1 = l3;
            i2 = 15u;
            i1 &= i2;
            i2 = 12u;
            i1 <<= (i2 & 31);
            i2 = p0;
            i3 = l2;
            l6 = i3;
            i4 = 1u;
            i3 += i4;
            l2 = i3;
            i3 = l6;
            i2 += i3;
            i2 = i32_load8_u((&memory), (u64)(i2));
            i3 = 63u;
            i2 &= i3;
            i3 = 6u;
            i2 <<= (i3 & 31);
            i1 |= i2;
            i2 = p0;
            i3 = l2;
            l6 = i3;
            i4 = 1u;
            i3 += i4;
            l2 = i3;
            i3 = l6;
            i2 += i3;
            i2 = i32_load8_u((&memory), (u64)(i2));
            i3 = 63u;
            i2 &= i3;
            i1 |= i2;
            i32_store16((&memory), (u64)(i0), i1);
            i0 = l5;
            i1 = 2u;
            i0 += i1;
            l5 = i0;
          }
        }
      }
      goto L3;
    }
  i0 = l2;
  i1 = p1;
  i0 = i0 == i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 64u;
    i2 = 532u;
    i3 = 4u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = l5;
  i1 = 1u;
  i0 >>= (i1 & 31);
  i0 = _lib_internal_string_allocateUnsafe(i0);
  l7 = i0;
  i0 = l7;
  i1 = 4u;
  i0 += i1;
  l3 = i0;
  i0 = l4;
  l6 = i0;
  i0 = l5;
  l8 = i0;
  i0 = l3;
  i1 = l6;
  i2 = l8;
  _lib_internal_memory_memmove(i0, i1, i2);
  i0 = l4;
  l8 = i0;
  i0 = l8;
  _lib_allocator_arena___memory_free(i0);
  goto B23;
  B23:;
  i0 = l7;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_array_Array_i32____unchecked_set(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = p1;
  l4 = i0;
  i0 = p2;
  l5 = i0;
  i0 = 0u;
  l6 = i0;
  i0 = l3;
  i1 = l4;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l6;
  i0 += i1;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readHexDigit(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
  l1 = i0;
  i0 = l1;
  i1 = g5;
  i0 -= i1;
  l2 = i0;
  i0 = l2;
  i1 = 9u;
  i0 = (u32)((s32)i0 > (s32)i1);
  if (i0) {
    i0 = l1;
    i1 = g7;
    i0 -= i1;
    i1 = 10u;
    i0 += i1;
    l2 = i0;
    i0 = l2;
    i1 = 10u;
    i0 = (u32)((s32)i0 < (s32)i1);
    l3 = i0;
    if (i0) {
      i0 = l3;
    } else {
      i0 = l2;
      i1 = 15u;
      i0 = (u32)((s32)i0 > (s32)i1);
    }
    if (i0) {
      i0 = l1;
      i1 = g8;
      i0 -= i1;
      i1 = 10u;
      i0 += i1;
      l2 = i0;
    }
  }
  i0 = 0u;
  i1 = 2u;
  i0 = _lib_array_Array_i32__constructor(i0, i1);
  l4 = i0;
  i0 = l4;
  i1 = 0u;
  i2 = l1;
  _lib_array_Array_i32____unchecked_set(i0, i1, i2);
  i0 = l4;
  i1 = 1u;
  i2 = l2;
  _lib_array_Array_i32____unchecked_set(i0, i1, i2);
  i0 = l4;
  l4 = i0;
  i0 = l2;
  i1 = 0u;
  i0 = (u32)((s32)i0 >= (s32)i1);
  l3 = i0;
  if (i0) {
    i0 = l2;
    i1 = 16u;
    i0 = (u32)((s32)i0 < (s32)i1);
  } else {
    i0 = l3;
  }
  i0 = !(i0);
  if (i0) {
    i0 = 1928u;
    i1 = 1600u;
    i2 = 272u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = l2;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_string_String_fromCodePoint(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i1 = 1114111u;
  i0 = i0 <= i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 64u;
    i2 = 34u;
    i3 = 4u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i1 = 65535u;
  i0 = (u32)((s32)i0 > (s32)i1);
  l1 = i0;
  i0 = l1;
  i1 = 1u;
  i0 += i1;
  i0 = _lib_internal_string_allocateUnsafe(i0);
  l2 = i0;
  i0 = l1;
  i0 = !(i0);
  if (i0) {
    i0 = l2;
    i1 = p0;
    i32_store16((&memory), (u64)(i0 + 4), i1);
  } else {
    i0 = p0;
    i1 = 65536u;
    i0 -= i1;
    p0 = i0;
    i0 = p0;
    i1 = 10u;
    i0 >>= (i1 & 31);
    i1 = 55296u;
    i0 += i1;
    l3 = i0;
    i0 = p0;
    i1 = 1023u;
    i0 &= i1;
    i1 = 56320u;
    i0 += i1;
    l4 = i0;
    i0 = l2;
    i1 = l3;
    i2 = 16u;
    i1 <<= (i2 & 31);
    i2 = l4;
    i1 |= i2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  }
  i0 = l2;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readEscapedChar(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
  l1 = i0;
  i0 = l1;
  i1 = 1184u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1184u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1192u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1192u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1880u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1880u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1888u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1216u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1896u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1232u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1904u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1248u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1912u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1264u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1920u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readHexDigit(i0);
    l2 = i0;
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readHexDigit(i0);
    l3 = i0;
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readHexDigit(i0);
    l4 = i0;
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readHexDigit(i0);
    l5 = i0;
    i0 = l2;
    i1 = 4096u;
    i0 *= i1;
    i1 = l3;
    i2 = 256u;
    i1 *= i2;
    i0 += i1;
    i1 = l4;
    i2 = 16u;
    i1 *= i2;
    i0 += i1;
    i1 = l5;
    i0 += i1;
    l6 = i0;
    i0 = l6;
    i0 = _lib_string_String_fromCodePoint(i0);
    goto Bfunc;
  }
  i0 = 0u;
  i0 = !(i0);
  if (i0) {
    i0 = 1976u;
    i1 = l1;
    i1 = _lib_string_String_fromCharCode(i1);
    i0 = _lib_string_String___concat(i0, i1);
    i1 = 1600u;
    i2 = 258u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = 312u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readString(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
  i1 = 1184u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  i0 = !(i0);
  if (i0) {
    i0 = 1752u;
    i1 = 1600u;
    i2 = 197u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0));
  l1 = i0;
  i0 = 0u;
  l2 = i0;
  L2: 
    i0 = 1u;
    i0 = !(i0);
    if (i0) {goto B1;}
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
    l3 = i0;
    i0 = l3;
    i1 = 32u;
    i0 = (u32)((s32)i0 >= (s32)i1);
    i0 = !(i0);
    if (i0) {
      i0 = 1816u;
      i1 = 1600u;
      i2 = 202u;
      i3 = 12u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = 1184u;
    i2 = 0u;
    i1 = _lib_string_String_charCodeAt(i1, i2);
    i0 = i0 == i1;
    if (i0) {
      i0 = p0;
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i0 = i32_load((&memory), (u64)(i0));
      l4 = i0;
      i0 = l4;
      i1 = 8u;
      i0 += i1;
      i1 = l1;
      i0 += i1;
      i1 = p0;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i1 = i32_load((&memory), (u64)(i1));
      i2 = l1;
      i1 -= i2;
      i2 = 1u;
      i1 -= i2;
      i0 = _lib_string_String_fromUTF8(i0, i1);
      l4 = i0;
      i0 = l2;
      i1 = 0u;
      i0 = i0 == i1;
      if (i0) {
        i0 = l4;
        goto Bfunc;
      }
      i0 = l2;
      i1 = l4;
      i0 = _lib_array_Array_String__push(i0, i1);
      i0 = l2;
      i1 = 312u;
      i0 = _lib_array_Array_String__join(i0, i1);
      goto Bfunc;
    } else {
      i0 = l3;
      i1 = 1192u;
      i2 = 0u;
      i1 = _lib_string_String_charCodeAt(i1, i2);
      i0 = i0 == i1;
      if (i0) {
        i0 = l2;
        i1 = 0u;
        i0 = i0 == i1;
        if (i0) {
          i0 = 0u;
          i1 = 0u;
          i0 = _lib_array_Array_String__constructor(i0, i1);
          l2 = i0;
        }
        i0 = p0;
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i0 = i32_load((&memory), (u64)(i0));
        i1 = l1;
        i2 = 1u;
        i1 += i2;
        i0 = (u32)((s32)i0 > (s32)i1);
        if (i0) {
          i0 = l2;
          i1 = p0;
          i1 = i32_load((&memory), (u64)(i1 + 4));
          i1 = i32_load((&memory), (u64)(i1 + 4));
          i1 = i32_load((&memory), (u64)(i1));
          l4 = i1;
          i1 = l4;
          i2 = 8u;
          i1 += i2;
          i2 = l1;
          i1 += i2;
          i2 = p0;
          i2 = i32_load((&memory), (u64)(i2 + 4));
          i2 = i32_load((&memory), (u64)(i2));
          i3 = l1;
          i2 -= i3;
          i3 = 1u;
          i2 -= i3;
          i1 = _lib_string_String_fromUTF8(i1, i2);
          i0 = _lib_array_Array_String__push(i0, i1);
        }
        i0 = l2;
        i1 = p0;
        i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readEscapedChar(i1);
        i0 = _lib_array_Array_String__push(i0, i1);
        i0 = p0;
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i0 = i32_load((&memory), (u64)(i0));
        l1 = i0;
      }
    }
    goto L2;
  UNREACHABLE;
  B1:;
  i0 = 312u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseKey(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___skipWhitespace(i0);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = p0;
  i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readString(i1);
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___skipWhitespace(i0);
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
  i1 = 1480u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  i0 = !(i0);
  if (i0) {
    i0 = 2040u;
    i1 = 1600u;
    i2 = 160u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
}

static void assembly_index_MatrixDecoder_i32__popObject(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 320u;
    i2 = 1013u;
    i3 = 2u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1));
  l1 = i1;
  i1 = l1;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i2 = 1u;
  i1 -= i2;
  i0 = _lib_array_Array_Array_i32_____get(i0, i1);
  i1 = 1u;
  g16 = i1;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = p0;
  i2 = i32_load((&memory), (u64)(i2 + 12));
  i1 = CALL_INDIRECT(table, u32 (*)(u32), 6, i2, i1);
  i0 = _lib_array_Array_i32__push(i0, i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseObject(u32 p0) {
  u32 l1 = 0, l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(i0);
  i1 = 1496u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 != i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l1 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = l1;
  i0 = assembly_index_MatrixDecoder_i32__pushObject(i0, i1);
  if (i0) {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
    i0 = p0;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___skipWhitespace(i0);
    i0 = 1u;
    l2 = i0;
    L3: 
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(i0);
      i1 = 1504u;
      i2 = 0u;
      i1 = _lib_string_String_charCodeAt(i1, i2);
      i0 = i0 != i1;
      if (i0) {
        i0 = l2;
        i0 = !(i0);
        if (i0) {
          i0 = p0;
          i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
          i1 = 1176u;
          i2 = 0u;
          i1 = _lib_string_String_charCodeAt(i1, i2);
          i0 = i0 == i1;
          i0 = !(i0);
          if (i0) {
            i0 = 1720u;
            i1 = 1600u;
            i2 = 143u;
            i3 = 20u;
            (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
            UNREACHABLE;
          }
        } else {
          i0 = 0u;
          l2 = i0;
        }
        i0 = p0;
        ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseKey(i0);
        i0 = p0;
        i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseValue(i0);
        goto L3;
      }
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
    i1 = 1504u;
    i2 = 0u;
    i1 = _lib_string_String_charCodeAt(i1, i2);
    i0 = i0 == i1;
    i0 = !(i0);
    if (i0) {
      i0 = 2072u;
      i1 = 1600u;
      i2 = 150u;
      i3 = 12u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  assembly_index_MatrixDecoder_i32__popObject(i0);
  i0 = 1u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_i32___push(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l5 = i0;
  i0 = l2;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = l2;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 182u;
      i3 = 42u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = l5;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
  }
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  l6 = i0;
  i0 = l2;
  l7 = i0;
  i0 = p1;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l6;
  i1 = l7;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l9;
  i0 += i1;
  i1 = l8;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_MatrixDecoder_i32__pushArray(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = 1u;
    i32_store((&memory), (u64)(i0 + 4), i1);
  } else {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = 1u;
    i0 = i0 == i1;
    if (i0) {
      i0 = p0;
      i0 = i32_load((&memory), (u64)(i0));
      i1 = 0u;
      i2 = 0u;
      i1 = _lib_array_Array_i32__constructor(i1, i2);
      i0 = _lib_array_Array_Array_i32___push(i0, i1);
      i0 = p0;
      i1 = 2u;
      i32_store((&memory), (u64)(i0 + 4), i1);
    } else {
      UNREACHABLE;
    }
  }
  i0 = 1u;
  FUNC_EPILOGUE;
  return i0;
}

static void assembly_index_MatrixDecoder_i32__popArray(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 1u;
  i0 = i0 == i1;
  if (i0) {
  } else {
    i0 = p0;
    i1 = 1u;
    i32_store((&memory), (u64)(i0 + 4), i1);
  }
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseArray(u32 p0) {
  u32 l1 = 0, l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(i0);
  i1 = 1488u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 != i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l1 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = l1;
  i0 = assembly_index_MatrixDecoder_i32__pushArray(i0, i1);
  if (i0) {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
    i0 = p0;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___skipWhitespace(i0);
    i0 = 1u;
    l2 = i0;
    L3: 
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(i0);
      i1 = 1512u;
      i2 = 0u;
      i1 = _lib_string_String_charCodeAt(i1, i2);
      i0 = i0 != i1;
      if (i0) {
        i0 = l2;
        i0 = !(i0);
        if (i0) {
          i0 = p0;
          i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
          i1 = 1176u;
          i2 = 0u;
          i1 = _lib_string_String_charCodeAt(i1, i2);
          i0 = i0 == i1;
          i0 = !(i0);
          if (i0) {
            i0 = 1720u;
            i1 = 1600u;
            i2 = 176u;
            i3 = 20u;
            (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
            UNREACHABLE;
          }
        } else {
          i0 = 0u;
          l2 = i0;
        }
        i0 = p0;
        i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseValue(i0);
        goto L3;
      }
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
    i1 = 1512u;
    i2 = 0u;
    i1 = _lib_string_String_charCodeAt(i1, i2);
    i0 = i0 == i1;
    i0 = !(i0);
    if (i0) {
      i0 = 2128u;
      i1 = 1600u;
      i2 = 182u;
      i3 = 12u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  assembly_index_MatrixDecoder_i32__popArray(i0);
  i0 = 1u;
  goto Bfunc;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_map_Map_String_String__rehash(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, 
      l10 = 0, l11 = 0, l12 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  f64 d0, d1;
  i0 = p1;
  i1 = 1u;
  i0 += i1;
  l2 = i0;
  i0 = 0u;
  i1 = l2;
  i2 = 4u;
  i1 *= i2;
  i2 = 0u;
  i0 = _lib_arraybuffer_ArrayBuffer_constructor(i0, i1, i2);
  l3 = i0;
  i0 = l2;
  d0 = (f64)(s32)(i0);
  d1 = 2.6666666666666665;
  d0 *= d1;
  i0 = I32_TRUNC_S_F64(d0);
  l4 = i0;
  i0 = 0u;
  i1 = l4;
  i2 = 12u;
  i1 *= i2;
  i2 = 1u;
  i0 = _lib_arraybuffer_ArrayBuffer_constructor(i0, i1, i2);
  l5 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 8u;
  i0 += i1;
  l6 = i0;
  i0 = l6;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 16));
  i2 = 12u;
  i1 *= i2;
  i0 += i1;
  l7 = i0;
  i0 = l5;
  i1 = 8u;
  i0 += i1;
  l8 = i0;
  L3: 
    i0 = l6;
    i1 = l7;
    i0 = i0 != i1;
    if (i0) {
      i0 = l6;
      l9 = i0;
      i0 = l9;
      i0 = i32_load((&memory), (u64)(i0 + 8));
      i1 = 1u;
      i0 &= i1;
      i0 = !(i0);
      if (i0) {
        i0 = l8;
        l10 = i0;
        i0 = l10;
        i1 = l9;
        i1 = i32_load((&memory), (u64)(i1));
        i32_store((&memory), (u64)(i0), i1);
        i0 = l10;
        i1 = l9;
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i32_store((&memory), (u64)(i0 + 4), i1);
        i0 = l9;
        i0 = i32_load((&memory), (u64)(i0));
        l11 = i0;
        i0 = l11;
        i0 = _lib_internal_hash_hashStr(i0);
        goto B7;
        B7:;
        i1 = p1;
        i0 &= i1;
        l11 = i0;
        i0 = l3;
        i1 = l11;
        i2 = 4u;
        i1 *= i2;
        i0 += i1;
        l12 = i0;
        i0 = l10;
        i1 = l12;
        i1 = i32_load((&memory), (u64)(i1 + 8));
        i32_store((&memory), (u64)(i0 + 8), i1);
        i0 = l12;
        i1 = l8;
        i32_store((&memory), (u64)(i0 + 8), i1);
        i0 = l8;
        i1 = 12u;
        i0 += i1;
        l8 = i0;
      }
      i0 = l6;
      i1 = 12u;
      i0 += i1;
      l6 = i0;
      goto L3;
    }
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = l4;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 20));
  i32_store((&memory), (u64)(i0 + 16), i1);
  FUNC_EPILOGUE;
}

static void _lib_map_Map_String_String__set(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  f64 d2, d3;
  i0 = p1;
  l3 = i0;
  i0 = l3;
  i0 = _lib_internal_hash_hashStr(i0);
  goto B0;
  B0:;
  l4 = i0;
  i0 = p0;
  i1 = p1;
  i2 = l4;
  i0 = _lib_map_Map_String_String__find(i0, i1, i2);
  l5 = i0;
  i0 = l5;
  if (i0) {
    i0 = l5;
    i1 = p2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  } else {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 16));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 12));
    i0 = i0 == i1;
    if (i0) {
      i0 = p0;
      i1 = p0;
      i1 = i32_load((&memory), (u64)(i1 + 20));
      i2 = p0;
      i2 = i32_load((&memory), (u64)(i2 + 12));
      d2 = (f64)(s32)(i2);
      d3 = 0.75;
      d2 *= d3;
      i2 = I32_TRUNC_S_F64(d2);
      i1 = (u32)((s32)i1 < (s32)i2);
      if (i1) {
        i1 = p0;
        i1 = i32_load((&memory), (u64)(i1 + 4));
      } else {
        i1 = p0;
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i2 = 1u;
        i1 <<= (i2 & 31);
        i2 = 1u;
        i1 |= i2;
      }
      _lib_map_Map_String_String__rehash(i0, i1);
    }
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 8));
    l3 = i0;
    i0 = l3;
    i1 = 8u;
    i0 += i1;
    i1 = p0;
    i2 = p0;
    i2 = i32_load((&memory), (u64)(i2 + 16));
    l6 = i2;
    i3 = 1u;
    i2 += i3;
    i32_store((&memory), (u64)(i1 + 16), i2);
    i1 = l6;
    i2 = 12u;
    i1 *= i2;
    i0 += i1;
    l5 = i0;
    i0 = l5;
    i1 = p1;
    i32_store((&memory), (u64)(i0), i1);
    i0 = l5;
    i1 = p2;
    i32_store((&memory), (u64)(i0 + 4), i1);
    i0 = p0;
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 20));
    i2 = 1u;
    i1 += i2;
    i32_store((&memory), (u64)(i0 + 20), i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = l4;
    i2 = p0;
    i2 = i32_load((&memory), (u64)(i2 + 4));
    i1 &= i2;
    i2 = 4u;
    i1 *= i2;
    i0 += i1;
    l6 = i0;
    i0 = l5;
    i1 = l6;
    i1 = i32_load((&memory), (u64)(i1 + 8));
    i32_store((&memory), (u64)(i0 + 8), i1);
    i0 = l6;
    i1 = l5;
    i32_store((&memory), (u64)(i0 + 8), i1);
  }
  FUNC_EPILOGUE;
}

static void assembly_index_MatrixDecoder_i32__setString(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 320u;
    i2 = 1020u;
    i3 = 2u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = p1;
  i2 = p2;
  _lib_map_Map_String_String__set(i0, i1, i2);
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseString(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(i0);
  i1 = 1184u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 != i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = p0;
  i2 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readString(i2);
  assembly_index_MatrixDecoder_i32__setString(i0, i1, i2);
  i0 = 1u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readAndAssert(u32 p0, u32 p1) {
  u32 l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = 0u;
  l2 = i0;
  L1: 
    i0 = l2;
    i1 = p1;
    i1 = i32_load((&memory), (u64)(i1));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = p1;
    i1 = l2;
    i0 = _lib_string_String_charCodeAt(i0, i1);
    i1 = p0;
    i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i1);
    i0 = i0 == i1;
    i0 = !(i0);
    if (i0) {
      i0 = 2184u;
      i1 = p1;
      i0 = _lib_string_String___concat(i0, i1);
      i1 = 2208u;
      i0 = _lib_string_String___concat(i0, i1);
      i1 = 1600u;
      i2 = 324u;
      i3 = 12u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l2;
    i1 = 1u;
    i0 += i1;
    l2 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  FUNC_EPILOGUE;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setBoolean(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseBoolean(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(i0);
  i1 = g3;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = g3;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readAndAssert(i0, i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i1 = i32_load((&memory), (u64)(i1 + 8));
    i2 = 0u;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setBoolean(i0, i1, i2);
    i0 = 1u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(i0);
  i1 = g2;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = g2;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readAndAssert(i0, i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i1 = i32_load((&memory), (u64)(i1 + 8));
    i2 = 1u;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setBoolean(i0, i1, i2);
    i0 = 1u;
    goto Bfunc;
  }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setInteger(u32 p0, u32 p1, u64 p2) {
  FUNC_PROLOGUE;
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseNumber(u32 p0) {
  u32 l1 = 0, l2 = 0;
  u64 l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  u64 j0, j1, j2, j3;
  j0 = 0ull;
  l3 = j0;
  j0 = 1ull;
  l4 = j0;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(i0);
  i1 = 2216u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    j0 = 18446744073709551615ull;
    l4 = j0;
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
  }
  i0 = 0u;
  l1 = i0;
  L2: 
    i0 = g5;
    i1 = p0;
    i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(i1);
    i0 = (u32)((s32)i0 <= (s32)i1);
    l2 = i0;
    if (i0) {
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(i0);
      i1 = g6;
      i0 = (u32)((s32)i0 <= (s32)i1);
    } else {
      i0 = l2;
    }
    if (i0) {
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readChar(i0);
      l2 = i0;
      j0 = l3;
      j1 = 10ull;
      j0 *= j1;
      l3 = j0;
      j0 = l3;
      i1 = l2;
      i2 = g5;
      i1 -= i2;
      j1 = (u64)(s64)(s32)(i1);
      j0 += j1;
      l3 = j0;
      i0 = l1;
      i1 = 1u;
      i0 += i1;
      l1 = i0;
      goto L2;
    }
  i0 = l1;
  i1 = 0u;
  i0 = (u32)((s32)i0 > (s32)i1);
  if (i0) {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i1 = i32_load((&memory), (u64)(i1 + 8));
    j2 = l3;
    j3 = l4;
    j2 *= j3;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setInteger(i0, i1, j2);
    i0 = 1u;
    goto Bfunc;
  }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setNull(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseNull(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___peekChar(i0);
  i1 = g4;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = g4;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___readAndAssert(i0, i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i1 = i32_load((&memory), (u64)(i1 + 8));
    ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setNull(i0, i1);
    i0 = 1u;
    goto Bfunc;
  }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseValue(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___skipWhitespace(i0);
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseObject(i0);
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseArray(i0);
  }
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseString(i0);
  }
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseBoolean(i0);
  }
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseNumber(i0);
  }
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseNull(i0);
  }
  l1 = i0;
  i0 = p0;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___skipWhitespace(i0);
  i0 = l1;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___deserialize(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p2;
  if (i0) {
    i0 = p0;
    i1 = p2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  } else {
    i0 = p0;
    i1 = 0u;
    i1 = ___node_modules_assemblyscript_json_assembly_decoder_DecoderState_constructor(i1);
    i32_store((&memory), (u64)(i0 + 4), i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = 0u;
    i32_store((&memory), (u64)(i0), i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = p1;
    i32_store((&memory), (u64)(i0 + 4), i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = 0u;
    i32_store((&memory), (u64)(i0 + 8), i1);
  }
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___parseValue(i0);
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = 2224u;
    i1 = 1600u;
    i2 = 102u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
}

static u32 assembly_index_MatrixDecoder_i32__getResult(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint3_constructor(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4, u32 p5) {
  u32 l6 = 0, l7 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  i0 = p4;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = 1520u;
    p4 = i0;
  }
  i0 = p0;
  if (i0) {
    i0 = p0;
  } else {
    i0 = 24u;
    i0 = _lib_memory_memory_allocate(i0);
  }
  i1 = p1;
  i2 = p2;
  i3 = p3;
  i4 = p4;
  i5 = p5;
  i0 = assembly_index_Constraint_constructor(i0, i1, i2, i3, i4, i5);
  p0 = i0;
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 20), i1);
  i0 = p5;
  i1 = 0u;
  i0 = i0 != i1;
  if (i0) {
    i0 = 0u;
    i1 = 12u;
    i0 = assembly_index_MatrixDecoder_i32__constructor(i0, i1);
    l6 = i0;
    i0 = 0u;
    i1 = l6;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___constructor(i0, i1);
    l7 = i0;
    i0 = l7;
    i1 = p5;
    i1 = assembly_index_stringToUint8Array(i1);
    i2 = 0u;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___deserialize(i0, i1, i2);
    i0 = p0;
    i1 = l6;
    i1 = assembly_index_MatrixDecoder_i32__getResult(i1);
    i32_store((&memory), (u64)(i0 + 20), i1);
  } else {
    i0 = p0;
    i1 = 2272u;
    i32_store((&memory), (u64)(i0 + 20), i1);
  }
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint3_gen(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4) {
  u32 l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0, l11 = 0, l12 = 0, 
      l13 = 0, l14 = 0, l15 = 0, l16 = 0, l17 = 0, l18 = 0, l19 = 0, l20 = 0, 
      l21 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  f64 d0, d1;
  i0 = 9u;
  l5 = i0;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l6 = i0;
  i0 = 1u;
  g16 = i0;
  i0 = p1;
  l7 = i0;
  i0 = l7;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = genShuff;
  i0 = CALL_INDIRECT(table, u32 (*)(u32), 6, i1, i0);
  l7 = i0;
  i0 = 1u;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  L3: 
    i0 = l9;
    i1 = p1;
    l10 = i1;
    i1 = l10;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B2;}
    i0 = p1;
    i1 = l7;
    i2 = l9;
    i1 = _lib_array_Array_i32____get(i1, i2);
    i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
    l10 = i0;
    i0 = l10;
    l11 = i0;
    i0 = l11;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = 4u;
    i0 = (u32)((s32)i0 < (s32)i1);
    l11 = i0;
    if (i0) {
      i0 = p2;
      i1 = 1u;
      i0 = (u32)((s32)i0 > (s32)i1);
    } else {
      i0 = l11;
    }
    if (i0) {
      d0 = _lib_math_NativeMath_random();
      d1 = 0.10000000000000001;
      i0 = d0 < d1;
      i0 = !(i0);
      if (i0) {
        goto B4;
      }
    } else {
      i0 = l10;
      l11 = i0;
      i0 = l11;
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i1 = 16u;
      i0 = (u32)((s32)i0 > (s32)i1);
      if (i0) {
        d0 = _lib_math_NativeMath_random();
        d1 = 0.10000000000000001;
        i0 = d0 < d1;
        i0 = !(i0);
        if (i0) {
          goto B4;
        }
      } else {
        d0 = _lib_math_NativeMath_random();
        i1 = l8;
        d1 = (f64)(s32)(i1);
        i0 = d0 < d1;
        i0 = !(i0);
        if (i0) {
          goto B4;
        }
      }
    }
    i0 = 1u;
    g16 = i0;
    i0 = l10;
    i1 = 10u;
    i0 = assembly_index_arrayMap_PartitionListElement_PathMarker_(i0, i1);
    i1 = l5;
    i0 = CALL_INDIRECT(table, u32 (*)(u32), 6, i1, i0);
    l11 = i0;
    i0 = l11;
    i1 = 0u;
    i0 = i0 == i1;
    if (i0) {
      goto B4;
    }
    i0 = l11;
    l12 = i0;
    i0 = 0u;
    l13 = i0;
    i0 = 0u;
    l14 = i0;
    L18: 
      i0 = l14;
      i1 = l10;
      l15 = i1;
      i1 = l15;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B17;}
      i0 = l10;
      i1 = l14;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 8));
      i0 = !(i0);
      if (i0) {
        i0 = l13;
        i1 = 1u;
        i0 += i1;
        l13 = i0;
      }
      i0 = l14;
      i1 = 1u;
      i0 += i1;
      l14 = i0;
      goto L18;
    UNREACHABLE;
    B17:;
    i0 = l13;
    i1 = l12;
    l14 = i1;
    i1 = l14;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    if (i0) {
      goto B4;
    }
    i0 = 0u;
    l14 = i0;
    i0 = 1u;
    g16 = i0;
    i0 = l10;
    l15 = i0;
    i0 = l15;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = genShuff;
    i0 = CALL_INDIRECT(table, u32 (*)(u32), 6, i1, i0);
    l15 = i0;
    i0 = 0u;
    l16 = i0;
    L27: 
      i0 = l16;
      i1 = l10;
      l17 = i1;
      i1 = l17;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      l17 = i0;
      if (i0) {
        i0 = l14;
        i1 = l12;
        l17 = i1;
        i1 = l17;
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i0 = (u32)((s32)i0 < (s32)i1);
      } else {
        i0 = l17;
      }
      i0 = !(i0);
      if (i0) {goto B26;}
      i0 = l12;
      i1 = l14;
      i0 = _lib_array_Array_Array_Array_i32______get(i0, i1);
      l17 = i0;
      i0 = l17;
      i0 = assembly_index_serializeI32(i0);
      l18 = i0;
      i0 = l18;
      i0 = assembly_index_uint8ArrayToString(i0);
      l19 = i0;
      i0 = l15;
      i1 = l16;
      i0 = _lib_array_Array_i32____get(i0, i1);
      l20 = i0;
      i0 = l10;
      i1 = l20;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 8));
      i1 = 0u;
      i0 = i0 == i1;
      if (i0) {
        i0 = 0u;
        i1 = l10;
        i2 = l20;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1));
        i2 = l10;
        i3 = l20;
        i2 = _lib_array_Array_PartitionListElement____get(i2, i3);
        i2 = i32_load((&memory), (u64)(i2 + 4));
        i3 = l16;
        i4 = 0u;
        i5 = l19;
        i0 = assembly_index_Constraint3_constructor(i0, i1, i2, i3, i4, i5);
        l21 = i0;
        i0 = l10;
        i1 = l20;
        i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
        i1 = l21;
        i32_store((&memory), (u64)(i0 + 8), i1);
        i0 = p0;
        i1 = l10;
        i2 = l20;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = l10;
        i2 = l20;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1));
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i1 = l21;
        i32_store((&memory), (u64)(i0 + 4), i1);
        i0 = l6;
        i1 = l21;
        i0 = _lib_array_Array_Constraint__push(i0, i1);
        i0 = l14;
        i1 = 1u;
        i0 += i1;
        l14 = i0;
      }
      i0 = l16;
      i1 = 1u;
      i0 += i1;
      l16 = i0;
      goto L27;
    UNREACHABLE;
    B26:;
    i0 = l8;
    i1 = 2u;
    i0 *= i1;
    i1 = p2;
    i2 = 1u;
    i1 += i2;
    i0 = I32_DIV_S(i0, i1);
    l8 = i0;
    B4:;
    i0 = l9;
    i1 = 1u;
    i0 += i1;
    l9 = i0;
    goto L3;
  UNREACHABLE;
  B2:;
  i0 = l6;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint4_check(u32 p0, u32 p1, u32 p2, u32 p3) {
  u32 l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  L1: 
    i0 = l5;
    i1 = p0;
    l6 = i1;
    i1 = l6;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = 0u;
    l6 = i0;
    L4: 
      i0 = l6;
      i1 = p0;
      i2 = l5;
      i1 = _lib_array_Array_Array_BoardMatrixElement_____get(i1, i2);
      l7 = i1;
      i1 = l7;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B3;}
      i0 = p0;
      i1 = l5;
      i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
      i1 = l6;
      i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i1 = 0u;
      i0 = i0 != i1;
      l7 = i0;
      if (i0) {
        i0 = p0;
        i1 = l5;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = l6;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i0 = i32_load((&memory), (u64)(i0 + 12));
        i1 = 2280u;
        i0 = assembly_index_streq(i0, i1);
      } else {
        i0 = l7;
      }
      if (i0) {
        i0 = p0;
        i1 = l5;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = l6;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0));
        l7 = i0;
        i0 = p2;
        i1 = l5;
        i0 = _lib_array_Array_Array_i32_____get(i0, i1);
        i1 = l6;
        i0 = _lib_array_Array_i32____get(i0, i1);
        i1 = p2;
        i2 = l5;
        i3 = 1u;
        i2 += i3;
        i1 = _lib_array_Array_Array_i32_____get(i1, i2);
        i2 = l6;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 += i1;
        i1 = p3;
        i2 = l5;
        i1 = _lib_array_Array_Array_i32_____get(i1, i2);
        i2 = l6;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 += i1;
        i1 = p3;
        i2 = l5;
        i1 = _lib_array_Array_Array_i32_____get(i1, i2);
        i2 = l6;
        i3 = 1u;
        i2 += i3;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 += i1;
        l8 = i0;
        i0 = p0;
        i1 = l5;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = l6;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i0 = i32_load((&memory), (u64)(i0 + 20));
        i1 = l8;
        i0 = i0 != i1;
        if (i0) {
          i0 = l4;
          i1 = p0;
          i2 = l5;
          i1 = _lib_array_Array_Array_BoardMatrixElement_____get(i1, i2);
          i2 = l6;
          i1 = _lib_array_Array_BoardMatrixElement____get(i1, i2);
          i1 = i32_load((&memory), (u64)(i1 + 4));
          i0 = _lib_array_Array_Constraint__push(i0, i1);
        }
      }
      i0 = l6;
      i1 = 1u;
      i0 += i1;
      l6 = i0;
      goto L4;
    UNREACHABLE;
    B3:;
    i0 = l5;
    i1 = 1u;
    i0 += i1;
    l5 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l4;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint4_constructor(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4, u32 p5) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  i0 = p4;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = 2280u;
    p4 = i0;
  }
  i0 = p0;
  if (i0) {
    i0 = p0;
  } else {
    i0 = 24u;
    i0 = _lib_memory_memory_allocate(i0);
  }
  i1 = p1;
  i2 = p2;
  i3 = p3;
  i4 = p4;
  i5 = p5;
  i0 = assembly_index_Constraint_constructor(i0, i1, i2, i3, i4, i5);
  p0 = i0;
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 20), i1);
  i0 = p0;
  i1 = p5;
  i2 = 0u;
  i1 = _lib_string_parseI32(i1, i2);
  i32_store((&memory), (u64)(i0 + 20), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint4_gen(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4) {
  u32 l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0, l11 = 0, l12 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  f64 d0, d1;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l5 = i0;
  i0 = 0u;
  l6 = i0;
  L1: 
    i0 = l6;
    i1 = p0;
    l7 = i1;
    i1 = l7;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = 0u;
    l7 = i0;
    L4: 
      i0 = l7;
      i1 = p0;
      i2 = l6;
      i1 = _lib_array_Array_Array_BoardMatrixElement_____get(i1, i2);
      l8 = i1;
      i1 = l8;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B3;}
      d0 = _lib_math_NativeMath_random();
      d1 = 0.10000000000000001;
      i0 = d0 < d1;
      l8 = i0;
      if (i0) {
        i0 = p0;
        i1 = l6;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = l7;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i1 = 0u;
        i0 = i0 == i1;
      } else {
        i0 = l8;
      }
      if (i0) {
        i0 = p0;
        i1 = l6;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = l7;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0));
        l8 = i0;
        i0 = p3;
        i1 = l6;
        i0 = _lib_array_Array_Array_i32_____get(i0, i1);
        i1 = l7;
        i0 = _lib_array_Array_i32____get(i0, i1);
        i1 = p3;
        i2 = l6;
        i3 = 1u;
        i2 += i3;
        i1 = _lib_array_Array_Array_i32_____get(i1, i2);
        i2 = l7;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 += i1;
        i1 = p4;
        i2 = l6;
        i1 = _lib_array_Array_Array_i32_____get(i1, i2);
        i2 = l7;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 += i1;
        i1 = p4;
        i2 = l6;
        i1 = _lib_array_Array_Array_i32_____get(i1, i2);
        i2 = l7;
        i3 = 1u;
        i2 += i3;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 += i1;
        l9 = i0;
        i0 = l9;
        i1 = 0u;
        i0 = i0 != i1;
        if (i0) {
          i0 = 0u;
          i1 = l7;
          i2 = l6;
          i3 = l8;
          i4 = 0u;
          i5 = l9;
          i5 = _lib_number_I32_toString(i5);
          i0 = assembly_index_Constraint4_constructor(i0, i1, i2, i3, i4, i5);
          l10 = i0;
          i0 = p0;
          i1 = l6;
          i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
          i1 = l7;
          i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
          i1 = l10;
          i32_store((&memory), (u64)(i0 + 4), i1);
          i0 = 0u;
          l11 = i0;
          L10: 
            i0 = l11;
            i1 = p1;
            i2 = l8;
            i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
            l12 = i1;
            i1 = l12;
            i1 = i32_load((&memory), (u64)(i1 + 4));
            i0 = (u32)((s32)i0 < (s32)i1);
            i0 = !(i0);
            if (i0) {goto B9;}
            i0 = p1;
            i1 = l8;
            i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
            i1 = l11;
            i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
            i0 = i32_load((&memory), (u64)(i0));
            i1 = l7;
            i0 = i0 == i1;
            l12 = i0;
            if (i0) {
              i0 = p1;
              i1 = l8;
              i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
              i1 = l11;
              i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
              i0 = i32_load((&memory), (u64)(i0 + 4));
              i1 = l6;
              i0 = i0 == i1;
            } else {
              i0 = l12;
            }
            if (i0) {
              i0 = p1;
              i1 = l8;
              i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
              i1 = l11;
              i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
              i1 = l10;
              i32_store((&memory), (u64)(i0 + 8), i1);
            }
            i0 = l11;
            i1 = 1u;
            i0 += i1;
            l11 = i0;
            goto L10;
          UNREACHABLE;
          B9:;
          i0 = l5;
          i1 = l10;
          i0 = _lib_array_Array_Constraint__push(i0, i1);
        }
      }
      i0 = l7;
      i1 = 1u;
      i0 += i1;
      l7 = i0;
      goto L4;
    UNREACHABLE;
    B3:;
    i0 = l6;
    i1 = 1u;
    i0 += i1;
    l6 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint5_check(u32 p0, u32 p1, u32 p2, u32 p3) {
  u32 l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0, l11 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  L1: 
    i0 = l5;
    i1 = p1;
    l6 = i1;
    i1 = l6;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = 0u;
    l6 = i0;
    i0 = 0u;
    l7 = i0;
    i0 = 0u;
    i1 = 0u;
    i0 = _lib_array_Array_Constraint__constructor(i0, i1);
    l8 = i0;
    i0 = 0u;
    l9 = i0;
    L5: 
      i0 = l9;
      i1 = p1;
      i2 = l5;
      i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
      l10 = i1;
      i1 = l10;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B4;}
      i0 = p1;
      i1 = l5;
      i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
      i1 = l9;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 8));
      l10 = i0;
      i0 = l10;
      i1 = 0u;
      i0 = i0 != i1;
      l11 = i0;
      if (i0) {
        i0 = l10;
        i0 = i32_load((&memory), (u64)(i0 + 12));
        i1 = 2312u;
        i0 = assembly_index_streq(i0, i1);
      } else {
        i0 = l11;
      }
      if (i0) {
        i0 = l7;
        i1 = 1u;
        i0 += i1;
        l7 = i0;
        i0 = l8;
        i1 = l10;
        i0 = _lib_array_Array_Constraint__push(i0, i1);
      }
      i0 = p1;
      i1 = l5;
      i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
      i1 = l9;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0));
      i1 = 1u;
      i0 -= i1;
      i1 = 0u;
      i0 = (u32)((s32)i0 < (s32)i1);
      l11 = i0;
      if (i0) {
        i0 = l11;
      } else {
        i0 = p0;
        i1 = p1;
        i2 = l5;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = p1;
        i2 = l5;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1));
        i2 = 1u;
        i1 -= i2;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0));
        i1 = l5;
        i0 = i0 != i1;
      }
      if (i0) {
        i0 = l6;
        i1 = 1u;
        i0 += i1;
        l6 = i0;
      }
      i0 = p1;
      i1 = l5;
      i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
      i1 = l9;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0));
      i1 = 1u;
      i0 += i1;
      i1 = p0;
      i2 = p1;
      i3 = l5;
      i2 = _lib_array_Array_Array_PartitionListElement_____get(i2, i3);
      i3 = l9;
      i2 = _lib_array_Array_PartitionListElement____get(i2, i3);
      i2 = i32_load((&memory), (u64)(i2 + 4));
      i1 = _lib_array_Array_Array_BoardMatrixElement_____get(i1, i2);
      l11 = i1;
      i1 = l11;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 >= (s32)i1);
      l11 = i0;
      if (i0) {
        i0 = l11;
      } else {
        i0 = p0;
        i1 = p1;
        i2 = l5;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = p1;
        i2 = l5;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1));
        i2 = 1u;
        i1 += i2;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0));
        i1 = l5;
        i0 = i0 != i1;
      }
      if (i0) {
        i0 = l6;
        i1 = 1u;
        i0 += i1;
        l6 = i0;
      }
      i0 = p1;
      i1 = l5;
      i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
      i1 = l9;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i1 = 1u;
      i0 -= i1;
      i1 = 0u;
      i0 = (u32)((s32)i0 < (s32)i1);
      l11 = i0;
      if (i0) {
        i0 = l11;
      } else {
        i0 = p0;
        i1 = p1;
        i2 = l5;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i2 = 1u;
        i1 -= i2;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = p1;
        i2 = l5;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1));
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0));
        i1 = l5;
        i0 = i0 != i1;
      }
      if (i0) {
        i0 = l6;
        i1 = 1u;
        i0 += i1;
        l6 = i0;
      }
      i0 = p1;
      i1 = l5;
      i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
      i1 = l9;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i1 = 1u;
      i0 += i1;
      i1 = p0;
      l11 = i1;
      i1 = l11;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 >= (s32)i1);
      l11 = i0;
      if (i0) {
        i0 = l11;
      } else {
        i0 = p0;
        i1 = p1;
        i2 = l5;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i2 = 1u;
        i1 += i2;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = p1;
        i2 = l5;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1));
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0));
        i1 = l5;
        i0 = i0 != i1;
      }
      if (i0) {
        i0 = l6;
        i1 = 1u;
        i0 += i1;
        l6 = i0;
      }
      i0 = l9;
      i1 = 1u;
      i0 += i1;
      l9 = i0;
      goto L5;
    UNREACHABLE;
    B4:;
    i0 = l7;
    i1 = 0u;
    i0 = i0 != i1;
    l9 = i0;
    if (i0) {
      i0 = l6;
      i1 = 2u;
      i0 += i1;
      i1 = 3u;
      i0 = I32_REM_S(i0, i1);
      i1 = 1u;
      i0 += i1;
      i1 = l7;
      i0 = i0 != i1;
    } else {
      i0 = l9;
    }
    if (i0) {
      i0 = l4;
      i1 = l8;
      i0 = _lib_array_Array_Constraint__concat(i0, i1);
      l4 = i0;
    }
    i0 = l5;
    i1 = 1u;
    i0 += i1;
    l5 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l4;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint5_constructor(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4, u32 p5) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  i0 = p4;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = 2312u;
    p4 = i0;
  }
  i0 = p0;
  if (i0) {
    i0 = p0;
  } else {
    i0 = 20u;
    i0 = _lib_memory_memory_allocate(i0);
  }
  i1 = p1;
  i2 = p2;
  i3 = p3;
  i4 = p4;
  i5 = p5;
  i0 = assembly_index_Constraint_constructor(i0, i1, i2, i3, i4, i5);
  p0 = i0;
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint5_gen(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4) {
  u32 l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0, l11 = 0, l12 = 0, 
      l13 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  f64 d0, d1, d2;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l5 = i0;
  i0 = 0u;
  l6 = i0;
  L1: 
    i0 = l6;
    i1 = p1;
    l7 = i1;
    i1 = l7;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = 0u;
    l7 = i0;
    i0 = 0u;
    l8 = i0;
    i0 = 0u;
    l9 = i0;
    L5: 
      i0 = l9;
      i1 = p1;
      i2 = l6;
      i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
      l10 = i1;
      i1 = l10;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B4;}
      i0 = p1;
      i1 = l6;
      i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
      i1 = l9;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 8));
      l10 = i0;
      i0 = l10;
      i1 = 0u;
      i0 = i0 == i1;
      if (i0) {
        i0 = l8;
        i1 = 1u;
        i0 += i1;
        l8 = i0;
      }
      i0 = p1;
      i1 = l6;
      i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
      i1 = l9;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0));
      i1 = 1u;
      i0 -= i1;
      i1 = 0u;
      i0 = (u32)((s32)i0 < (s32)i1);
      l11 = i0;
      if (i0) {
        i0 = l11;
      } else {
        i0 = p0;
        i1 = p1;
        i2 = l6;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = p1;
        i2 = l6;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1));
        i2 = 1u;
        i1 -= i2;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0));
        i1 = l6;
        i0 = i0 != i1;
      }
      if (i0) {
        i0 = l7;
        i1 = 1u;
        i0 += i1;
        l7 = i0;
      }
      i0 = p1;
      i1 = l6;
      i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
      i1 = l9;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0));
      i1 = 1u;
      i0 += i1;
      i1 = p0;
      i2 = p1;
      i3 = l6;
      i2 = _lib_array_Array_Array_PartitionListElement_____get(i2, i3);
      i3 = l9;
      i2 = _lib_array_Array_PartitionListElement____get(i2, i3);
      i2 = i32_load((&memory), (u64)(i2 + 4));
      i1 = _lib_array_Array_Array_BoardMatrixElement_____get(i1, i2);
      l11 = i1;
      i1 = l11;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 >= (s32)i1);
      l11 = i0;
      if (i0) {
        i0 = l11;
      } else {
        i0 = p0;
        i1 = p1;
        i2 = l6;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = p1;
        i2 = l6;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1));
        i2 = 1u;
        i1 += i2;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0));
        i1 = l6;
        i0 = i0 != i1;
      }
      if (i0) {
        i0 = l7;
        i1 = 1u;
        i0 += i1;
        l7 = i0;
      }
      i0 = p1;
      i1 = l6;
      i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
      i1 = l9;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i1 = 1u;
      i0 -= i1;
      i1 = 0u;
      i0 = (u32)((s32)i0 < (s32)i1);
      l11 = i0;
      if (i0) {
        i0 = l11;
      } else {
        i0 = p0;
        i1 = p1;
        i2 = l6;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i2 = 1u;
        i1 -= i2;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = p1;
        i2 = l6;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1));
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0));
        i1 = l6;
        i0 = i0 != i1;
      }
      if (i0) {
        i0 = l7;
        i1 = 1u;
        i0 += i1;
        l7 = i0;
      }
      i0 = p1;
      i1 = l6;
      i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
      i1 = l9;
      i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i1 = 1u;
      i0 += i1;
      i1 = p0;
      l11 = i1;
      i1 = l11;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 >= (s32)i1);
      l11 = i0;
      if (i0) {
        i0 = l11;
      } else {
        i0 = p0;
        i1 = p1;
        i2 = l6;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1 + 4));
        i2 = 1u;
        i1 += i2;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = p1;
        i2 = l6;
        i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
        i2 = l9;
        i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
        i1 = i32_load((&memory), (u64)(i1));
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0));
        i1 = l6;
        i0 = i0 != i1;
      }
      if (i0) {
        i0 = l7;
        i1 = 1u;
        i0 += i1;
        l7 = i0;
      }
      i0 = l9;
      i1 = 1u;
      i0 += i1;
      l9 = i0;
      goto L5;
    UNREACHABLE;
    B4:;
    i0 = l8;
    i1 = 3u;
    i0 = (u32)((s32)i0 > (s32)i1);
    l9 = i0;
    if (i0) {
      i0 = l8;
      i1 = 12u;
      i0 = (u32)((s32)i0 > (s32)i1);
      l9 = i0;
      if (i0) {
        i0 = l9;
      } else {
        d0 = _lib_math_NativeMath_random();
        i1 = l8;
        i2 = 3u;
        i1 -= i2;
        i2 = 12u;
        i1 = I32_DIV_S(i1, i2);
        d1 = (f64)(s32)(i1);
        d2 = 0.20000000000000001;
        d1 += d2;
        i0 = d0 < d1;
      }
    } else {
      i0 = l9;
    }
    if (i0) {
      i0 = 1u;
      g16 = i0;
      i0 = p1;
      i1 = l6;
      i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
      l9 = i0;
      i0 = l9;
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i1 = genShuff;
      i0 = CALL_INDIRECT(table, u32 (*)(u32), 6, i1, i0);
      l9 = i0;
      i0 = l7;
      i1 = 2u;
      i0 += i1;
      i1 = 3u;
      i0 = I32_REM_S(i0, i1);
      i1 = 1u;
      i0 += i1;
      l10 = i0;
      i0 = 0u;
      l11 = i0;
      L25: 
        i0 = l10;
        i1 = 0u;
        i0 = (u32)((s32)i0 > (s32)i1);
        if (i0) {
          i0 = p1;
          i1 = l6;
          i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
          i1 = l9;
          i2 = l11;
          i1 = _lib_array_Array_i32____get(i1, i2);
          i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
          l12 = i0;
          i0 = l12;
          i0 = i32_load((&memory), (u64)(i0 + 8));
          i1 = 0u;
          i0 = i0 == i1;
          if (i0) {
            i0 = 0u;
            i1 = l12;
            i1 = i32_load((&memory), (u64)(i1));
            i2 = l12;
            i2 = i32_load((&memory), (u64)(i2 + 4));
            i3 = 0u;
            i4 = 0u;
            i5 = 312u;
            i0 = assembly_index_Constraint5_constructor(i0, i1, i2, i3, i4, i5);
            l13 = i0;
            i0 = l12;
            i1 = l13;
            i32_store((&memory), (u64)(i0 + 8), i1);
            i0 = p0;
            i1 = l12;
            i1 = i32_load((&memory), (u64)(i1 + 4));
            i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
            i1 = l12;
            i1 = i32_load((&memory), (u64)(i1));
            i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
            i1 = l13;
            i32_store((&memory), (u64)(i0 + 4), i1);
            i0 = l5;
            i1 = l13;
            i0 = _lib_array_Array_Constraint__push(i0, i1);
            i0 = l10;
            i1 = 1u;
            i0 -= i1;
            l10 = i0;
          }
          i0 = l11;
          i1 = 1u;
          i0 += i1;
          l11 = i0;
          goto L25;
        }
    }
    i0 = l6;
    i1 = 1u;
    i0 += i1;
    l6 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint6_check(u32 p0, u32 p1, u32 p2, u32 p3) {
  u32 l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  L1: 
    i0 = l5;
    i1 = p0;
    l6 = i1;
    i1 = l6;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = 0u;
    l6 = i0;
    L4: 
      i0 = l6;
      i1 = p0;
      i2 = l5;
      i1 = _lib_array_Array_Array_BoardMatrixElement_____get(i1, i2);
      l7 = i1;
      i1 = l7;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B3;}
      i0 = p0;
      i1 = l5;
      i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
      i1 = l6;
      i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i1 = 0u;
      i0 = i0 != i1;
      l7 = i0;
      if (i0) {
        i0 = p0;
        i1 = l5;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = l6;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i0 = i32_load((&memory), (u64)(i0 + 12));
        i1 = 2344u;
        i0 = assembly_index_streq(i0, i1);
      } else {
        i0 = l7;
      }
      if (i0) {
        i0 = p0;
        i1 = l5;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = l6;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0));
        l7 = i0;
        i0 = p2;
        i1 = l5;
        i0 = _lib_array_Array_Array_i32_____get(i0, i1);
        i1 = l6;
        i0 = _lib_array_Array_i32____get(i0, i1);
        i1 = p2;
        i2 = l5;
        i3 = 1u;
        i2 += i3;
        i1 = _lib_array_Array_Array_i32_____get(i1, i2);
        i2 = l6;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 += i1;
        i1 = p3;
        i2 = l5;
        i1 = _lib_array_Array_Array_i32_____get(i1, i2);
        i2 = l6;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 += i1;
        i1 = p3;
        i2 = l5;
        i1 = _lib_array_Array_Array_i32_____get(i1, i2);
        i2 = l6;
        i3 = 1u;
        i2 += i3;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 += i1;
        l8 = i0;
        i0 = l8;
        i1 = 0u;
        i0 = i0 != i1;
        if (i0) {
          i0 = l4;
          i1 = p0;
          i2 = l5;
          i1 = _lib_array_Array_Array_BoardMatrixElement_____get(i1, i2);
          i2 = l6;
          i1 = _lib_array_Array_BoardMatrixElement____get(i1, i2);
          i1 = i32_load((&memory), (u64)(i1 + 4));
          i0 = _lib_array_Array_Constraint__push(i0, i1);
        }
      }
      i0 = l6;
      i1 = 1u;
      i0 += i1;
      l6 = i0;
      goto L4;
    UNREACHABLE;
    B3:;
    i0 = l5;
    i1 = 1u;
    i0 += i1;
    l5 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l4;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint6_constructor(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4, u32 p5) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  i0 = p4;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = 2344u;
    p4 = i0;
  }
  i0 = p0;
  if (i0) {
    i0 = p0;
  } else {
    i0 = 20u;
    i0 = _lib_memory_memory_allocate(i0);
  }
  i1 = p1;
  i2 = p2;
  i3 = p3;
  i4 = p4;
  i5 = p5;
  i0 = assembly_index_Constraint_constructor(i0, i1, i2, i3, i4, i5);
  p0 = i0;
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_Constraint6_gen(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4) {
  u32 l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0, l10 = 0, l11 = 0, l12 = 0;
  f64 l13 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  f64 d0, d1, d3, d4;
  i0 = 0u;
  i1 = 0u;
  i0 = _lib_array_Array_Constraint__constructor(i0, i1);
  l5 = i0;
  i0 = 0u;
  l6 = i0;
  L1: 
    i0 = l6;
    i1 = p0;
    l7 = i1;
    i1 = l7;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = 0u;
    l7 = i0;
    L4: 
      i0 = l7;
      i1 = p0;
      i2 = l6;
      i1 = _lib_array_Array_Array_BoardMatrixElement_____get(i1, i2);
      l8 = i1;
      i1 = l8;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B3;}
      d0 = _lib_math_NativeMath_random();
      d1 = 0.20000000000000001;
      i0 = d0 < d1;
      l8 = i0;
      if (i0) {
        i0 = p0;
        i1 = l6;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = l7;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i1 = 0u;
        i0 = i0 == i1;
      } else {
        i0 = l8;
      }
      if (i0) {
        i0 = p0;
        i1 = l6;
        i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
        i1 = l7;
        i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
        i0 = i32_load((&memory), (u64)(i0));
        l8 = i0;
        i0 = p3;
        i1 = l6;
        i0 = _lib_array_Array_Array_i32_____get(i0, i1);
        i1 = l7;
        i0 = _lib_array_Array_i32____get(i0, i1);
        i1 = p3;
        i2 = l6;
        i3 = 1u;
        i2 += i3;
        i1 = _lib_array_Array_Array_i32_____get(i1, i2);
        i2 = l7;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 += i1;
        i1 = p4;
        i2 = l6;
        i1 = _lib_array_Array_Array_i32_____get(i1, i2);
        i2 = l7;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 += i1;
        i1 = p4;
        i2 = l6;
        i1 = _lib_array_Array_Array_i32_____get(i1, i2);
        i2 = l7;
        i3 = 1u;
        i2 += i3;
        i1 = _lib_array_Array_i32____get(i1, i2);
        i0 += i1;
        l9 = i0;
        i0 = l9;
        i1 = 0u;
        i0 = i0 == i1;
        if (i0) {
          i0 = 2376u;
          (*Z_indexZ_consoleZ2ElogSZ_vi)(i0);
          i0 = 0u;
          i1 = l7;
          i2 = l6;
          d3 = _lib_math_NativeMath_random();
          d4 = 3;
          d3 *= d4;
          l13 = d3;
          d3 = l13;
          d3 = floor(d3);
          i3 = I32_TRUNC_S_F64(d3);
          i4 = 0u;
          i5 = 312u;
          i0 = assembly_index_Constraint6_constructor(i0, i1, i2, i3, i4, i5);
          l10 = i0;
          i0 = p0;
          i1 = l6;
          i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
          i1 = l7;
          i0 = _lib_array_Array_BoardMatrixElement____get(i0, i1);
          i1 = l10;
          i32_store((&memory), (u64)(i0 + 4), i1);
          i0 = 0u;
          l11 = i0;
          L11: 
            i0 = l11;
            i1 = p1;
            i2 = l8;
            i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
            l12 = i1;
            i1 = l12;
            i1 = i32_load((&memory), (u64)(i1 + 4));
            i0 = (u32)((s32)i0 < (s32)i1);
            i0 = !(i0);
            if (i0) {goto B10;}
            i0 = p1;
            i1 = l8;
            i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
            i1 = l11;
            i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
            i0 = i32_load((&memory), (u64)(i0));
            i1 = l7;
            i0 = i0 == i1;
            l12 = i0;
            if (i0) {
              i0 = p1;
              i1 = l8;
              i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
              i1 = l11;
              i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
              i0 = i32_load((&memory), (u64)(i0 + 4));
              i1 = l6;
              i0 = i0 == i1;
            } else {
              i0 = l12;
            }
            if (i0) {
              i0 = p1;
              i1 = l8;
              i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
              i1 = l11;
              i0 = _lib_array_Array_PartitionListElement____get(i0, i1);
              i1 = l10;
              i32_store((&memory), (u64)(i0 + 8), i1);
            }
            i0 = l11;
            i1 = 1u;
            i0 += i1;
            l11 = i0;
            goto L11;
          UNREACHABLE;
          B10:;
          i0 = l5;
          i1 = l10;
          i0 = _lib_array_Array_Constraint__push(i0, i1);
        }
      }
      i0 = l7;
      i1 = 1u;
      i0 += i1;
      l7 = i0;
      goto L4;
    UNREACHABLE;
    B3:;
    i0 = l6;
    i1 = 1u;
    i0 += i1;
    l6 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_checkAll(u32 p0, u32 p1, u32 p2, u32 p3) {
  u32 l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = p0;
  i1 = p1;
  i2 = p2;
  i3 = p3;
  i0 = assembly_index_Constraint1_check(i0, i1, i2, i3);
  l4 = i0;
  i0 = l4;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l4 = i0;
  i0 = l4;
  i1 = p0;
  i2 = p1;
  i3 = p2;
  i4 = p3;
  i1 = assembly_index_Constraint2_check(i1, i2, i3, i4);
  l5 = i1;
  i1 = l5;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i0 += i1;
  l4 = i0;
  i0 = l4;
  i1 = p0;
  i2 = p1;
  i3 = p2;
  i4 = p3;
  i1 = assembly_index_Constraint3_check(i1, i2, i3, i4);
  l5 = i1;
  i1 = l5;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i0 += i1;
  l4 = i0;
  i0 = l4;
  i1 = p0;
  i2 = p1;
  i3 = p2;
  i4 = p3;
  i1 = assembly_index_Constraint4_check(i1, i2, i3, i4);
  l5 = i1;
  i1 = l5;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i0 += i1;
  l4 = i0;
  i0 = l4;
  i1 = p0;
  i2 = p1;
  i3 = p2;
  i4 = p3;
  i1 = assembly_index_Constraint5_check(i1, i2, i3, i4);
  l5 = i1;
  i1 = l5;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i0 += i1;
  l4 = i0;
  i0 = l4;
  i1 = p0;
  i2 = p1;
  i3 = p2;
  i4 = p3;
  i1 = assembly_index_Constraint6_check(i1, i2, i3, i4);
  l5 = i1;
  i1 = l5;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i0 += i1;
  l4 = i0;
  i0 = l4;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_State_constructor(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p2;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_State_create(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 0u;
  i1 = p0;
  i2 = p1;
  i0 = assembly_index_State_constructor(i0, i1, i2);
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_genAll(u32 p0, u32 p1, u32 p2, u32 p3, u32 p4, u32 p5, u32 p6, u32 p7, 
    u32 p8) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4;
  i0 = p3;
  i1 = 0u;
  i0 = i0 != i1;
  if (i0) {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i2 = 3u;
    i3 = p1;
    i4 = p2;
    i0 = assembly_index_Constraint1_gen(i0, i1, i2, i3, i4);
  }
  i0 = p4;
  i1 = 0u;
  i0 = i0 != i1;
  if (i0) {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i2 = 3u;
    i3 = p1;
    i4 = p2;
    i0 = assembly_index_Constraint2_gen(i0, i1, i2, i3, i4);
  }
  i0 = p5;
  i1 = 0u;
  i0 = i0 != i1;
  if (i0) {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i2 = 3u;
    i3 = p1;
    i4 = p2;
    i0 = assembly_index_Constraint3_gen(i0, i1, i2, i3, i4);
  }
  i0 = p6;
  i1 = 0u;
  i0 = i0 != i1;
  if (i0) {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i2 = 3u;
    i3 = p1;
    i4 = p2;
    i0 = assembly_index_Constraint4_gen(i0, i1, i2, i3, i4);
  }
  i0 = p7;
  i1 = 0u;
  i0 = i0 != i1;
  if (i0) {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i2 = 3u;
    i3 = p1;
    i4 = p2;
    i0 = assembly_index_Constraint5_gen(i0, i1, i2, i3, i4);
  }
  i0 = p8;
  i1 = 0u;
  i0 = i0 != i1;
  if (i0) {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i2 = 3u;
    i3 = p1;
    i4 = p2;
    i0 = assembly_index_Constraint6_gen(i0, i1, i2, i3, i4);
  }
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_BoardMatrixElement___constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_MatrixDecoder_BoardMatrixElement__constructor(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  if (i0) {
    i0 = p0;
  } else {
    i0 = 16u;
    i0 = _lib_memory_memory_allocate(i0);
  }
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_constructor(i0);
  p0 = i0;
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = 0u;
  i2 = 0u;
  i1 = _lib_array_Array_Array_BoardMatrixElement___constructor(i1, i2);
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_decodeConstraint(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3, i4, i5;
  i0 = p0;
  i1 = 1912u;
  i0 = _lib_map_Map_String_String__get(i0, i1);
  l1 = i0;
  i0 = l1;
  i1 = 0u;
  i0 = i0 == i1;
  l2 = i0;
  if (i0) {
    i0 = l2;
  } else {
    i0 = l1;
    i1 = 40u;
    i0 = assembly_index_streq(i0, i1);
  }
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = p0;
  i1 = 2408u;
  i0 = _lib_map_Map_String_String__get(i0, i1);
  l2 = i0;
  i0 = p0;
  i1 = 2424u;
  i0 = _lib_map_Map_String_String__get(i0, i1);
  l3 = i0;
  i0 = p0;
  i1 = 2440u;
  i0 = _lib_map_Map_String_String__get(i0, i1);
  l4 = i0;
  i0 = p0;
  i1 = 2480u;
  i0 = _lib_map_Map_String_String__get(i0, i1);
  l5 = i0;
  i0 = l2;
  i1 = 0u;
  i0 = i0 == i1;
  l6 = i0;
  if (i0) {
    i0 = l6;
  } else {
    i0 = l3;
    i1 = 0u;
    i0 = i0 == i1;
  }
  l6 = i0;
  if (i0) {
    i0 = l6;
  } else {
    i0 = l4;
    i1 = 0u;
    i0 = i0 == i1;
  }
  if (i0) {
    i0 = 2520u;
    (*Z_indexZ_consoleZ2ElogSZ_vi)(i0);
    UNREACHABLE;
  }
  i0 = l2;
  i1 = 0u;
  i0 = _lib_string_parseI32(i0, i1);
  l6 = i0;
  i0 = l3;
  i1 = 0u;
  i0 = _lib_string_parseI32(i0, i1);
  l7 = i0;
  i0 = l4;
  i1 = 0u;
  i0 = _lib_string_parseI32(i0, i1);
  l8 = i0;
  i0 = l1;
  i1 = 360u;
  i0 = assembly_index_streq(i0, i1);
  if (i0) {
    i0 = 0u;
    i1 = l6;
    i2 = l7;
    i3 = l8;
    i4 = 0u;
    i5 = l5;
    i0 = assembly_index_Constraint1_constructor(i0, i1, i2, i3, i4, i5);
    goto Bfunc;
  } else {
    i0 = l1;
    i1 = 552u;
    i0 = assembly_index_streq(i0, i1);
    if (i0) {
      i0 = 0u;
      i1 = l6;
      i2 = l7;
      i3 = l8;
      i4 = 0u;
      i5 = l5;
      i0 = assembly_index_Constraint2_constructor(i0, i1, i2, i3, i4, i5);
      goto Bfunc;
    } else {
      i0 = l1;
      i1 = 1520u;
      i0 = assembly_index_streq(i0, i1);
      if (i0) {
        i0 = 0u;
        i1 = l6;
        i2 = l7;
        i3 = l8;
        i4 = 0u;
        i5 = l5;
        i0 = assembly_index_Constraint3_constructor(i0, i1, i2, i3, i4, i5);
        goto Bfunc;
      } else {
        i0 = l1;
        i1 = 2280u;
        i0 = assembly_index_streq(i0, i1);
        if (i0) {
          i0 = 0u;
          i1 = l6;
          i2 = l7;
          i3 = l8;
          i4 = 0u;
          i5 = l5;
          i0 = assembly_index_Constraint4_constructor(i0, i1, i2, i3, i4, i5);
          goto Bfunc;
        } else {
          i0 = l1;
          i1 = 2312u;
          i0 = assembly_index_streq(i0, i1);
          if (i0) {
            i0 = 0u;
            i1 = l6;
            i2 = l7;
            i3 = l8;
            i4 = 0u;
            i5 = l5;
            i0 = assembly_index_Constraint5_constructor(i0, i1, i2, i3, i4, i5);
            goto Bfunc;
          } else {
            i0 = l1;
            i1 = 2344u;
            i0 = assembly_index_streq(i0, i1);
            if (i0) {
              i0 = 0u;
              i1 = l6;
              i2 = l7;
              i3 = l8;
              i4 = 0u;
              i5 = l5;
              i0 = assembly_index_Constraint6_constructor(i0, i1, i2, i3, i4, i5);
              goto Bfunc;
            }
          }
        }
      }
    }
  }
  i0 = 2544u;
  (*Z_indexZ_consoleZ2ElogSZ_vi)(i0);
  i0 = l1;
  (*Z_indexZ_consoleZ2ElogSZ_vi)(i0);
  UNREACHABLE;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_decodeBoardMatrixElement(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i1 = 2400u;
  i0 = _lib_map_Map_String_String__get(i0, i1);
  l1 = i0;
  i0 = p0;
  i0 = assembly_index_decodeConstraint(i0);
  l2 = i0;
  i0 = l1;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    UNREACHABLE;
  }
  i0 = l1;
  i1 = 0u;
  i0 = _lib_string_parseI32(i0, i1);
  l3 = i0;
  i0 = 0u;
  i1 = l3;
  i2 = l2;
  i0 = assembly_index_BoardMatrixElement_constructor(i0, i1, i2);
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___constructor(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i1 = i32_load((&memory), (u64)(i1 + 4));
  l1 = i1;
  i1 = l1;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = 0u;
  i1 >>= (i2 & 31);
  i0 = (u32)((s32)i0 >= (s32)i1);
  if (i0) {
    i0 = 4294967295u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i1 = i32_load((&memory), (u64)(i1));
  i0 = _lib_internal_typedarray_TypedArray_u8____get(i0, i1);
  i1 = 255u;
  i0 &= i1;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___isWhitespace(u32 p0, u32 p1) {
  u32 l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p1;
  i1 = 9u;
  i0 = i0 == i1;
  l2 = i0;
  if (i0) {
    i0 = l2;
  } else {
    i0 = p1;
    i1 = 10u;
    i0 = i0 == i1;
  }
  l2 = i0;
  if (i0) {
    i0 = l2;
  } else {
    i0 = p1;
    i1 = 13u;
    i0 = i0 == i1;
  }
  l2 = i0;
  if (i0) {
    i0 = l2;
  } else {
    i0 = p1;
    i1 = 32u;
    i0 = i0 == i1;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i1 = i32_load((&memory), (u64)(i1 + 4));
  l1 = i1;
  i1 = l1;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = 0u;
  i1 >>= (i2 & 31);
  i0 = (u32)((s32)i0 < (s32)i1);
  i0 = !(i0);
  if (i0) {
    i0 = 1552u;
    i1 = 1600u;
    i2 = 114u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i2 = p0;
  i2 = i32_load((&memory), (u64)(i2 + 4));
  i2 = i32_load((&memory), (u64)(i2));
  l1 = i2;
  i3 = 1u;
  i2 += i3;
  i32_store((&memory), (u64)(i1), i2);
  i1 = l1;
  i0 = _lib_internal_typedarray_TypedArray_u8____get(i0, i1);
  i1 = 255u;
  i0 &= i1;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___skipWhitespace(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  L0: 
    i0 = p0;
    i1 = p0;
    i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(i1);
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___isWhitespace(i0, i1);
    if (i0) {
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
      goto L0;
    }
  FUNC_EPILOGUE;
}

static u32 assembly_index_MatrixDecoder_BoardMatrixElement__pushObject(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 0u;
  i0 = i0 == i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 320u;
    i2 = 1005u;
    i3 = 2u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i1 = 0u;
  i1 = _lib_map_Map_String_String__constructor(i1);
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = 1u;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readHexDigit(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
  l1 = i0;
  i0 = l1;
  i1 = g5;
  i0 -= i1;
  l2 = i0;
  i0 = l2;
  i1 = 9u;
  i0 = (u32)((s32)i0 > (s32)i1);
  if (i0) {
    i0 = l1;
    i1 = g7;
    i0 -= i1;
    i1 = 10u;
    i0 += i1;
    l2 = i0;
    i0 = l2;
    i1 = 10u;
    i0 = (u32)((s32)i0 < (s32)i1);
    l3 = i0;
    if (i0) {
      i0 = l3;
    } else {
      i0 = l2;
      i1 = 15u;
      i0 = (u32)((s32)i0 > (s32)i1);
    }
    if (i0) {
      i0 = l1;
      i1 = g8;
      i0 -= i1;
      i1 = 10u;
      i0 += i1;
      l2 = i0;
    }
  }
  i0 = 0u;
  i1 = 2u;
  i0 = _lib_array_Array_i32__constructor(i0, i1);
  l4 = i0;
  i0 = l4;
  i1 = 0u;
  i2 = l1;
  _lib_array_Array_i32____unchecked_set(i0, i1, i2);
  i0 = l4;
  i1 = 1u;
  i2 = l2;
  _lib_array_Array_i32____unchecked_set(i0, i1, i2);
  i0 = l4;
  l4 = i0;
  i0 = l2;
  i1 = 0u;
  i0 = (u32)((s32)i0 >= (s32)i1);
  l3 = i0;
  if (i0) {
    i0 = l2;
    i1 = 16u;
    i0 = (u32)((s32)i0 < (s32)i1);
  } else {
    i0 = l3;
  }
  i0 = !(i0);
  if (i0) {
    i0 = 1928u;
    i1 = 1600u;
    i2 = 272u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = l2;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readEscapedChar(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
  l1 = i0;
  i0 = l1;
  i1 = 1184u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1184u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1192u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1192u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1880u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1880u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1888u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1216u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1896u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1232u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1904u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1248u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1912u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1264u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1920u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readHexDigit(i0);
    l2 = i0;
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readHexDigit(i0);
    l3 = i0;
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readHexDigit(i0);
    l4 = i0;
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readHexDigit(i0);
    l5 = i0;
    i0 = l2;
    i1 = 4096u;
    i0 *= i1;
    i1 = l3;
    i2 = 256u;
    i1 *= i2;
    i0 += i1;
    i1 = l4;
    i2 = 16u;
    i1 *= i2;
    i0 += i1;
    i1 = l5;
    i0 += i1;
    l6 = i0;
    i0 = l6;
    i0 = _lib_string_String_fromCodePoint(i0);
    goto Bfunc;
  }
  i0 = 0u;
  i0 = !(i0);
  if (i0) {
    i0 = 1976u;
    i1 = l1;
    i1 = _lib_string_String_fromCharCode(i1);
    i0 = _lib_string_String___concat(i0, i1);
    i1 = 1600u;
    i2 = 258u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = 312u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readString(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
  i1 = 1184u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  i0 = !(i0);
  if (i0) {
    i0 = 1752u;
    i1 = 1600u;
    i2 = 197u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0));
  l1 = i0;
  i0 = 0u;
  l2 = i0;
  L2: 
    i0 = 1u;
    i0 = !(i0);
    if (i0) {goto B1;}
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
    l3 = i0;
    i0 = l3;
    i1 = 32u;
    i0 = (u32)((s32)i0 >= (s32)i1);
    i0 = !(i0);
    if (i0) {
      i0 = 1816u;
      i1 = 1600u;
      i2 = 202u;
      i3 = 12u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = 1184u;
    i2 = 0u;
    i1 = _lib_string_String_charCodeAt(i1, i2);
    i0 = i0 == i1;
    if (i0) {
      i0 = p0;
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i0 = i32_load((&memory), (u64)(i0));
      l4 = i0;
      i0 = l4;
      i1 = 8u;
      i0 += i1;
      i1 = l1;
      i0 += i1;
      i1 = p0;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i1 = i32_load((&memory), (u64)(i1));
      i2 = l1;
      i1 -= i2;
      i2 = 1u;
      i1 -= i2;
      i0 = _lib_string_String_fromUTF8(i0, i1);
      l4 = i0;
      i0 = l2;
      i1 = 0u;
      i0 = i0 == i1;
      if (i0) {
        i0 = l4;
        goto Bfunc;
      }
      i0 = l2;
      i1 = l4;
      i0 = _lib_array_Array_String__push(i0, i1);
      i0 = l2;
      i1 = 312u;
      i0 = _lib_array_Array_String__join(i0, i1);
      goto Bfunc;
    } else {
      i0 = l3;
      i1 = 1192u;
      i2 = 0u;
      i1 = _lib_string_String_charCodeAt(i1, i2);
      i0 = i0 == i1;
      if (i0) {
        i0 = l2;
        i1 = 0u;
        i0 = i0 == i1;
        if (i0) {
          i0 = 0u;
          i1 = 0u;
          i0 = _lib_array_Array_String__constructor(i0, i1);
          l2 = i0;
        }
        i0 = p0;
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i0 = i32_load((&memory), (u64)(i0));
        i1 = l1;
        i2 = 1u;
        i1 += i2;
        i0 = (u32)((s32)i0 > (s32)i1);
        if (i0) {
          i0 = l2;
          i1 = p0;
          i1 = i32_load((&memory), (u64)(i1 + 4));
          i1 = i32_load((&memory), (u64)(i1 + 4));
          i1 = i32_load((&memory), (u64)(i1));
          l4 = i1;
          i1 = l4;
          i2 = 8u;
          i1 += i2;
          i2 = l1;
          i1 += i2;
          i2 = p0;
          i2 = i32_load((&memory), (u64)(i2 + 4));
          i2 = i32_load((&memory), (u64)(i2));
          i3 = l1;
          i2 -= i3;
          i3 = 1u;
          i2 -= i3;
          i1 = _lib_string_String_fromUTF8(i1, i2);
          i0 = _lib_array_Array_String__push(i0, i1);
        }
        i0 = l2;
        i1 = p0;
        i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readEscapedChar(i1);
        i0 = _lib_array_Array_String__push(i0, i1);
        i0 = p0;
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i0 = i32_load((&memory), (u64)(i0));
        l1 = i0;
      }
    }
    goto L2;
  UNREACHABLE;
  B1:;
  i0 = 312u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseKey(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___skipWhitespace(i0);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = p0;
  i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readString(i1);
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___skipWhitespace(i0);
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
  i1 = 1480u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  i0 = !(i0);
  if (i0) {
    i0 = 2040u;
    i1 = 1600u;
    i2 = 160u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
}

static u32 _lib_array_Array_BoardMatrixElement__push(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l5 = i0;
  i0 = l2;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = l2;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 182u;
      i3 = 42u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = l5;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
  }
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  l6 = i0;
  i0 = l2;
  l7 = i0;
  i0 = p1;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l6;
  i1 = l7;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l9;
  i0 += i1;
  i1 = l8;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static void assembly_index_MatrixDecoder_BoardMatrixElement__popObject(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 320u;
    i2 = 1013u;
    i3 = 2u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1));
  l1 = i1;
  i1 = l1;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i2 = 1u;
  i1 -= i2;
  i0 = _lib_array_Array_Array_BoardMatrixElement_____get(i0, i1);
  i1 = 1u;
  g16 = i1;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = p0;
  i2 = i32_load((&memory), (u64)(i2 + 12));
  i1 = CALL_INDIRECT(table, u32 (*)(u32), 6, i2, i1);
  i0 = _lib_array_Array_BoardMatrixElement__push(i0, i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseObject(u32 p0) {
  u32 l1 = 0, l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(i0);
  i1 = 1496u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 != i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l1 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = l1;
  i0 = assembly_index_MatrixDecoder_BoardMatrixElement__pushObject(i0, i1);
  if (i0) {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
    i0 = p0;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___skipWhitespace(i0);
    i0 = 1u;
    l2 = i0;
    L3: 
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(i0);
      i1 = 1504u;
      i2 = 0u;
      i1 = _lib_string_String_charCodeAt(i1, i2);
      i0 = i0 != i1;
      if (i0) {
        i0 = l2;
        i0 = !(i0);
        if (i0) {
          i0 = p0;
          i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
          i1 = 1176u;
          i2 = 0u;
          i1 = _lib_string_String_charCodeAt(i1, i2);
          i0 = i0 == i1;
          i0 = !(i0);
          if (i0) {
            i0 = 1720u;
            i1 = 1600u;
            i2 = 143u;
            i3 = 20u;
            (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
            UNREACHABLE;
          }
        } else {
          i0 = 0u;
          l2 = i0;
        }
        i0 = p0;
        ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseKey(i0);
        i0 = p0;
        i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseValue(i0);
        goto L3;
      }
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
    i1 = 1504u;
    i2 = 0u;
    i1 = _lib_string_String_charCodeAt(i1, i2);
    i0 = i0 == i1;
    i0 = !(i0);
    if (i0) {
      i0 = 2072u;
      i1 = 1600u;
      i2 = 150u;
      i3 = 12u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  assembly_index_MatrixDecoder_BoardMatrixElement__popObject(i0);
  i0 = 1u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_BoardMatrixElement__constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_BoardMatrixElement___push(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l5 = i0;
  i0 = l2;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = l2;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 182u;
      i3 = 42u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = l5;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
  }
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  l6 = i0;
  i0 = l2;
  l7 = i0;
  i0 = p1;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l6;
  i1 = l7;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l9;
  i0 += i1;
  i1 = l8;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_MatrixDecoder_BoardMatrixElement__pushArray(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = 1u;
    i32_store((&memory), (u64)(i0 + 4), i1);
  } else {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = 1u;
    i0 = i0 == i1;
    if (i0) {
      i0 = p0;
      i0 = i32_load((&memory), (u64)(i0));
      i1 = 0u;
      i2 = 0u;
      i1 = _lib_array_Array_BoardMatrixElement__constructor(i1, i2);
      i0 = _lib_array_Array_Array_BoardMatrixElement___push(i0, i1);
      i0 = p0;
      i1 = 2u;
      i32_store((&memory), (u64)(i0 + 4), i1);
    } else {
      UNREACHABLE;
    }
  }
  i0 = 1u;
  FUNC_EPILOGUE;
  return i0;
}

static void assembly_index_MatrixDecoder_BoardMatrixElement__popArray(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 1u;
  i0 = i0 == i1;
  if (i0) {
  } else {
    i0 = p0;
    i1 = 1u;
    i32_store((&memory), (u64)(i0 + 4), i1);
  }
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseArray(u32 p0) {
  u32 l1 = 0, l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(i0);
  i1 = 1488u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 != i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l1 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = l1;
  i0 = assembly_index_MatrixDecoder_BoardMatrixElement__pushArray(i0, i1);
  if (i0) {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
    i0 = p0;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___skipWhitespace(i0);
    i0 = 1u;
    l2 = i0;
    L3: 
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(i0);
      i1 = 1512u;
      i2 = 0u;
      i1 = _lib_string_String_charCodeAt(i1, i2);
      i0 = i0 != i1;
      if (i0) {
        i0 = l2;
        i0 = !(i0);
        if (i0) {
          i0 = p0;
          i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
          i1 = 1176u;
          i2 = 0u;
          i1 = _lib_string_String_charCodeAt(i1, i2);
          i0 = i0 == i1;
          i0 = !(i0);
          if (i0) {
            i0 = 1720u;
            i1 = 1600u;
            i2 = 176u;
            i3 = 20u;
            (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
            UNREACHABLE;
          }
        } else {
          i0 = 0u;
          l2 = i0;
        }
        i0 = p0;
        i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseValue(i0);
        goto L3;
      }
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
    i1 = 1512u;
    i2 = 0u;
    i1 = _lib_string_String_charCodeAt(i1, i2);
    i0 = i0 == i1;
    i0 = !(i0);
    if (i0) {
      i0 = 2128u;
      i1 = 1600u;
      i2 = 182u;
      i3 = 12u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  assembly_index_MatrixDecoder_BoardMatrixElement__popArray(i0);
  i0 = 1u;
  goto Bfunc;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void assembly_index_MatrixDecoder_BoardMatrixElement__setString(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 320u;
    i2 = 1020u;
    i3 = 2u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = p1;
  i2 = p2;
  _lib_map_Map_String_String__set(i0, i1, i2);
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseString(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(i0);
  i1 = 1184u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 != i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = p0;
  i2 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readString(i2);
  assembly_index_MatrixDecoder_BoardMatrixElement__setString(i0, i1, i2);
  i0 = 1u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readAndAssert(u32 p0, u32 p1) {
  u32 l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = 0u;
  l2 = i0;
  L1: 
    i0 = l2;
    i1 = p1;
    i1 = i32_load((&memory), (u64)(i1));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = p1;
    i1 = l2;
    i0 = _lib_string_String_charCodeAt(i0, i1);
    i1 = p0;
    i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i1);
    i0 = i0 == i1;
    i0 = !(i0);
    if (i0) {
      i0 = 2184u;
      i1 = p1;
      i0 = _lib_string_String___concat(i0, i1);
      i1 = 2208u;
      i0 = _lib_string_String___concat(i0, i1);
      i1 = 1600u;
      i2 = 324u;
      i3 = 12u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l2;
    i1 = 1u;
    i0 += i1;
    l2 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseBoolean(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(i0);
  i1 = g3;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = g3;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readAndAssert(i0, i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i1 = i32_load((&memory), (u64)(i1 + 8));
    i2 = 0u;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setBoolean(i0, i1, i2);
    i0 = 1u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(i0);
  i1 = g2;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = g2;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readAndAssert(i0, i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i1 = i32_load((&memory), (u64)(i1 + 8));
    i2 = 1u;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setBoolean(i0, i1, i2);
    i0 = 1u;
    goto Bfunc;
  }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseNumber(u32 p0) {
  u32 l1 = 0, l2 = 0;
  u64 l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  u64 j0, j1, j2, j3;
  j0 = 0ull;
  l3 = j0;
  j0 = 1ull;
  l4 = j0;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(i0);
  i1 = 2216u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    j0 = 18446744073709551615ull;
    l4 = j0;
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
  }
  i0 = 0u;
  l1 = i0;
  L2: 
    i0 = g5;
    i1 = p0;
    i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(i1);
    i0 = (u32)((s32)i0 <= (s32)i1);
    l2 = i0;
    if (i0) {
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(i0);
      i1 = g6;
      i0 = (u32)((s32)i0 <= (s32)i1);
    } else {
      i0 = l2;
    }
    if (i0) {
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readChar(i0);
      l2 = i0;
      j0 = l3;
      j1 = 10ull;
      j0 *= j1;
      l3 = j0;
      j0 = l3;
      i1 = l2;
      i2 = g5;
      i1 -= i2;
      j1 = (u64)(s64)(s32)(i1);
      j0 += j1;
      l3 = j0;
      i0 = l1;
      i1 = 1u;
      i0 += i1;
      l1 = i0;
      goto L2;
    }
  i0 = l1;
  i1 = 0u;
  i0 = (u32)((s32)i0 > (s32)i1);
  if (i0) {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i1 = i32_load((&memory), (u64)(i1 + 8));
    j2 = l3;
    j3 = l4;
    j2 *= j3;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setInteger(i0, i1, j2);
    i0 = 1u;
    goto Bfunc;
  }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseNull(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___peekChar(i0);
  i1 = g4;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = g4;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___readAndAssert(i0, i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i1 = i32_load((&memory), (u64)(i1 + 8));
    ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setNull(i0, i1);
    i0 = 1u;
    goto Bfunc;
  }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseValue(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___skipWhitespace(i0);
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseObject(i0);
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseArray(i0);
  }
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseString(i0);
  }
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseBoolean(i0);
  }
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseNumber(i0);
  }
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseNull(i0);
  }
  l1 = i0;
  i0 = p0;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___skipWhitespace(i0);
  i0 = l1;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___deserialize(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p2;
  if (i0) {
    i0 = p0;
    i1 = p2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  } else {
    i0 = p0;
    i1 = 0u;
    i1 = ___node_modules_assemblyscript_json_assembly_decoder_DecoderState_constructor(i1);
    i32_store((&memory), (u64)(i0 + 4), i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = 0u;
    i32_store((&memory), (u64)(i0), i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = p1;
    i32_store((&memory), (u64)(i0 + 4), i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = 0u;
    i32_store((&memory), (u64)(i0 + 8), i1);
  }
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___parseValue(i0);
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = 2224u;
    i1 = 1600u;
    i2 = 102u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
}

static u32 assembly_index_MatrixDecoder_BoardMatrixElement__getResult(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_deserializeBoardMatrix(u32 p0) {
  u32 l1 = 0, l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 0u;
  i1 = 13u;
  i0 = assembly_index_MatrixDecoder_BoardMatrixElement__constructor(i0, i1);
  l1 = i0;
  i0 = 0u;
  i1 = l1;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___constructor(i0, i1);
  l2 = i0;
  i0 = l2;
  i1 = p0;
  i2 = 0u;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_BoardMatrixElement___deserialize(i0, i1, i2);
  i0 = l1;
  i0 = assembly_index_MatrixDecoder_BoardMatrixElement__getResult(i0);
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_PartitionListElement___constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_MatrixDecoder_PartitionListElement__constructor(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  if (i0) {
    i0 = p0;
  } else {
    i0 = 16u;
    i0 = _lib_memory_memory_allocate(i0);
  }
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_constructor(i0);
  p0 = i0;
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  i1 = 0u;
  i2 = 0u;
  i1 = _lib_array_Array_Array_PartitionListElement___constructor(i1, i2);
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 12), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_decodePartitionListElement(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i1 = 2568u;
  i0 = _lib_map_Map_String_String__get(i0, i1);
  l1 = i0;
  i0 = p0;
  i1 = 2576u;
  i0 = _lib_map_Map_String_String__get(i0, i1);
  l2 = i0;
  i0 = p0;
  i0 = assembly_index_decodeConstraint(i0);
  l3 = i0;
  i0 = l1;
  i1 = 0u;
  i0 = i0 == i1;
  l4 = i0;
  if (i0) {
    i0 = l4;
  } else {
    i0 = l2;
    i1 = 0u;
    i0 = i0 == i1;
  }
  if (i0) {
    UNREACHABLE;
  }
  i0 = l1;
  i1 = 0u;
  i0 = _lib_string_parseI32(i0, i1);
  l4 = i0;
  i0 = l2;
  i1 = 0u;
  i0 = _lib_string_parseI32(i0, i1);
  l5 = i0;
  i0 = 0u;
  i1 = l4;
  i2 = l5;
  i3 = l3;
  i0 = assembly_index_PartitionListElement_constructor(i0, i1, i2, i3);
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___constructor(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i1 = i32_load((&memory), (u64)(i1 + 4));
  l1 = i1;
  i1 = l1;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = 0u;
  i1 >>= (i2 & 31);
  i0 = (u32)((s32)i0 >= (s32)i1);
  if (i0) {
    i0 = 4294967295u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i1 = i32_load((&memory), (u64)(i1));
  i0 = _lib_internal_typedarray_TypedArray_u8____get(i0, i1);
  i1 = 255u;
  i0 &= i1;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___isWhitespace(u32 p0, u32 p1) {
  u32 l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p1;
  i1 = 9u;
  i0 = i0 == i1;
  l2 = i0;
  if (i0) {
    i0 = l2;
  } else {
    i0 = p1;
    i1 = 10u;
    i0 = i0 == i1;
  }
  l2 = i0;
  if (i0) {
    i0 = l2;
  } else {
    i0 = p1;
    i1 = 13u;
    i0 = i0 == i1;
  }
  l2 = i0;
  if (i0) {
    i0 = l2;
  } else {
    i0 = p1;
    i1 = 32u;
    i0 = i0 == i1;
  }
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i1 = i32_load((&memory), (u64)(i1 + 4));
  l1 = i1;
  i1 = l1;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = 0u;
  i1 >>= (i2 & 31);
  i0 = (u32)((s32)i0 < (s32)i1);
  i0 = !(i0);
  if (i0) {
    i0 = 1552u;
    i1 = 1600u;
    i2 = 114u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i2 = p0;
  i2 = i32_load((&memory), (u64)(i2 + 4));
  i2 = i32_load((&memory), (u64)(i2));
  l1 = i2;
  i3 = 1u;
  i2 += i3;
  i32_store((&memory), (u64)(i1), i2);
  i1 = l1;
  i0 = _lib_internal_typedarray_TypedArray_u8____get(i0, i1);
  i1 = 255u;
  i0 &= i1;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___skipWhitespace(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  L0: 
    i0 = p0;
    i1 = p0;
    i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(i1);
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___isWhitespace(i0, i1);
    if (i0) {
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
      goto L0;
    }
  FUNC_EPILOGUE;
}

static u32 assembly_index_MatrixDecoder_PartitionListElement__pushObject(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 0u;
  i0 = i0 == i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 320u;
    i2 = 1005u;
    i3 = 2u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i1 = 0u;
  i1 = _lib_map_Map_String_String__constructor(i1);
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = 1u;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readHexDigit(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
  l1 = i0;
  i0 = l1;
  i1 = g5;
  i0 -= i1;
  l2 = i0;
  i0 = l2;
  i1 = 9u;
  i0 = (u32)((s32)i0 > (s32)i1);
  if (i0) {
    i0 = l1;
    i1 = g7;
    i0 -= i1;
    i1 = 10u;
    i0 += i1;
    l2 = i0;
    i0 = l2;
    i1 = 10u;
    i0 = (u32)((s32)i0 < (s32)i1);
    l3 = i0;
    if (i0) {
      i0 = l3;
    } else {
      i0 = l2;
      i1 = 15u;
      i0 = (u32)((s32)i0 > (s32)i1);
    }
    if (i0) {
      i0 = l1;
      i1 = g8;
      i0 -= i1;
      i1 = 10u;
      i0 += i1;
      l2 = i0;
    }
  }
  i0 = 0u;
  i1 = 2u;
  i0 = _lib_array_Array_i32__constructor(i0, i1);
  l4 = i0;
  i0 = l4;
  i1 = 0u;
  i2 = l1;
  _lib_array_Array_i32____unchecked_set(i0, i1, i2);
  i0 = l4;
  i1 = 1u;
  i2 = l2;
  _lib_array_Array_i32____unchecked_set(i0, i1, i2);
  i0 = l4;
  l4 = i0;
  i0 = l2;
  i1 = 0u;
  i0 = (u32)((s32)i0 >= (s32)i1);
  l3 = i0;
  if (i0) {
    i0 = l2;
    i1 = 16u;
    i0 = (u32)((s32)i0 < (s32)i1);
  } else {
    i0 = l3;
  }
  i0 = !(i0);
  if (i0) {
    i0 = 1928u;
    i1 = 1600u;
    i2 = 272u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = l2;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readEscapedChar(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
  l1 = i0;
  i0 = l1;
  i1 = 1184u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1184u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1192u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1192u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1880u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1880u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1888u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1216u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1896u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1232u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1904u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1248u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1912u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = 1264u;
    goto Bfunc;
  }
  i0 = l1;
  i1 = 1920u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readHexDigit(i0);
    l2 = i0;
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readHexDigit(i0);
    l3 = i0;
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readHexDigit(i0);
    l4 = i0;
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readHexDigit(i0);
    l5 = i0;
    i0 = l2;
    i1 = 4096u;
    i0 *= i1;
    i1 = l3;
    i2 = 256u;
    i1 *= i2;
    i0 += i1;
    i1 = l4;
    i2 = 16u;
    i1 *= i2;
    i0 += i1;
    i1 = l5;
    i0 += i1;
    l6 = i0;
    i0 = l6;
    i0 = _lib_string_String_fromCodePoint(i0);
    goto Bfunc;
  }
  i0 = 0u;
  i0 = !(i0);
  if (i0) {
    i0 = 1976u;
    i1 = l1;
    i1 = _lib_string_String_fromCharCode(i1);
    i0 = _lib_string_String___concat(i0, i1);
    i1 = 1600u;
    i2 = 258u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = 312u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readString(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
  i1 = 1184u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  i0 = !(i0);
  if (i0) {
    i0 = 1752u;
    i1 = 1600u;
    i2 = 197u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0));
  l1 = i0;
  i0 = 0u;
  l2 = i0;
  L2: 
    i0 = 1u;
    i0 = !(i0);
    if (i0) {goto B1;}
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
    l3 = i0;
    i0 = l3;
    i1 = 32u;
    i0 = (u32)((s32)i0 >= (s32)i1);
    i0 = !(i0);
    if (i0) {
      i0 = 1816u;
      i1 = 1600u;
      i2 = 202u;
      i3 = 12u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = 1184u;
    i2 = 0u;
    i1 = _lib_string_String_charCodeAt(i1, i2);
    i0 = i0 == i1;
    if (i0) {
      i0 = p0;
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i0 = i32_load((&memory), (u64)(i0 + 4));
      i0 = i32_load((&memory), (u64)(i0));
      l4 = i0;
      i0 = l4;
      i1 = 8u;
      i0 += i1;
      i1 = l1;
      i0 += i1;
      i1 = p0;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i1 = i32_load((&memory), (u64)(i1));
      i2 = l1;
      i1 -= i2;
      i2 = 1u;
      i1 -= i2;
      i0 = _lib_string_String_fromUTF8(i0, i1);
      l4 = i0;
      i0 = l2;
      i1 = 0u;
      i0 = i0 == i1;
      if (i0) {
        i0 = l4;
        goto Bfunc;
      }
      i0 = l2;
      i1 = l4;
      i0 = _lib_array_Array_String__push(i0, i1);
      i0 = l2;
      i1 = 312u;
      i0 = _lib_array_Array_String__join(i0, i1);
      goto Bfunc;
    } else {
      i0 = l3;
      i1 = 1192u;
      i2 = 0u;
      i1 = _lib_string_String_charCodeAt(i1, i2);
      i0 = i0 == i1;
      if (i0) {
        i0 = l2;
        i1 = 0u;
        i0 = i0 == i1;
        if (i0) {
          i0 = 0u;
          i1 = 0u;
          i0 = _lib_array_Array_String__constructor(i0, i1);
          l2 = i0;
        }
        i0 = p0;
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i0 = i32_load((&memory), (u64)(i0));
        i1 = l1;
        i2 = 1u;
        i1 += i2;
        i0 = (u32)((s32)i0 > (s32)i1);
        if (i0) {
          i0 = l2;
          i1 = p0;
          i1 = i32_load((&memory), (u64)(i1 + 4));
          i1 = i32_load((&memory), (u64)(i1 + 4));
          i1 = i32_load((&memory), (u64)(i1));
          l4 = i1;
          i1 = l4;
          i2 = 8u;
          i1 += i2;
          i2 = l1;
          i1 += i2;
          i2 = p0;
          i2 = i32_load((&memory), (u64)(i2 + 4));
          i2 = i32_load((&memory), (u64)(i2));
          i3 = l1;
          i2 -= i3;
          i3 = 1u;
          i2 -= i3;
          i1 = _lib_string_String_fromUTF8(i1, i2);
          i0 = _lib_array_Array_String__push(i0, i1);
        }
        i0 = l2;
        i1 = p0;
        i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readEscapedChar(i1);
        i0 = _lib_array_Array_String__push(i0, i1);
        i0 = p0;
        i0 = i32_load((&memory), (u64)(i0 + 4));
        i0 = i32_load((&memory), (u64)(i0));
        l1 = i0;
      }
    }
    goto L2;
  UNREACHABLE;
  B1:;
  i0 = 312u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseKey(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___skipWhitespace(i0);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = p0;
  i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readString(i1);
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___skipWhitespace(i0);
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
  i1 = 1480u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  i0 = !(i0);
  if (i0) {
    i0 = 2040u;
    i1 = 1600u;
    i2 = 160u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
}

static u32 _lib_array_Array_PartitionListElement__push(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l5 = i0;
  i0 = l2;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = l2;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 182u;
      i3 = 42u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = l5;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
  }
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  l6 = i0;
  i0 = l2;
  l7 = i0;
  i0 = p1;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l6;
  i1 = l7;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l9;
  i0 += i1;
  i1 = l8;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static void assembly_index_MatrixDecoder_PartitionListElement__popObject(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 320u;
    i2 = 1013u;
    i3 = 2u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1));
  l1 = i1;
  i1 = l1;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i2 = 1u;
  i1 -= i2;
  i0 = _lib_array_Array_Array_PartitionListElement_____get(i0, i1);
  i1 = 1u;
  g16 = i1;
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = p0;
  i2 = i32_load((&memory), (u64)(i2 + 12));
  i1 = CALL_INDIRECT(table, u32 (*)(u32), 6, i2, i1);
  i0 = _lib_array_Array_PartitionListElement__push(i0, i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseObject(u32 p0) {
  u32 l1 = 0, l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(i0);
  i1 = 1496u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 != i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l1 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = l1;
  i0 = assembly_index_MatrixDecoder_PartitionListElement__pushObject(i0, i1);
  if (i0) {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
    i0 = p0;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___skipWhitespace(i0);
    i0 = 1u;
    l2 = i0;
    L3: 
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(i0);
      i1 = 1504u;
      i2 = 0u;
      i1 = _lib_string_String_charCodeAt(i1, i2);
      i0 = i0 != i1;
      if (i0) {
        i0 = l2;
        i0 = !(i0);
        if (i0) {
          i0 = p0;
          i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
          i1 = 1176u;
          i2 = 0u;
          i1 = _lib_string_String_charCodeAt(i1, i2);
          i0 = i0 == i1;
          i0 = !(i0);
          if (i0) {
            i0 = 1720u;
            i1 = 1600u;
            i2 = 143u;
            i3 = 20u;
            (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
            UNREACHABLE;
          }
        } else {
          i0 = 0u;
          l2 = i0;
        }
        i0 = p0;
        ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseKey(i0);
        i0 = p0;
        i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseValue(i0);
        goto L3;
      }
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
    i1 = 1504u;
    i2 = 0u;
    i1 = _lib_string_String_charCodeAt(i1, i2);
    i0 = i0 == i1;
    i0 = !(i0);
    if (i0) {
      i0 = 2072u;
      i1 = 1600u;
      i2 = 150u;
      i3 = 12u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  assembly_index_MatrixDecoder_PartitionListElement__popObject(i0);
  i0 = 1u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_PartitionListElement__constructor(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p1;
  i1 = 268435454u;
  i0 = i0 > i1;
  if (i0) {
    i0 = 0u;
    i1 = 152u;
    i2 = 45u;
    i3 = 39u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p1;
  i1 = 2u;
  i0 <<= (i1 & 31);
  l2 = i0;
  i0 = l2;
  i0 = _lib_internal_arraybuffer_allocateUnsafe(i0);
  l3 = i0;
  i0 = p0;
  i0 = !(i0);
  if (i0) {
    i0 = 8u;
    i0 = _lib_memory_memory_allocate(i0);
    p0 = i0;
  }
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = p0;
  i1 = l3;
  i32_store((&memory), (u64)(i0), i1);
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  i1 = 8u;
  i0 += i1;
  l4 = i0;
  i0 = 0u;
  l5 = i0;
  i0 = l2;
  l6 = i0;
  i0 = l4;
  i1 = l5;
  i2 = l6;
  _lib_internal_memory_memset(i0, i1, i2);
  i0 = p0;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_array_Array_Array_PartitionListElement___push(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0, l7 = 0, l8 = 0, l9 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  l2 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  l3 = i0;
  i0 = l3;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = 2u;
  i0 >>= (i1 & 31);
  l4 = i0;
  i0 = l2;
  i1 = 1u;
  i0 += i1;
  l5 = i0;
  i0 = l2;
  i1 = l4;
  i0 = i0 >= i1;
  if (i0) {
    i0 = l2;
    i1 = 268435454u;
    i0 = i0 >= i1;
    if (i0) {
      i0 = 0u;
      i1 = 152u;
      i2 = 182u;
      i3 = 42u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l3;
    i1 = l5;
    i2 = 2u;
    i1 <<= (i2 & 31);
    i0 = _lib_internal_arraybuffer_reallocateUnsafe(i0, i1);
    l3 = i0;
    i0 = p0;
    i1 = l3;
    i32_store((&memory), (u64)(i0), i1);
  }
  i0 = p0;
  i1 = l5;
  i32_store((&memory), (u64)(i0 + 4), i1);
  i0 = l3;
  l6 = i0;
  i0 = l2;
  l7 = i0;
  i0 = p1;
  l8 = i0;
  i0 = 0u;
  l9 = i0;
  i0 = l6;
  i1 = l7;
  i2 = 2u;
  i1 <<= (i2 & 31);
  i0 += i1;
  i1 = l9;
  i0 += i1;
  i1 = l8;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = l5;
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_MatrixDecoder_PartitionListElement__pushArray(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = 1u;
    i32_store((&memory), (u64)(i0 + 4), i1);
  } else {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = 1u;
    i0 = i0 == i1;
    if (i0) {
      i0 = p0;
      i0 = i32_load((&memory), (u64)(i0));
      i1 = 0u;
      i2 = 0u;
      i1 = _lib_array_Array_PartitionListElement__constructor(i1, i2);
      i0 = _lib_array_Array_Array_PartitionListElement___push(i0, i1);
      i0 = p0;
      i1 = 2u;
      i32_store((&memory), (u64)(i0 + 4), i1);
    } else {
      UNREACHABLE;
    }
  }
  i0 = 1u;
  FUNC_EPILOGUE;
  return i0;
}

static void assembly_index_MatrixDecoder_PartitionListElement__popArray(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 1u;
  i0 = i0 == i1;
  if (i0) {
  } else {
    i0 = p0;
    i1 = 1u;
    i32_store((&memory), (u64)(i0 + 4), i1);
  }
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseArray(u32 p0) {
  u32 l1 = 0, l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(i0);
  i1 = 1488u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 != i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = i32_load((&memory), (u64)(i0 + 8));
  l1 = i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i1 = 0u;
  i32_store((&memory), (u64)(i0 + 8), i1);
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = l1;
  i0 = assembly_index_MatrixDecoder_PartitionListElement__pushArray(i0, i1);
  if (i0) {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
    i0 = p0;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___skipWhitespace(i0);
    i0 = 1u;
    l2 = i0;
    L3: 
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(i0);
      i1 = 1512u;
      i2 = 0u;
      i1 = _lib_string_String_charCodeAt(i1, i2);
      i0 = i0 != i1;
      if (i0) {
        i0 = l2;
        i0 = !(i0);
        if (i0) {
          i0 = p0;
          i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
          i1 = 1176u;
          i2 = 0u;
          i1 = _lib_string_String_charCodeAt(i1, i2);
          i0 = i0 == i1;
          i0 = !(i0);
          if (i0) {
            i0 = 1720u;
            i1 = 1600u;
            i2 = 176u;
            i3 = 20u;
            (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
            UNREACHABLE;
          }
        } else {
          i0 = 0u;
          l2 = i0;
        }
        i0 = p0;
        i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseValue(i0);
        goto L3;
      }
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
    i1 = 1512u;
    i2 = 0u;
    i1 = _lib_string_String_charCodeAt(i1, i2);
    i0 = i0 == i1;
    i0 = !(i0);
    if (i0) {
      i0 = 2128u;
      i1 = 1600u;
      i2 = 182u;
      i3 = 12u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  assembly_index_MatrixDecoder_PartitionListElement__popArray(i0);
  i0 = 1u;
  goto Bfunc;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void assembly_index_MatrixDecoder_PartitionListElement__setString(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = 0u;
    i1 = 320u;
    i2 = 1020u;
    i3 = 2u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i1 = p1;
  i2 = p2;
  _lib_map_Map_String_String__set(i0, i1, i2);
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseString(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(i0);
  i1 = 1184u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 != i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  i1 = p0;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  i1 = i32_load((&memory), (u64)(i1 + 8));
  i2 = p0;
  i2 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readString(i2);
  assembly_index_MatrixDecoder_PartitionListElement__setString(i0, i1, i2);
  i0 = 1u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readAndAssert(u32 p0, u32 p1) {
  u32 l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = 0u;
  l2 = i0;
  L1: 
    i0 = l2;
    i1 = p1;
    i1 = i32_load((&memory), (u64)(i1));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = p1;
    i1 = l2;
    i0 = _lib_string_String_charCodeAt(i0, i1);
    i1 = p0;
    i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i1);
    i0 = i0 == i1;
    i0 = !(i0);
    if (i0) {
      i0 = 2184u;
      i1 = p1;
      i0 = _lib_string_String___concat(i0, i1);
      i1 = 2208u;
      i0 = _lib_string_String___concat(i0, i1);
      i1 = 1600u;
      i2 = 324u;
      i3 = 12u;
      (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
      UNREACHABLE;
    }
    i0 = l2;
    i1 = 1u;
    i0 += i1;
    l2 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  FUNC_EPILOGUE;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseBoolean(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(i0);
  i1 = g3;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = g3;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readAndAssert(i0, i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i1 = i32_load((&memory), (u64)(i1 + 8));
    i2 = 0u;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setBoolean(i0, i1, i2);
    i0 = 1u;
    goto Bfunc;
  }
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(i0);
  i1 = g2;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = g2;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readAndAssert(i0, i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i1 = i32_load((&memory), (u64)(i1 + 8));
    i2 = 1u;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setBoolean(i0, i1, i2);
    i0 = 1u;
    goto Bfunc;
  }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseNumber(u32 p0) {
  u32 l1 = 0, l2 = 0;
  u64 l3 = 0, l4 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  u64 j0, j1, j2, j3;
  j0 = 0ull;
  l3 = j0;
  j0 = 1ull;
  l4 = j0;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(i0);
  i1 = 2216u;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    j0 = 18446744073709551615ull;
    l4 = j0;
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
  }
  i0 = 0u;
  l1 = i0;
  L2: 
    i0 = g5;
    i1 = p0;
    i1 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(i1);
    i0 = (u32)((s32)i0 <= (s32)i1);
    l2 = i0;
    if (i0) {
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(i0);
      i1 = g6;
      i0 = (u32)((s32)i0 <= (s32)i1);
    } else {
      i0 = l2;
    }
    if (i0) {
      i0 = p0;
      i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readChar(i0);
      l2 = i0;
      j0 = l3;
      j1 = 10ull;
      j0 *= j1;
      l3 = j0;
      j0 = l3;
      i1 = l2;
      i2 = g5;
      i1 -= i2;
      j1 = (u64)(s64)(s32)(i1);
      j0 += j1;
      l3 = j0;
      i0 = l1;
      i1 = 1u;
      i0 += i1;
      l1 = i0;
      goto L2;
    }
  i0 = l1;
  i1 = 0u;
  i0 = (u32)((s32)i0 > (s32)i1);
  if (i0) {
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i1 = i32_load((&memory), (u64)(i1 + 8));
    j2 = l3;
    j3 = l4;
    j2 *= j3;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setInteger(i0, i1, j2);
    i0 = 1u;
    goto Bfunc;
  }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseNull(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___peekChar(i0);
  i1 = g4;
  i2 = 0u;
  i1 = _lib_string_String_charCodeAt(i1, i2);
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = g4;
    ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___readAndAssert(i0, i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0));
    i1 = p0;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i1 = i32_load((&memory), (u64)(i1 + 8));
    ___node_modules_assemblyscript_json_assembly_decoder_JSONHandler_setNull(i0, i1);
    i0 = 1u;
    goto Bfunc;
  }
  i0 = 0u;
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseValue(u32 p0) {
  u32 l1 = 0;
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___skipWhitespace(i0);
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseObject(i0);
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseArray(i0);
  }
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseString(i0);
  }
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseBoolean(i0);
  }
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseNumber(i0);
  }
  l1 = i0;
  if (i0) {
    i0 = l1;
  } else {
    i0 = p0;
    i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseNull(i0);
  }
  l1 = i0;
  i0 = p0;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___skipWhitespace(i0);
  i0 = l1;
  FUNC_EPILOGUE;
  return i0;
}

static void ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___deserialize(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2, i3;
  i0 = p2;
  if (i0) {
    i0 = p0;
    i1 = p2;
    i32_store((&memory), (u64)(i0 + 4), i1);
  } else {
    i0 = p0;
    i1 = 0u;
    i1 = ___node_modules_assemblyscript_json_assembly_decoder_DecoderState_constructor(i1);
    i32_store((&memory), (u64)(i0 + 4), i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = 0u;
    i32_store((&memory), (u64)(i0), i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = p1;
    i32_store((&memory), (u64)(i0 + 4), i1);
    i0 = p0;
    i0 = i32_load((&memory), (u64)(i0 + 4));
    i1 = 0u;
    i32_store((&memory), (u64)(i0 + 8), i1);
  }
  i0 = p0;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___parseValue(i0);
  i1 = 0u;
  i0 = i0 != i1;
  i0 = !(i0);
  if (i0) {
    i0 = 2224u;
    i1 = 1600u;
    i2 = 102u;
    i3 = 8u;
    (*Z_envZ_abortZ_viiii)(i0, i1, i2, i3);
    UNREACHABLE;
  }
  FUNC_EPILOGUE;
}

static u32 assembly_index_MatrixDecoder_PartitionListElement__getResult(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_deserializePartitionList(u32 p0) {
  u32 l1 = 0, l2 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 0u;
  i1 = 14u;
  i0 = assembly_index_MatrixDecoder_PartitionListElement__constructor(i0, i1);
  l1 = i0;
  i0 = 0u;
  i1 = l1;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___constructor(i0, i1);
  l2 = i0;
  i0 = l2;
  i1 = p0;
  i2 = 0u;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_PartitionListElement___deserialize(i0, i1, i2);
  i0 = l1;
  i0 = assembly_index_MatrixDecoder_PartitionListElement__getResult(i0);
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_deserializeI32(u32 p0) {
  u32 l1 = 0, l2 = 0, l3 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 0u;
  i1 = 12u;
  i0 = assembly_index_MatrixDecoder_i32__constructor(i0, i1);
  l1 = i0;
  i0 = 0u;
  i1 = l1;
  i0 = ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___constructor(i0, i1);
  l2 = i0;
  i0 = l2;
  i1 = p0;
  i2 = 0u;
  ___node_modules_assemblyscript_json_assembly_decoder_JSONDecoder_MatrixDecoder_i32___deserialize(i0, i1, i2);
  i0 = l1;
  i0 = assembly_index_MatrixDecoder_i32__getResult(i0);
  l3 = i0;
  i0 = l3;
  FUNC_EPILOGUE;
  return i0;
}

static void assembly_index_encodeConstraint(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0, l6 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p1;
  i1 = 0u;
  i0 = i0 == i1;
  if (i0) {
    i0 = p0;
    i1 = 1912u;
    i2 = 40u;
    ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_setString(i0, i1, i2);
    goto Bfunc;
  }
  i0 = p1;
  i0 = i32_load((&memory), (u64)(i0 + 12));
  l2 = i0;
  i0 = p1;
  i0 = i32_load((&memory), (u64)(i0));
  i0 = _lib_number_I32_toString(i0);
  l3 = i0;
  i0 = p1;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  i0 = _lib_number_I32_toString(i0);
  l4 = i0;
  i0 = p1;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  i0 = _lib_number_I32_toString(i0);
  l5 = i0;
  i0 = p1;
  i0 = i32_load((&memory), (u64)(i0 + 16));
  l6 = i0;
  i0 = p0;
  i1 = 1912u;
  i2 = l2;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_setString(i0, i1, i2);
  i0 = p0;
  i1 = 2408u;
  i2 = l3;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_setString(i0, i1, i2);
  i0 = p0;
  i1 = 2424u;
  i2 = l4;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_setString(i0, i1, i2);
  i0 = p0;
  i1 = 2440u;
  i2 = l5;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_setString(i0, i1, i2);
  i0 = p0;
  i1 = 2480u;
  i2 = l6;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_setString(i0, i1, i2);
  Bfunc:;
  FUNC_EPILOGUE;
}

static void assembly_index_encodeBoardMatrixElement(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i1 = 2400u;
  i2 = p1;
  i2 = i32_load((&memory), (u64)(i2));
  i2 = _lib_number_I32_toString(i2);
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_setString(i0, i1, i2);
  i0 = p0;
  i1 = p1;
  i1 = i32_load((&memory), (u64)(i1 + 4));
  assembly_index_encodeConstraint(i0, i1);
  FUNC_EPILOGUE;
}

static u32 assembly_index_MatrixEncoder_BoardMatrixElement_(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 0u;
  i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_constructor(i0);
  l2 = i0;
  i0 = l2;
  i1 = 0u;
  i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushArray(i0, i1);
  i0 = 0u;
  l3 = i0;
  L1: 
    i0 = l3;
    i1 = p0;
    l4 = i1;
    i1 = l4;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = l2;
    i1 = 0u;
    i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushArray(i0, i1);
    i0 = 0u;
    l4 = i0;
    L5: 
      i0 = l4;
      i1 = p0;
      i2 = l3;
      i1 = _lib_array_Array_Array_BoardMatrixElement_____get(i1, i2);
      l5 = i1;
      i1 = l5;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B4;}
      i0 = l2;
      i1 = 0u;
      i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushObject(i0, i1);
      i0 = 2u;
      g16 = i0;
      i0 = l2;
      i1 = p0;
      i2 = l3;
      i1 = _lib_array_Array_Array_BoardMatrixElement_____get(i1, i2);
      i2 = l4;
      i1 = _lib_array_Array_BoardMatrixElement____get(i1, i2);
      i2 = p1;
      CALL_INDIRECT(table, void (*)(u32, u32), 14, i2, i0, i1);
      i0 = l2;
      ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popObject(i0);
      i0 = l4;
      i1 = 1u;
      i0 += i1;
      l4 = i0;
      goto L5;
    UNREACHABLE;
    B4:;
    i0 = l2;
    ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popArray(i0);
    i0 = l3;
    i1 = 1u;
    i0 += i1;
    l3 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l2;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popArray(i0);
  i0 = l2;
  i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_serialize(i0);
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_serializeBoardMatrix(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = 15u;
  i0 = assembly_index_MatrixEncoder_BoardMatrixElement_(i0, i1);
  FUNC_EPILOGUE;
  return i0;
}

static void assembly_index_encodePartitionListElement(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i1 = 2568u;
  i2 = p1;
  i2 = i32_load((&memory), (u64)(i2));
  i2 = _lib_number_I32_toString(i2);
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_setString(i0, i1, i2);
  i0 = p0;
  i1 = 2576u;
  i2 = p1;
  i2 = i32_load((&memory), (u64)(i2 + 4));
  i2 = _lib_number_I32_toString(i2);
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_setString(i0, i1, i2);
  i0 = p0;
  i1 = p1;
  i1 = i32_load((&memory), (u64)(i1 + 8));
  assembly_index_encodeConstraint(i0, i1);
  FUNC_EPILOGUE;
}

static u32 assembly_index_MatrixEncoder_PartitionListElement_(u32 p0, u32 p1) {
  u32 l2 = 0, l3 = 0, l4 = 0, l5 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = 0u;
  i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_constructor(i0);
  l2 = i0;
  i0 = l2;
  i1 = 0u;
  i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushArray(i0, i1);
  i0 = 0u;
  l3 = i0;
  L1: 
    i0 = l3;
    i1 = p0;
    l4 = i1;
    i1 = l4;
    i1 = i32_load((&memory), (u64)(i1 + 4));
    i0 = (u32)((s32)i0 < (s32)i1);
    i0 = !(i0);
    if (i0) {goto B0;}
    i0 = l2;
    i1 = 0u;
    i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushArray(i0, i1);
    i0 = 0u;
    l4 = i0;
    L5: 
      i0 = l4;
      i1 = p0;
      i2 = l3;
      i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
      l5 = i1;
      i1 = l5;
      i1 = i32_load((&memory), (u64)(i1 + 4));
      i0 = (u32)((s32)i0 < (s32)i1);
      i0 = !(i0);
      if (i0) {goto B4;}
      i0 = l2;
      i1 = 0u;
      i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_pushObject(i0, i1);
      i0 = 2u;
      g16 = i0;
      i0 = l2;
      i1 = p0;
      i2 = l3;
      i1 = _lib_array_Array_Array_PartitionListElement_____get(i1, i2);
      i2 = l4;
      i1 = _lib_array_Array_PartitionListElement____get(i1, i2);
      i2 = p1;
      CALL_INDIRECT(table, void (*)(u32, u32), 14, i2, i0, i1);
      i0 = l2;
      ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popObject(i0);
      i0 = l4;
      i1 = 1u;
      i0 += i1;
      l4 = i0;
      goto L5;
    UNREACHABLE;
    B4:;
    i0 = l2;
    ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popArray(i0);
    i0 = l3;
    i1 = 1u;
    i0 += i1;
    l3 = i0;
    goto L1;
  UNREACHABLE;
  B0:;
  i0 = l2;
  ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_popArray(i0);
  i0 = l2;
  i0 = ___node_modules_assemblyscript_json_assembly_encoder_JSONEncoder_serialize(i0);
  FUNC_EPILOGUE;
  return i0;
}

static u32 assembly_index_serializePartitionList(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = 16u;
  i0 = assembly_index_MatrixEncoder_PartitionListElement_(i0, i1);
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_internal_memory_memcmp(u32 p0, u32 p1, u32 p2) {
  u32 l3 = 0;
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i0 = i0 == i1;
  if (i0) {
    i0 = 0u;
    goto Bfunc;
  }
  L2: 
    i0 = p2;
    i1 = 0u;
    i0 = i0 != i1;
    l3 = i0;
    if (i0) {
      i0 = p0;
      i0 = i32_load8_u((&memory), (u64)(i0));
      i1 = p1;
      i1 = i32_load8_u((&memory), (u64)(i1));
      i0 = i0 == i1;
    } else {
      i0 = l3;
    }
    if (i0) {
      i0 = p2;
      i1 = 1u;
      i0 -= i1;
      p2 = i0;
      i0 = p0;
      i1 = 1u;
      i0 += i1;
      p0 = i0;
      i0 = p1;
      i1 = 1u;
      i0 += i1;
      p1 = i0;
      goto L2;
    }
  i0 = p2;
  if (i0) {
    i0 = p0;
    i0 = i32_load8_u((&memory), (u64)(i0));
    i1 = p1;
    i1 = i32_load8_u((&memory), (u64)(i1));
    i0 -= i1;
  } else {
    i0 = 0u;
  }
  Bfunc:;
  FUNC_EPILOGUE;
  return i0;
}

static u32 _lib_memory_memory_compare(u32 p0, u32 p1, u32 p2) {
  FUNC_PROLOGUE;
  u32 i0, i1, i2;
  i0 = p0;
  i1 = p1;
  i2 = p2;
  i0 = _lib_internal_memory_memcmp(i0, i1, i2);
  FUNC_EPILOGUE;
  return i0;
}

static void _lib_memory_memory_free(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  _lib_allocator_arena___memory_free(i0);
  goto Bfunc;
  Bfunc:;
  FUNC_EPILOGUE;
}

static void _lib_allocator_arena___memory_reset(void) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = g0;
  g1 = i0;
  FUNC_EPILOGUE;
}

static void _lib_memory_memory_reset(void) {
  FUNC_PROLOGUE;
  _lib_allocator_arena___memory_reset();
  goto Bfunc;
  Bfunc:;
  FUNC_EPILOGUE;
}

static void start(void) {
  FUNC_PROLOGUE;
  start_assembly_index();
  FUNC_EPILOGUE;
}

static void null(void) {
  FUNC_PROLOGUE;
  FUNC_EPILOGUE;
}

static u32 BoardMatrixElement_get_p(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static void BoardMatrixElement_set_p(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  FUNC_EPILOGUE;
}

static u32 BoardMatrixElement_get_t(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static void BoardMatrixElement_set_t(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  FUNC_EPILOGUE;
}

static u32 PartitionListElement_get_x(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static void PartitionListElement_set_x(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  FUNC_EPILOGUE;
}

static u32 PartitionListElement_get_y(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static void PartitionListElement_set_y(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  FUNC_EPILOGUE;
}

static u32 PartitionListElement_get_t(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  FUNC_EPILOGUE;
  return i0;
}

static void PartitionListElement_set_t(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint_get_x(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint_set_x(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint_get_y(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint_set_y(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint_get_classification(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint_set_classification(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint_get_name(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 12));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint_set_name(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 12), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint_get_serializedArgs(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 16));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint_set_serializedArgs(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 16), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint1_get_x(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint1_set_x(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint1_get_y(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint1_set_y(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint1_get_classification(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint1_set_classification(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint1_get_name(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 12));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint1_set_name(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 12), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint1_get_serializedArgs(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 16));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint1_set_serializedArgs(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 16), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint2_get_x(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint2_set_x(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint2_get_y(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint2_set_y(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint2_get_classification(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint2_set_classification(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint2_get_name(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 12));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint2_set_name(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 12), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint2_get_serializedArgs(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 16));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint2_set_serializedArgs(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 16), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint3_get_x(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint3_set_x(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint3_get_y(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint3_set_y(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint3_get_classification(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint3_set_classification(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint3_get_name(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 12));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint3_set_name(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 12), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint3_get_serializedArgs(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 16));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint3_set_serializedArgs(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 16), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint4_get_x(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint4_set_x(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint4_get_y(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint4_set_y(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint4_get_classification(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint4_set_classification(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint4_get_name(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 12));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint4_set_name(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 12), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint4_get_serializedArgs(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 16));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint4_set_serializedArgs(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 16), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint5_get_x(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint5_set_x(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint5_get_y(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint5_set_y(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint5_get_classification(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint5_set_classification(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint5_get_name(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 12));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint5_set_name(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 12), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint5_get_serializedArgs(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 16));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint5_set_serializedArgs(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 16), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint6_get_x(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint6_set_x(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint6_get_y(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint6_set_y(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint6_get_classification(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 8));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint6_set_classification(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 8), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint6_get_name(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 12));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint6_set_name(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 12), i1);
  FUNC_EPILOGUE;
}

static u32 Constraint6_get_serializedArgs(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 16));
  FUNC_EPILOGUE;
  return i0;
}

static void Constraint6_set_serializedArgs(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 16), i1);
  FUNC_EPILOGUE;
}

static u32 State_get_mtx(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0));
  FUNC_EPILOGUE;
  return i0;
}

static void State_set_mtx(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0), i1);
  FUNC_EPILOGUE;
}

static u32 State_get_parts(u32 p0) {
  FUNC_PROLOGUE;
  u32 i0;
  i0 = p0;
  i0 = i32_load((&memory), (u64)(i0 + 4));
  FUNC_EPILOGUE;
  return i0;
}

static void State_set_parts(u32 p0, u32 p1) {
  FUNC_PROLOGUE;
  u32 i0, i1;
  i0 = p0;
  i1 = p1;
  i32_store((&memory), (u64)(i0 + 4), i1);
  FUNC_EPILOGUE;
}

static const u8 data_segment_data_0[] = {
  0x04, 0x00, 0x00, 0x00, 0x74, 0x00, 0x72, 0x00, 0x75, 0x00, 0x65, 0x00, 
  
};

static const u8 data_segment_data_1[] = {
  0x05, 0x00, 0x00, 0x00, 0x66, 0x00, 0x61, 0x00, 0x6c, 0x00, 0x73, 0x00, 
  0x65, 0x00, 
};

static const u8 data_segment_data_2[] = {
  0x04, 0x00, 0x00, 0x00, 0x6e, 0x00, 0x75, 0x00, 0x6c, 0x00, 0x6c, 0x00, 
  
};

static const u8 data_segment_data_3[] = {
  0x01, 0x00, 0x00, 0x00, 0x30, 0x00, 
};

static const u8 data_segment_data_4[] = {
  0x0e, 0x00, 0x00, 0x00, 0x7e, 0x00, 0x6c, 0x00, 0x69, 0x00, 0x62, 0x00, 
  0x2f, 0x00, 0x73, 0x00, 0x74, 0x00, 0x72, 0x00, 0x69, 0x00, 0x6e, 0x00, 
  0x67, 0x00, 0x2e, 0x00, 0x74, 0x00, 0x73, 0x00, 
};

static const u8 data_segment_data_5[] = {
  0x01, 0x00, 0x00, 0x00, 0x39, 0x00, 
};

static const u8 data_segment_data_6[] = {
  0x01, 0x00, 0x00, 0x00, 0x41, 0x00, 
};

static const u8 data_segment_data_7[] = {
  0x01, 0x00, 0x00, 0x00, 0x61, 0x00, 
};

static const u8 data_segment_data_8[] = {
  0x0c, 0x00, 0x00, 0x00, 0x7e, 0x00, 0x6c, 0x00, 0x69, 0x00, 0x62, 0x00, 
  0x2f, 0x00, 0x6d, 0x00, 0x61, 0x00, 0x74, 0x00, 0x68, 0x00, 0x2e, 0x00, 
  0x74, 0x00, 0x73, 0x00, 
};

static const u8 data_segment_data_9[] = {
  0x0d, 0x00, 0x00, 0x00, 0x7e, 0x00, 0x6c, 0x00, 0x69, 0x00, 0x62, 0x00, 
  0x2f, 0x00, 0x61, 0x00, 0x72, 0x00, 0x72, 0x00, 0x61, 0x00, 0x79, 0x00, 
  0x2e, 0x00, 0x74, 0x00, 0x73, 0x00, 
};

static const u8 data_segment_data_10[] = {
  0x1c, 0x00, 0x00, 0x00, 0x7e, 0x00, 0x6c, 0x00, 0x69, 0x00, 0x62, 0x00, 
  0x2f, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x74, 0x00, 0x65, 0x00, 0x72, 0x00, 
  0x6e, 0x00, 0x61, 0x00, 0x6c, 0x00, 0x2f, 0x00, 0x61, 0x00, 0x72, 0x00, 
  0x72, 0x00, 0x61, 0x00, 0x79, 0x00, 0x62, 0x00, 0x75, 0x00, 0x66, 0x00, 
  0x66, 0x00, 0x65, 0x00, 0x72, 0x00, 0x2e, 0x00, 0x74, 0x00, 0x73, 0x00, 
  
};

static const u8 data_segment_data_11[] = {
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_12[] = {
  0xf8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_13[] = {
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_14[] = {
  0x08, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_15[] = {
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_16[] = {
  0x18, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_17[] = {
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_18[] = {
  0x28, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_19[] = {
  0x00, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_20[] = {
  0x11, 0x00, 0x00, 0x00, 0x61, 0x00, 0x73, 0x00, 0x73, 0x00, 0x65, 0x00, 
  0x6d, 0x00, 0x62, 0x00, 0x6c, 0x00, 0x79, 0x00, 0x2f, 0x00, 0x69, 0x00, 
  0x6e, 0x00, 0x64, 0x00, 0x65, 0x00, 0x78, 0x00, 0x2e, 0x00, 0x74, 0x00, 
  0x73, 0x00, 
};

static const u8 data_segment_data_21[] = {
  0x0b, 0x00, 0x00, 0x00, 0x63, 0x00, 0x6f, 0x00, 0x6e, 0x00, 0x73, 0x00, 
  0x74, 0x00, 0x72, 0x00, 0x61, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x74, 0x00, 
  0x31, 0x00, 
};

static const u8 data_segment_data_22[] = {
  0x1b, 0x00, 0x00, 0x00, 0x7e, 0x00, 0x6c, 0x00, 0x69, 0x00, 0x62, 0x00, 
  0x2f, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x74, 0x00, 0x65, 0x00, 0x72, 0x00, 
  0x6e, 0x00, 0x61, 0x00, 0x6c, 0x00, 0x2f, 0x00, 0x74, 0x00, 0x79, 0x00, 
  0x70, 0x00, 0x65, 0x00, 0x64, 0x00, 0x61, 0x00, 0x72, 0x00, 0x72, 0x00, 
  0x61, 0x00, 0x79, 0x00, 0x2e, 0x00, 0x74, 0x00, 0x73, 0x00, 
};

static const u8 data_segment_data_23[] = {
  0x13, 0x00, 0x00, 0x00, 0x49, 0x00, 0x6e, 0x00, 0x76, 0x00, 0x61, 0x00, 
  0x6c, 0x00, 0x69, 0x00, 0x64, 0x00, 0x20, 0x00, 0x63, 0x00, 0x6f, 0x00, 
  0x6e, 0x00, 0x73, 0x00, 0x74, 0x00, 0x72, 0x00, 0x61, 0x00, 0x69, 0x00, 
  0x6e, 0x00, 0x74, 0x00, 0x31, 0x00, 
};

static const u8 data_segment_data_24[] = {
  0x13, 0x00, 0x00, 0x00, 0x7e, 0x00, 0x6c, 0x00, 0x69, 0x00, 0x62, 0x00, 
  0x2f, 0x00, 0x61, 0x00, 0x72, 0x00, 0x72, 0x00, 0x61, 0x00, 0x79, 0x00, 
  0x62, 0x00, 0x75, 0x00, 0x66, 0x00, 0x66, 0x00, 0x65, 0x00, 0x72, 0x00, 
  0x2e, 0x00, 0x74, 0x00, 0x73, 0x00, 
};

static const u8 data_segment_data_25[] = {
  0x0b, 0x00, 0x00, 0x00, 0x63, 0x00, 0x6f, 0x00, 0x6e, 0x00, 0x73, 0x00, 
  0x74, 0x00, 0x72, 0x00, 0x61, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x74, 0x00, 
  0x32, 0x00, 
};

static const u8 data_segment_data_26[] = {
  0x05, 0x00, 0x00, 0x00, 0x76, 0x00, 0x61, 0x00, 0x6c, 0x00, 0x75, 0x00, 
  0x65, 0x00, 
};

static const u8 data_segment_data_27[] = {
  0x17, 0x00, 0x00, 0x00, 0x7e, 0x00, 0x6c, 0x00, 0x69, 0x00, 0x62, 0x00, 
  0x2f, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x74, 0x00, 0x65, 0x00, 0x72, 0x00, 
  0x6e, 0x00, 0x61, 0x00, 0x6c, 0x00, 0x2f, 0x00, 0x73, 0x00, 0x74, 0x00, 
  0x72, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x67, 0x00, 0x2e, 0x00, 0x74, 0x00, 
  0x73, 0x00, 
};

static const u8 data_segment_data_28[] = {
  0x90, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30, 0x00, 0x30, 0x00, 
  0x30, 0x00, 0x31, 0x00, 0x30, 0x00, 0x32, 0x00, 0x30, 0x00, 0x33, 0x00, 
  0x30, 0x00, 0x34, 0x00, 0x30, 0x00, 0x35, 0x00, 0x30, 0x00, 0x36, 0x00, 
  0x30, 0x00, 0x37, 0x00, 0x30, 0x00, 0x38, 0x00, 0x30, 0x00, 0x39, 0x00, 
  0x31, 0x00, 0x30, 0x00, 0x31, 0x00, 0x31, 0x00, 0x31, 0x00, 0x32, 0x00, 
  0x31, 0x00, 0x33, 0x00, 0x31, 0x00, 0x34, 0x00, 0x31, 0x00, 0x35, 0x00, 
  0x31, 0x00, 0x36, 0x00, 0x31, 0x00, 0x37, 0x00, 0x31, 0x00, 0x38, 0x00, 
  0x31, 0x00, 0x39, 0x00, 0x32, 0x00, 0x30, 0x00, 0x32, 0x00, 0x31, 0x00, 
  0x32, 0x00, 0x32, 0x00, 0x32, 0x00, 0x33, 0x00, 0x32, 0x00, 0x34, 0x00, 
  0x32, 0x00, 0x35, 0x00, 0x32, 0x00, 0x36, 0x00, 0x32, 0x00, 0x37, 0x00, 
  0x32, 0x00, 0x38, 0x00, 0x32, 0x00, 0x39, 0x00, 0x33, 0x00, 0x30, 0x00, 
  0x33, 0x00, 0x31, 0x00, 0x33, 0x00, 0x32, 0x00, 0x33, 0x00, 0x33, 0x00, 
  0x33, 0x00, 0x34, 0x00, 0x33, 0x00, 0x35, 0x00, 0x33, 0x00, 0x36, 0x00, 
  0x33, 0x00, 0x37, 0x00, 0x33, 0x00, 0x38, 0x00, 0x33, 0x00, 0x39, 0x00, 
  0x34, 0x00, 0x30, 0x00, 0x34, 0x00, 0x31, 0x00, 0x34, 0x00, 0x32, 0x00, 
  0x34, 0x00, 0x33, 0x00, 0x34, 0x00, 0x34, 0x00, 0x34, 0x00, 0x35, 0x00, 
  0x34, 0x00, 0x36, 0x00, 0x34, 0x00, 0x37, 0x00, 0x34, 0x00, 0x38, 0x00, 
  0x34, 0x00, 0x39, 0x00, 0x35, 0x00, 0x30, 0x00, 0x35, 0x00, 0x31, 0x00, 
  0x35, 0x00, 0x32, 0x00, 0x35, 0x00, 0x33, 0x00, 0x35, 0x00, 0x34, 0x00, 
  0x35, 0x00, 0x35, 0x00, 0x35, 0x00, 0x36, 0x00, 0x35, 0x00, 0x37, 0x00, 
  0x35, 0x00, 0x38, 0x00, 0x35, 0x00, 0x39, 0x00, 0x36, 0x00, 0x30, 0x00, 
  0x36, 0x00, 0x31, 0x00, 0x36, 0x00, 0x32, 0x00, 0x36, 0x00, 0x33, 0x00, 
  0x36, 0x00, 0x34, 0x00, 0x36, 0x00, 0x35, 0x00, 0x36, 0x00, 0x36, 0x00, 
  0x36, 0x00, 0x37, 0x00, 0x36, 0x00, 0x38, 0x00, 0x36, 0x00, 0x39, 0x00, 
  0x37, 0x00, 0x30, 0x00, 0x37, 0x00, 0x31, 0x00, 0x37, 0x00, 0x32, 0x00, 
  0x37, 0x00, 0x33, 0x00, 0x37, 0x00, 0x34, 0x00, 0x37, 0x00, 0x35, 0x00, 
  0x37, 0x00, 0x36, 0x00, 0x37, 0x00, 0x37, 0x00, 0x37, 0x00, 0x38, 0x00, 
  0x37, 0x00, 0x39, 0x00, 0x38, 0x00, 0x30, 0x00, 0x38, 0x00, 0x31, 0x00, 
  0x38, 0x00, 0x32, 0x00, 0x38, 0x00, 0x33, 0x00, 0x38, 0x00, 0x34, 0x00, 
  0x38, 0x00, 0x35, 0x00, 0x38, 0x00, 0x36, 0x00, 0x38, 0x00, 0x37, 0x00, 
  0x38, 0x00, 0x38, 0x00, 0x38, 0x00, 0x39, 0x00, 0x39, 0x00, 0x30, 0x00, 
  0x39, 0x00, 0x31, 0x00, 0x39, 0x00, 0x32, 0x00, 0x39, 0x00, 0x33, 0x00, 
  0x39, 0x00, 0x34, 0x00, 0x39, 0x00, 0x35, 0x00, 0x39, 0x00, 0x36, 0x00, 
  0x39, 0x00, 0x37, 0x00, 0x39, 0x00, 0x38, 0x00, 0x39, 0x00, 0x39, 0x00, 
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_29[] = {
  0x90, 0x02, 0x00, 0x00, 0x64, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_30[] = {
  0x01, 0x00, 0x00, 0x00, 0x2c, 0x00, 
};

static const u8 data_segment_data_31[] = {
  0x01, 0x00, 0x00, 0x00, 0x22, 0x00, 
};

static const u8 data_segment_data_32[] = {
  0x01, 0x00, 0x00, 0x00, 0x5c, 0x00, 
};

static const u8 data_segment_data_33[] = {
  0x02, 0x00, 0x00, 0x00, 0x5c, 0x00, 0x22, 0x00, 
};

static const u8 data_segment_data_34[] = {
  0x02, 0x00, 0x00, 0x00, 0x5c, 0x00, 0x5c, 0x00, 
};

static const u8 data_segment_data_35[] = {
  0x01, 0x00, 0x00, 0x00, 0x08, 0x00, 
};

static const u8 data_segment_data_36[] = {
  0x02, 0x00, 0x00, 0x00, 0x5c, 0x00, 0x62, 0x00, 
};

static const u8 data_segment_data_37[] = {
  0x01, 0x00, 0x00, 0x00, 0x0a, 0x00, 
};

static const u8 data_segment_data_38[] = {
  0x02, 0x00, 0x00, 0x00, 0x5c, 0x00, 0x6e, 0x00, 
};

static const u8 data_segment_data_39[] = {
  0x01, 0x00, 0x00, 0x00, 0x0d, 0x00, 
};

static const u8 data_segment_data_40[] = {
  0x02, 0x00, 0x00, 0x00, 0x5c, 0x00, 0x72, 0x00, 
};

static const u8 data_segment_data_41[] = {
  0x01, 0x00, 0x00, 0x00, 0x09, 0x00, 
};

static const u8 data_segment_data_42[] = {
  0x02, 0x00, 0x00, 0x00, 0x5c, 0x00, 0x74, 0x00, 
};

static const u8 data_segment_data_43[] = {
  0x24, 0x00, 0x00, 0x00, 0x55, 0x00, 0x6e, 0x00, 0x73, 0x00, 0x75, 0x00, 
  0x70, 0x00, 0x70, 0x00, 0x6f, 0x00, 0x72, 0x00, 0x74, 0x00, 0x65, 0x00, 
  0x64, 0x00, 0x20, 0x00, 0x63, 0x00, 0x6f, 0x00, 0x6e, 0x00, 0x74, 0x00, 
  0x72, 0x00, 0x6f, 0x00, 0x6c, 0x00, 0x20, 0x00, 0x63, 0x00, 0x68, 0x00, 
  0x61, 0x00, 0x72, 0x00, 0x61, 0x00, 0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 
  0x72, 0x00, 0x20, 0x00, 0x63, 0x00, 0x6f, 0x00, 0x64, 0x00, 0x65, 0x00, 
  0x3a, 0x00, 0x20, 0x00, 
};

static const u8 data_segment_data_44[] = {
  0x37, 0x00, 0x00, 0x00, 0x2e, 0x00, 0x2e, 0x00, 0x2f, 0x00, 0x6e, 0x00, 
  0x6f, 0x00, 0x64, 0x00, 0x65, 0x00, 0x5f, 0x00, 0x6d, 0x00, 0x6f, 0x00, 
  0x64, 0x00, 0x75, 0x00, 0x6c, 0x00, 0x65, 0x00, 0x73, 0x00, 0x2f, 0x00, 
  0x61, 0x00, 0x73, 0x00, 0x73, 0x00, 0x65, 0x00, 0x6d, 0x00, 0x62, 0x00, 
  0x6c, 0x00, 0x79, 0x00, 0x73, 0x00, 0x63, 0x00, 0x72, 0x00, 0x69, 0x00, 
  0x70, 0x00, 0x74, 0x00, 0x2d, 0x00, 0x6a, 0x00, 0x73, 0x00, 0x6f, 0x00, 
  0x6e, 0x00, 0x2f, 0x00, 0x61, 0x00, 0x73, 0x00, 0x73, 0x00, 0x65, 0x00, 
  0x6d, 0x00, 0x62, 0x00, 0x6c, 0x00, 0x79, 0x00, 0x2f, 0x00, 0x65, 0x00, 
  0x6e, 0x00, 0x63, 0x00, 0x6f, 0x00, 0x64, 0x00, 0x65, 0x00, 0x72, 0x00, 
  0x2e, 0x00, 0x74, 0x00, 0x73, 0x00, 
};

static const u8 data_segment_data_45[] = {
  0x01, 0x00, 0x00, 0x00, 0x3a, 0x00, 
};

static const u8 data_segment_data_46[] = {
  0x01, 0x00, 0x00, 0x00, 0x5b, 0x00, 
};

static const u8 data_segment_data_47[] = {
  0x01, 0x00, 0x00, 0x00, 0x7b, 0x00, 
};

static const u8 data_segment_data_48[] = {
  0x01, 0x00, 0x00, 0x00, 0x7d, 0x00, 
};

static const u8 data_segment_data_49[] = {
  0x01, 0x00, 0x00, 0x00, 0x5d, 0x00, 
};

static const u8 data_segment_data_50[] = {
  0x0b, 0x00, 0x00, 0x00, 0x63, 0x00, 0x6f, 0x00, 0x6e, 0x00, 0x73, 0x00, 
  0x74, 0x00, 0x72, 0x00, 0x61, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x74, 0x00, 
  0x33, 0x00, 
};

static const u8 data_segment_data_51[] = {
  0x14, 0x00, 0x00, 0x00, 0x55, 0x00, 0x6e, 0x00, 0x65, 0x00, 0x78, 0x00, 
  0x70, 0x00, 0x65, 0x00, 0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 0x64, 0x00, 
  0x20, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x70, 0x00, 0x75, 0x00, 0x74, 0x00, 
  0x20, 0x00, 0x65, 0x00, 0x6e, 0x00, 0x64, 0x00, 
};

static const u8 data_segment_data_52[] = {
  0x37, 0x00, 0x00, 0x00, 0x2e, 0x00, 0x2e, 0x00, 0x2f, 0x00, 0x6e, 0x00, 
  0x6f, 0x00, 0x64, 0x00, 0x65, 0x00, 0x5f, 0x00, 0x6d, 0x00, 0x6f, 0x00, 
  0x64, 0x00, 0x75, 0x00, 0x6c, 0x00, 0x65, 0x00, 0x73, 0x00, 0x2f, 0x00, 
  0x61, 0x00, 0x73, 0x00, 0x73, 0x00, 0x65, 0x00, 0x6d, 0x00, 0x62, 0x00, 
  0x6c, 0x00, 0x79, 0x00, 0x73, 0x00, 0x63, 0x00, 0x72, 0x00, 0x69, 0x00, 
  0x70, 0x00, 0x74, 0x00, 0x2d, 0x00, 0x6a, 0x00, 0x73, 0x00, 0x6f, 0x00, 
  0x6e, 0x00, 0x2f, 0x00, 0x61, 0x00, 0x73, 0x00, 0x73, 0x00, 0x65, 0x00, 
  0x6d, 0x00, 0x62, 0x00, 0x6c, 0x00, 0x79, 0x00, 0x2f, 0x00, 0x64, 0x00, 
  0x65, 0x00, 0x63, 0x00, 0x6f, 0x00, 0x64, 0x00, 0x65, 0x00, 0x72, 0x00, 
  0x2e, 0x00, 0x74, 0x00, 0x73, 0x00, 
};

static const u8 data_segment_data_53[] = {
  0x0c, 0x00, 0x00, 0x00, 0x45, 0x00, 0x78, 0x00, 0x70, 0x00, 0x65, 0x00, 
  0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 0x64, 0x00, 0x20, 0x00, 0x27, 0x00, 
  0x2c, 0x00, 0x27, 0x00, 
};

static const u8 data_segment_data_54[] = {
  0x1d, 0x00, 0x00, 0x00, 0x45, 0x00, 0x78, 0x00, 0x70, 0x00, 0x65, 0x00, 
  0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 0x64, 0x00, 0x20, 0x00, 0x64, 0x00, 
  0x6f, 0x00, 0x75, 0x00, 0x62, 0x00, 0x6c, 0x00, 0x65, 0x00, 0x2d, 0x00, 
  0x71, 0x00, 0x75, 0x00, 0x6f, 0x00, 0x74, 0x00, 0x65, 0x00, 0x64, 0x00, 
  0x20, 0x00, 0x73, 0x00, 0x74, 0x00, 0x72, 0x00, 0x69, 0x00, 0x6e, 0x00, 
  0x67, 0x00, 
};

static const u8 data_segment_data_55[] = {
  0x1c, 0x00, 0x00, 0x00, 0x55, 0x00, 0x6e, 0x00, 0x65, 0x00, 0x78, 0x00, 
  0x70, 0x00, 0x65, 0x00, 0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 0x64, 0x00, 
  0x20, 0x00, 0x63, 0x00, 0x6f, 0x00, 0x6e, 0x00, 0x74, 0x00, 0x72, 0x00, 
  0x6f, 0x00, 0x6c, 0x00, 0x20, 0x00, 0x63, 0x00, 0x68, 0x00, 0x61, 0x00, 
  0x72, 0x00, 0x61, 0x00, 0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 0x72, 0x00, 
  
};

static const u8 data_segment_data_56[] = {
  0x01, 0x00, 0x00, 0x00, 0x2f, 0x00, 
};

static const u8 data_segment_data_57[] = {
  0x01, 0x00, 0x00, 0x00, 0x62, 0x00, 
};

static const u8 data_segment_data_58[] = {
  0x01, 0x00, 0x00, 0x00, 0x6e, 0x00, 
};

static const u8 data_segment_data_59[] = {
  0x01, 0x00, 0x00, 0x00, 0x72, 0x00, 
};

static const u8 data_segment_data_60[] = {
  0x01, 0x00, 0x00, 0x00, 0x74, 0x00, 
};

static const u8 data_segment_data_61[] = {
  0x01, 0x00, 0x00, 0x00, 0x75, 0x00, 
};

static const u8 data_segment_data_62[] = {
  0x13, 0x00, 0x00, 0x00, 0x55, 0x00, 0x6e, 0x00, 0x65, 0x00, 0x78, 0x00, 
  0x70, 0x00, 0x65, 0x00, 0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 0x64, 0x00, 
  0x20, 0x00, 0x5c, 0x00, 0x75, 0x00, 0x20, 0x00, 0x64, 0x00, 0x69, 0x00, 
  0x67, 0x00, 0x69, 0x00, 0x74, 0x00, 
};

static const u8 data_segment_data_63[] = {
  0x1e, 0x00, 0x00, 0x00, 0x55, 0x00, 0x6e, 0x00, 0x65, 0x00, 0x78, 0x00, 
  0x70, 0x00, 0x65, 0x00, 0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 0x64, 0x00, 
  0x20, 0x00, 0x65, 0x00, 0x73, 0x00, 0x63, 0x00, 0x61, 0x00, 0x70, 0x00, 
  0x65, 0x00, 0x64, 0x00, 0x20, 0x00, 0x63, 0x00, 0x68, 0x00, 0x61, 0x00, 
  0x72, 0x00, 0x61, 0x00, 0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 0x72, 0x00, 
  0x3a, 0x00, 0x20, 0x00, 
};

static const u8 data_segment_data_64[] = {
  0x0c, 0x00, 0x00, 0x00, 0x45, 0x00, 0x78, 0x00, 0x70, 0x00, 0x65, 0x00, 
  0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 0x64, 0x00, 0x20, 0x00, 0x27, 0x00, 
  0x3a, 0x00, 0x27, 0x00, 
};

static const u8 data_segment_data_65[] = {
  0x18, 0x00, 0x00, 0x00, 0x55, 0x00, 0x6e, 0x00, 0x65, 0x00, 0x78, 0x00, 
  0x70, 0x00, 0x65, 0x00, 0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 0x64, 0x00, 
  0x20, 0x00, 0x65, 0x00, 0x6e, 0x00, 0x64, 0x00, 0x20, 0x00, 0x6f, 0x00, 
  0x66, 0x00, 0x20, 0x00, 0x6f, 0x00, 0x62, 0x00, 0x6a, 0x00, 0x65, 0x00, 
  0x63, 0x00, 0x74, 0x00, 
};

static const u8 data_segment_data_66[] = {
  0x17, 0x00, 0x00, 0x00, 0x55, 0x00, 0x6e, 0x00, 0x65, 0x00, 0x78, 0x00, 
  0x70, 0x00, 0x65, 0x00, 0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 0x64, 0x00, 
  0x20, 0x00, 0x65, 0x00, 0x6e, 0x00, 0x64, 0x00, 0x20, 0x00, 0x6f, 0x00, 
  0x66, 0x00, 0x20, 0x00, 0x61, 0x00, 0x72, 0x00, 0x72, 0x00, 0x61, 0x00, 
  0x79, 0x00, 
};

static const u8 data_segment_data_67[] = {
  0x0a, 0x00, 0x00, 0x00, 0x45, 0x00, 0x78, 0x00, 0x70, 0x00, 0x65, 0x00, 
  0x63, 0x00, 0x74, 0x00, 0x65, 0x00, 0x64, 0x00, 0x20, 0x00, 0x27, 0x00, 
  
};

static const u8 data_segment_data_68[] = {
  0x01, 0x00, 0x00, 0x00, 0x27, 0x00, 
};

static const u8 data_segment_data_69[] = {
  0x01, 0x00, 0x00, 0x00, 0x2d, 0x00, 
};

static const u8 data_segment_data_70[] = {
  0x11, 0x00, 0x00, 0x00, 0x43, 0x00, 0x61, 0x00, 0x6e, 0x00, 0x6e, 0x00, 
  0x6f, 0x00, 0x74, 0x00, 0x20, 0x00, 0x70, 0x00, 0x61, 0x00, 0x72, 0x00, 
  0x73, 0x00, 0x65, 0x00, 0x20, 0x00, 0x4a, 0x00, 0x53, 0x00, 0x4f, 0x00, 
  0x4e, 0x00, 
};

static const u8 data_segment_data_71[] = {
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_72[] = {
  0xd8, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

static const u8 data_segment_data_73[] = {
  0x0b, 0x00, 0x00, 0x00, 0x63, 0x00, 0x6f, 0x00, 0x6e, 0x00, 0x73, 0x00, 
  0x74, 0x00, 0x72, 0x00, 0x61, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x74, 0x00, 
  0x34, 0x00, 
};

static const u8 data_segment_data_74[] = {
  0x0b, 0x00, 0x00, 0x00, 0x63, 0x00, 0x6f, 0x00, 0x6e, 0x00, 0x73, 0x00, 
  0x74, 0x00, 0x72, 0x00, 0x61, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x74, 0x00, 
  0x35, 0x00, 
};

static const u8 data_segment_data_75[] = {
  0x0b, 0x00, 0x00, 0x00, 0x63, 0x00, 0x6f, 0x00, 0x6e, 0x00, 0x73, 0x00, 
  0x74, 0x00, 0x72, 0x00, 0x61, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x74, 0x00, 
  0x36, 0x00, 
};

static const u8 data_segment_data_76[] = {
  0x0a, 0x00, 0x00, 0x00, 0x47, 0x00, 0x65, 0x00, 0x6e, 0x00, 0x65, 0x00, 
  0x72, 0x00, 0x61, 0x00, 0x74, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x67, 0x00, 
  
};

static const u8 data_segment_data_77[] = {
  0x01, 0x00, 0x00, 0x00, 0x70, 0x00, 
};

static const u8 data_segment_data_78[] = {
  0x03, 0x00, 0x00, 0x00, 0x74, 0x00, 0x2e, 0x00, 0x78, 0x00, 
};

static const u8 data_segment_data_79[] = {
  0x03, 0x00, 0x00, 0x00, 0x74, 0x00, 0x2e, 0x00, 0x79, 0x00, 
};

static const u8 data_segment_data_80[] = {
  0x10, 0x00, 0x00, 0x00, 0x74, 0x00, 0x2e, 0x00, 0x63, 0x00, 0x6c, 0x00, 
  0x61, 0x00, 0x73, 0x00, 0x73, 0x00, 0x69, 0x00, 0x66, 0x00, 0x69, 0x00, 
  0x63, 0x00, 0x61, 0x00, 0x74, 0x00, 0x69, 0x00, 0x6f, 0x00, 0x6e, 0x00, 
  
};

static const u8 data_segment_data_81[] = {
  0x10, 0x00, 0x00, 0x00, 0x74, 0x00, 0x2e, 0x00, 0x73, 0x00, 0x65, 0x00, 
  0x72, 0x00, 0x69, 0x00, 0x61, 0x00, 0x6c, 0x00, 0x69, 0x00, 0x7a, 0x00, 
  0x65, 0x00, 0x64, 0x00, 0x41, 0x00, 0x72, 0x00, 0x67, 0x00, 0x73, 0x00, 
  
};

static const u8 data_segment_data_82[] = {
  0x08, 0x00, 0x00, 0x00, 0x42, 0x00, 0x61, 0x00, 0x64, 0x00, 0x20, 0x00, 
  0x61, 0x00, 0x72, 0x00, 0x67, 0x00, 0x73, 0x00, 
};

static const u8 data_segment_data_83[] = {
  0x08, 0x00, 0x00, 0x00, 0x42, 0x00, 0x61, 0x00, 0x64, 0x00, 0x20, 0x00, 
  0x6b, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x64, 0x00, 
};

static const u8 data_segment_data_84[] = {
  0x01, 0x00, 0x00, 0x00, 0x78, 0x00, 
};

static const u8 data_segment_data_85[] = {
  0x01, 0x00, 0x00, 0x00, 0x79, 0x00, 
};

static void init_memory(void) {
  wasm_rt_allocate_memory((&memory), 1, 65536);
  memcpy(&(memory.data[8u]), data_segment_data_0, 12);
  memcpy(&(memory.data[24u]), data_segment_data_1, 14);
  memcpy(&(memory.data[40u]), data_segment_data_2, 12);
  memcpy(&(memory.data[56u]), data_segment_data_3, 6);
  memcpy(&(memory.data[64u]), data_segment_data_4, 32);
  memcpy(&(memory.data[96u]), data_segment_data_5, 6);
  memcpy(&(memory.data[104u]), data_segment_data_6, 6);
  memcpy(&(memory.data[112u]), data_segment_data_7, 6);
  memcpy(&(memory.data[120u]), data_segment_data_8, 28);
  memcpy(&(memory.data[152u]), data_segment_data_9, 30);
  memcpy(&(memory.data[184u]), data_segment_data_10, 60);
  memcpy(&(memory.data[248u]), data_segment_data_11, 8);
  memcpy(&(memory.data[256u]), data_segment_data_12, 8);
  memcpy(&(memory.data[264u]), data_segment_data_13, 8);
  memcpy(&(memory.data[272u]), data_segment_data_14, 8);
  memcpy(&(memory.data[280u]), data_segment_data_15, 8);
  memcpy(&(memory.data[288u]), data_segment_data_16, 8);
  memcpy(&(memory.data[296u]), data_segment_data_17, 8);
  memcpy(&(memory.data[304u]), data_segment_data_18, 8);
  memcpy(&(memory.data[312u]), data_segment_data_19, 4);
  memcpy(&(memory.data[320u]), data_segment_data_20, 38);
  memcpy(&(memory.data[360u]), data_segment_data_21, 26);
  memcpy(&(memory.data[392u]), data_segment_data_22, 58);
  memcpy(&(memory.data[456u]), data_segment_data_23, 42);
  memcpy(&(memory.data[504u]), data_segment_data_24, 42);
  memcpy(&(memory.data[552u]), data_segment_data_25, 26);
  memcpy(&(memory.data[584u]), data_segment_data_26, 14);
  memcpy(&(memory.data[600u]), data_segment_data_27, 50);
  memcpy(&(memory.data[656u]), data_segment_data_28, 512);
  memcpy(&(memory.data[1168u]), data_segment_data_29, 8);
  memcpy(&(memory.data[1176u]), data_segment_data_30, 6);
  memcpy(&(memory.data[1184u]), data_segment_data_31, 6);
  memcpy(&(memory.data[1192u]), data_segment_data_32, 6);
  memcpy(&(memory.data[1200u]), data_segment_data_33, 8);
  memcpy(&(memory.data[1208u]), data_segment_data_34, 8);
  memcpy(&(memory.data[1216u]), data_segment_data_35, 6);
  memcpy(&(memory.data[1224u]), data_segment_data_36, 8);
  memcpy(&(memory.data[1232u]), data_segment_data_37, 6);
  memcpy(&(memory.data[1240u]), data_segment_data_38, 8);
  memcpy(&(memory.data[1248u]), data_segment_data_39, 6);
  memcpy(&(memory.data[1256u]), data_segment_data_40, 8);
  memcpy(&(memory.data[1264u]), data_segment_data_41, 6);
  memcpy(&(memory.data[1272u]), data_segment_data_42, 8);
  memcpy(&(memory.data[1280u]), data_segment_data_43, 76);
  memcpy(&(memory.data[1360u]), data_segment_data_44, 114);
  memcpy(&(memory.data[1480u]), data_segment_data_45, 6);
  memcpy(&(memory.data[1488u]), data_segment_data_46, 6);
  memcpy(&(memory.data[1496u]), data_segment_data_47, 6);
  memcpy(&(memory.data[1504u]), data_segment_data_48, 6);
  memcpy(&(memory.data[1512u]), data_segment_data_49, 6);
  memcpy(&(memory.data[1520u]), data_segment_data_50, 26);
  memcpy(&(memory.data[1552u]), data_segment_data_51, 44);
  memcpy(&(memory.data[1600u]), data_segment_data_52, 114);
  memcpy(&(memory.data[1720u]), data_segment_data_53, 28);
  memcpy(&(memory.data[1752u]), data_segment_data_54, 62);
  memcpy(&(memory.data[1816u]), data_segment_data_55, 60);
  memcpy(&(memory.data[1880u]), data_segment_data_56, 6);
  memcpy(&(memory.data[1888u]), data_segment_data_57, 6);
  memcpy(&(memory.data[1896u]), data_segment_data_58, 6);
  memcpy(&(memory.data[1904u]), data_segment_data_59, 6);
  memcpy(&(memory.data[1912u]), data_segment_data_60, 6);
  memcpy(&(memory.data[1920u]), data_segment_data_61, 6);
  memcpy(&(memory.data[1928u]), data_segment_data_62, 42);
  memcpy(&(memory.data[1976u]), data_segment_data_63, 64);
  memcpy(&(memory.data[2040u]), data_segment_data_64, 28);
  memcpy(&(memory.data[2072u]), data_segment_data_65, 52);
  memcpy(&(memory.data[2128u]), data_segment_data_66, 50);
  memcpy(&(memory.data[2184u]), data_segment_data_67, 24);
  memcpy(&(memory.data[2208u]), data_segment_data_68, 6);
  memcpy(&(memory.data[2216u]), data_segment_data_69, 6);
  memcpy(&(memory.data[2224u]), data_segment_data_70, 38);
  memcpy(&(memory.data[2264u]), data_segment_data_71, 8);
  memcpy(&(memory.data[2272u]), data_segment_data_72, 8);
  memcpy(&(memory.data[2280u]), data_segment_data_73, 26);
  memcpy(&(memory.data[2312u]), data_segment_data_74, 26);
  memcpy(&(memory.data[2344u]), data_segment_data_75, 26);
  memcpy(&(memory.data[2376u]), data_segment_data_76, 24);
  memcpy(&(memory.data[2400u]), data_segment_data_77, 6);
  memcpy(&(memory.data[2408u]), data_segment_data_78, 10);
  memcpy(&(memory.data[2424u]), data_segment_data_79, 10);
  memcpy(&(memory.data[2440u]), data_segment_data_80, 36);
  memcpy(&(memory.data[2480u]), data_segment_data_81, 36);
  memcpy(&(memory.data[2520u]), data_segment_data_82, 20);
  memcpy(&(memory.data[2544u]), data_segment_data_83, 20);
  memcpy(&(memory.data[2568u]), data_segment_data_84, 6);
  memcpy(&(memory.data[2576u]), data_segment_data_85, 6);
}

static void init_table(void) {
  uint32_t offset;
  wasm_rt_allocate_table((&table), 17, 4294967295);
  offset = 0u;
  table.data[offset + 0] = (wasm_rt_elem_t){func_types[0], (wasm_rt_anyfunc_t)(&null)};
  table.data[offset + 1] = (wasm_rt_elem_t){func_types[6], (wasm_rt_anyfunc_t)(&start_assembly_index_anonymous_0)};
  table.data[offset + 2] = (wasm_rt_elem_t){func_types[6], (wasm_rt_anyfunc_t)(&start_assembly_index_anonymous_1)};
  table.data[offset + 3] = (wasm_rt_elem_t){func_types[15], (wasm_rt_anyfunc_t)(&assembly_index_Constraint2_gen_anonymous_0)};
  table.data[offset + 4] = (wasm_rt_elem_t){func_types[10], (wasm_rt_anyfunc_t)(&assembly_index_Constraint3_check_anonymous_0)};
  table.data[offset + 5] = (wasm_rt_elem_t){func_types[6], (wasm_rt_anyfunc_t)(&assembly_index_Constraint3_check_anonymous_1)};
  table.data[offset + 6] = (wasm_rt_elem_t){func_types[6], (wasm_rt_anyfunc_t)(&assembly_index_Constraint3_check_anonymous_2)};
  table.data[offset + 7] = (wasm_rt_elem_t){func_types[6], (wasm_rt_anyfunc_t)(&assembly_index_Constraint3_check_anonymous_3)};
  table.data[offset + 8] = (wasm_rt_elem_t){func_types[6], (wasm_rt_anyfunc_t)(&assembly_index_Constraint3_check_anonymous_4)};
  table.data[offset + 9] = (wasm_rt_elem_t){func_types[6], (wasm_rt_anyfunc_t)(&assembly_index_Constraint3_gen_anonymous_0)};
  table.data[offset + 10] = (wasm_rt_elem_t){func_types[6], (wasm_rt_anyfunc_t)(&assembly_index_Constraint3_gen_anonymous_1)};
  table.data[offset + 11] = (wasm_rt_elem_t){func_types[14], (wasm_rt_anyfunc_t)(&assembly_index_encodeI32)};
  table.data[offset + 12] = (wasm_rt_elem_t){func_types[6], (wasm_rt_anyfunc_t)(&assembly_index_decodeI32)};
  table.data[offset + 13] = (wasm_rt_elem_t){func_types[6], (wasm_rt_anyfunc_t)(&assembly_index_decodeBoardMatrixElement)};
  table.data[offset + 14] = (wasm_rt_elem_t){func_types[6], (wasm_rt_anyfunc_t)(&assembly_index_decodePartitionListElement)};
  table.data[offset + 15] = (wasm_rt_elem_t){func_types[14], (wasm_rt_anyfunc_t)(&assembly_index_encodeBoardMatrixElement)};
  table.data[offset + 16] = (wasm_rt_elem_t){func_types[14], (wasm_rt_anyfunc_t)(&assembly_index_encodePartitionListElement)};
}

/* export: 'memory' */
wasm_rt_memory_t (*WASM_RT_ADD_PREFIX(Z_memory));
/* export: 'table' */
wasm_rt_table_t (*WASM_RT_ADD_PREFIX(Z_table));
/* export: 'genShuff' */
u32 (*WASM_RT_ADD_PREFIX(Z_genShuffZ_i));
/* export: 'copyPath' */
u32 (*WASM_RT_ADD_PREFIX(Z_copyPathZ_i));
/* export: 'gaussian' */
f64 (*WASM_RT_ADD_PREFIX(Z_gaussianZ_dv))(void);
/* export: 'arrayMap<PartitionListElement,PathMarker>' */
u32 (*WASM_RT_ADD_PREFIX(Z_arrayMapZ3CPartitionListElementZ2CPathMarkerZ3EZ_iii))(u32, u32);
/* export: 'arrayMap<i32>>>' */
u32 (*WASM_RT_ADD_PREFIX(Z_arrayMapZ3Ci32Z3EZ3EZ3EZ_iii))(u32, u32);
/* export: 'ArrayLen<BoardMatrixElement>>' */
u32 (*WASM_RT_ADD_PREFIX(Z_ArrayLenZ3CBoardMatrixElementZ3EZ3EZ_ii))(u32);
/* export: 'ArrayLen<BoardMatrixElement>' */
u32 (*WASM_RT_ADD_PREFIX(Z_ArrayLenZ3CBoardMatrixElementZ3EZ_ii))(u32);
/* export: 'ArrayLen<PartitionListElement>>' */
u32 (*WASM_RT_ADD_PREFIX(Z_ArrayLenZ3CPartitionListElementZ3EZ3EZ_ii))(u32);
/* export: 'ArrayLen<PartitionListElement>' */
u32 (*WASM_RT_ADD_PREFIX(Z_ArrayLenZ3CPartitionListElementZ3EZ_ii))(u32);
/* export: 'ArrayIndex<BoardMatrixElement>>' */
u32 (*WASM_RT_ADD_PREFIX(Z_ArrayIndexZ3CBoardMatrixElementZ3EZ3EZ_iii))(u32, u32);
/* export: 'ArrayIndex<BoardMatrixElement>' */
u32 (*WASM_RT_ADD_PREFIX(Z_ArrayIndexZ3CBoardMatrixElementZ3EZ_iii))(u32, u32);
/* export: 'ArrayIndex<PartitionListElement>>' */
u32 (*WASM_RT_ADD_PREFIX(Z_ArrayIndexZ3CPartitionListElementZ3EZ3EZ_iii))(u32, u32);
/* export: 'ArrayIndex<PartitionListElement>' */
u32 (*WASM_RT_ADD_PREFIX(Z_ArrayIndexZ3CPartitionListElementZ3EZ_iii))(u32, u32);
/* export: '_constrainer' */
void (*WASM_RT_ADD_PREFIX(Z__constrainerZ_vv))(void);
/* export: 'BoardMatrixElement#get:p' */
u32 (*WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23getZ3ApZ_ii))(u32);
/* export: 'BoardMatrixElement#set:p' */
void (*WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23setZ3ApZ_vii))(u32, u32);
/* export: 'BoardMatrixElement#get:t' */
u32 (*WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23getZ3AtZ_ii))(u32);
/* export: 'BoardMatrixElement#set:t' */
void (*WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23setZ3AtZ_vii))(u32, u32);
/* export: 'BoardMatrixElement#constructor' */
u32 (*WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23constructorZ_iiii))(u32, u32, u32);
/* export: 'BoardMatrixElement.create' */
u32 (*WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ2EcreateZ_iii))(u32, u32);
/* export: 'PartitionListElement#get:x' */
u32 (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23getZ3AxZ_ii))(u32);
/* export: 'PartitionListElement#set:x' */
void (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23setZ3AxZ_vii))(u32, u32);
/* export: 'PartitionListElement#get:y' */
u32 (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23getZ3AyZ_ii))(u32);
/* export: 'PartitionListElement#set:y' */
void (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23setZ3AyZ_vii))(u32, u32);
/* export: 'PartitionListElement#get:t' */
u32 (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23getZ3AtZ_ii))(u32);
/* export: 'PartitionListElement#set:t' */
void (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23setZ3AtZ_vii))(u32, u32);
/* export: 'PartitionListElement#constructor' */
u32 (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23constructorZ_iiiii))(u32, u32, u32, u32);
/* export: 'PartitionListElement.create' */
u32 (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ2EcreateZ_iiii))(u32, u32, u32);
/* export: 'Constraint#get:x' */
u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AxZ_ii))(u32);
/* export: 'Constraint#set:x' */
void (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint#get:y' */
u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AyZ_ii))(u32);
/* export: 'Constraint#set:y' */
void (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint#get:classification' */
u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint#set:classification' */
void (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint#get:name' */
u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AnameZ_ii))(u32);
/* export: 'Constraint#set:name' */
void (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint#get:serializedArgs' */
u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint#set:serializedArgs' */
void (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint#constructor' */
u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint#col' */
void (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint.check' */
u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint.gen' */
u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'Constraint1#get:x' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AxZ_ii))(u32);
/* export: 'Constraint1#set:x' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint1#get:y' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AyZ_ii))(u32);
/* export: 'Constraint1#set:y' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint1#get:classification' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint1#set:classification' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint1#get:name' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AnameZ_ii))(u32);
/* export: 'Constraint1#set:name' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint1#get:serializedArgs' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint1#set:serializedArgs' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint1#constructor' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint1#col' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint1.check' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint1.gen' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'Constraint2#get:x' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AxZ_ii))(u32);
/* export: 'Constraint2#set:x' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint2#get:y' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AyZ_ii))(u32);
/* export: 'Constraint2#set:y' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint2#get:classification' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint2#set:classification' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint2#get:name' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AnameZ_ii))(u32);
/* export: 'Constraint2#set:name' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint2#get:serializedArgs' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint2#set:serializedArgs' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint2#constructor' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint2#col' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint2.gen' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'Constraint2.check' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint3#get:x' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AxZ_ii))(u32);
/* export: 'Constraint3#set:x' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint3#get:y' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AyZ_ii))(u32);
/* export: 'Constraint3#set:y' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint3#get:classification' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint3#set:classification' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint3#get:name' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AnameZ_ii))(u32);
/* export: 'Constraint3#set:name' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint3#get:serializedArgs' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint3#set:serializedArgs' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint3#constructor' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint3#col' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint3.brute' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z2EbruteZ_iiii))(u32, u32, u32);
/* export: 'Constraint3.check' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint3.gen' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'Constraint4#get:x' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AxZ_ii))(u32);
/* export: 'Constraint4#set:x' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint4#get:y' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AyZ_ii))(u32);
/* export: 'Constraint4#set:y' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint4#get:classification' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint4#set:classification' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint4#get:name' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AnameZ_ii))(u32);
/* export: 'Constraint4#set:name' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint4#get:serializedArgs' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint4#set:serializedArgs' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint4#constructor' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint4#col' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint4.check' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint4.gen' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'Constraint5#get:x' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AxZ_ii))(u32);
/* export: 'Constraint5#set:x' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint5#get:y' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AyZ_ii))(u32);
/* export: 'Constraint5#set:y' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint5#get:classification' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint5#set:classification' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint5#get:name' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AnameZ_ii))(u32);
/* export: 'Constraint5#set:name' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint5#get:serializedArgs' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint5#set:serializedArgs' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint5#constructor' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint5#col' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint5.check' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint5.gen' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'Constraint6#get:x' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AxZ_ii))(u32);
/* export: 'Constraint6#set:x' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint6#get:y' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AyZ_ii))(u32);
/* export: 'Constraint6#set:y' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint6#get:classification' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint6#set:classification' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint6#get:name' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AnameZ_ii))(u32);
/* export: 'Constraint6#set:name' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint6#get:serializedArgs' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint6#set:serializedArgs' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint6#constructor' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint6#col' */
void (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint6.check' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint6.gen' */
u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'checkAll' */
u32 (*WASM_RT_ADD_PREFIX(Z_checkAllZ_iiiii))(u32, u32, u32, u32);
/* export: 'State#get:mtx' */
u32 (*WASM_RT_ADD_PREFIX(Z_StateZ23getZ3AmtxZ_ii))(u32);
/* export: 'State#set:mtx' */
void (*WASM_RT_ADD_PREFIX(Z_StateZ23setZ3AmtxZ_vii))(u32, u32);
/* export: 'State#get:parts' */
u32 (*WASM_RT_ADD_PREFIX(Z_StateZ23getZ3ApartsZ_ii))(u32);
/* export: 'State#set:parts' */
void (*WASM_RT_ADD_PREFIX(Z_StateZ23setZ3ApartsZ_vii))(u32, u32);
/* export: 'State#constructor' */
u32 (*WASM_RT_ADD_PREFIX(Z_StateZ23constructorZ_iiii))(u32, u32, u32);
/* export: 'State.create' */
u32 (*WASM_RT_ADD_PREFIX(Z_StateZ2EcreateZ_iii))(u32, u32);
/* export: 'genAll' */
u32 (*WASM_RT_ADD_PREFIX(Z_genAllZ_iiiiiiiiii))(u32, u32, u32, u32, u32, u32, u32, u32, u32);
/* export: 'deserializeBoardMatrix' */
u32 (*WASM_RT_ADD_PREFIX(Z_deserializeBoardMatrixZ_ii))(u32);
/* export: 'deserializePartitionList' */
u32 (*WASM_RT_ADD_PREFIX(Z_deserializePartitionListZ_ii))(u32);
/* export: 'deserializeI32' */
u32 (*WASM_RT_ADD_PREFIX(Z_deserializeI32Z_ii))(u32);
/* export: 'MatrixEncoder<i32>' */
u32 (*WASM_RT_ADD_PREFIX(Z_MatrixEncoderZ3Ci32Z3EZ_iii))(u32, u32);
/* export: 'MatrixEncoder<BoardMatrixElement>' */
u32 (*WASM_RT_ADD_PREFIX(Z_MatrixEncoderZ3CBoardMatrixElementZ3EZ_iii))(u32, u32);
/* export: 'MatrixEncoder<PartitionListElement>' */
u32 (*WASM_RT_ADD_PREFIX(Z_MatrixEncoderZ3CPartitionListElementZ3EZ_iii))(u32, u32);
/* export: 'serializeBoardMatrix' */
u32 (*WASM_RT_ADD_PREFIX(Z_serializeBoardMatrixZ_ii))(u32);
/* export: 'serializePartitionList' */
u32 (*WASM_RT_ADD_PREFIX(Z_serializePartitionListZ_ii))(u32);
/* export: 'serializeI32' */
u32 (*WASM_RT_ADD_PREFIX(Z_serializeI32Z_ii))(u32);
/* export: 'memory.compare' */
u32 (*WASM_RT_ADD_PREFIX(Z_memoryZ2EcompareZ_iiii))(u32, u32, u32);
/* export: 'memory.allocate' */
u32 (*WASM_RT_ADD_PREFIX(Z_memoryZ2EallocateZ_ii))(u32);
/* export: 'memory.free' */
void (*WASM_RT_ADD_PREFIX(Z_memoryZ2EfreeZ_vi))(u32);
/* export: 'memory.reset' */
void (*WASM_RT_ADD_PREFIX(Z_memoryZ2EresetZ_vv))(void);

static void init_exports(void) {
  /* export: 'memory' */
  WASM_RT_ADD_PREFIX(Z_memory) = (&memory);
  /* export: 'table' */
  WASM_RT_ADD_PREFIX(Z_table) = (&table);
  /* export: 'genShuff' */
  WASM_RT_ADD_PREFIX(Z_genShuffZ_i) = (&genShuff);
  /* export: 'copyPath' */
  WASM_RT_ADD_PREFIX(Z_copyPathZ_i) = (&copyPath);
  /* export: 'gaussian' */
  WASM_RT_ADD_PREFIX(Z_gaussianZ_dv) = (&assembly_index_gaussian);
  /* export: 'arrayMap<PartitionListElement,PathMarker>' */
  WASM_RT_ADD_PREFIX(Z_arrayMapZ3CPartitionListElementZ2CPathMarkerZ3EZ_iii) = (&assembly_index_arrayMap_PartitionListElement_PathMarker_);
  /* export: 'arrayMap<i32>>>' */
  WASM_RT_ADD_PREFIX(Z_arrayMapZ3Ci32Z3EZ3EZ3EZ_iii) = (&assembly_index_arrayMap_Constraint3_Array_Array_i32___);
  /* export: 'ArrayLen<BoardMatrixElement>>' */
  WASM_RT_ADD_PREFIX(Z_ArrayLenZ3CBoardMatrixElementZ3EZ3EZ_ii) = (&assembly_index_ArrayLen_Array_BoardMatrixElement__);
  /* export: 'ArrayLen<BoardMatrixElement>' */
  WASM_RT_ADD_PREFIX(Z_ArrayLenZ3CBoardMatrixElementZ3EZ_ii) = (&assembly_index_ArrayLen_BoardMatrixElement_);
  /* export: 'ArrayLen<PartitionListElement>>' */
  WASM_RT_ADD_PREFIX(Z_ArrayLenZ3CPartitionListElementZ3EZ3EZ_ii) = (&assembly_index_ArrayLen_Array_PartitionListElement__);
  /* export: 'ArrayLen<PartitionListElement>' */
  WASM_RT_ADD_PREFIX(Z_ArrayLenZ3CPartitionListElementZ3EZ_ii) = (&assembly_index_ArrayLen_PartitionListElement_);
  /* export: 'ArrayIndex<BoardMatrixElement>>' */
  WASM_RT_ADD_PREFIX(Z_ArrayIndexZ3CBoardMatrixElementZ3EZ3EZ_iii) = (&assembly_index_ArrayIndex_Array_BoardMatrixElement__);
  /* export: 'ArrayIndex<BoardMatrixElement>' */
  WASM_RT_ADD_PREFIX(Z_ArrayIndexZ3CBoardMatrixElementZ3EZ_iii) = (&assembly_index_ArrayIndex_BoardMatrixElement_);
  /* export: 'ArrayIndex<PartitionListElement>>' */
  WASM_RT_ADD_PREFIX(Z_ArrayIndexZ3CPartitionListElementZ3EZ3EZ_iii) = (&assembly_index_ArrayIndex_Array_PartitionListElement__);
  /* export: 'ArrayIndex<PartitionListElement>' */
  WASM_RT_ADD_PREFIX(Z_ArrayIndexZ3CPartitionListElementZ3EZ_iii) = (&assembly_index_ArrayIndex_PartitionListElement_);
  /* export: '_constrainer' */
  WASM_RT_ADD_PREFIX(Z__constrainerZ_vv) = (&assembly_index__constrainer);
  /* export: 'BoardMatrixElement#get:p' */
  WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23getZ3ApZ_ii) = (&BoardMatrixElement_get_p);
  /* export: 'BoardMatrixElement#set:p' */
  WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23setZ3ApZ_vii) = (&BoardMatrixElement_set_p);
  /* export: 'BoardMatrixElement#get:t' */
  WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23getZ3AtZ_ii) = (&BoardMatrixElement_get_t);
  /* export: 'BoardMatrixElement#set:t' */
  WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23setZ3AtZ_vii) = (&BoardMatrixElement_set_t);
  /* export: 'BoardMatrixElement#constructor' */
  WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23constructorZ_iiii) = (&assembly_index_BoardMatrixElement_constructor);
  /* export: 'BoardMatrixElement.create' */
  WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ2EcreateZ_iii) = (&assembly_index_BoardMatrixElement_create);
  /* export: 'PartitionListElement#get:x' */
  WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23getZ3AxZ_ii) = (&PartitionListElement_get_x);
  /* export: 'PartitionListElement#set:x' */
  WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23setZ3AxZ_vii) = (&PartitionListElement_set_x);
  /* export: 'PartitionListElement#get:y' */
  WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23getZ3AyZ_ii) = (&PartitionListElement_get_y);
  /* export: 'PartitionListElement#set:y' */
  WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23setZ3AyZ_vii) = (&PartitionListElement_set_y);
  /* export: 'PartitionListElement#get:t' */
  WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23getZ3AtZ_ii) = (&PartitionListElement_get_t);
  /* export: 'PartitionListElement#set:t' */
  WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23setZ3AtZ_vii) = (&PartitionListElement_set_t);
  /* export: 'PartitionListElement#constructor' */
  WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23constructorZ_iiiii) = (&assembly_index_PartitionListElement_constructor);
  /* export: 'PartitionListElement.create' */
  WASM_RT_ADD_PREFIX(Z_PartitionListElementZ2EcreateZ_iiii) = (&assembly_index_PartitionListElement_create);
  /* export: 'Constraint#get:x' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AxZ_ii) = (&Constraint_get_x);
  /* export: 'Constraint#set:x' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AxZ_vii) = (&Constraint_set_x);
  /* export: 'Constraint#get:y' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AyZ_ii) = (&Constraint_get_y);
  /* export: 'Constraint#set:y' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AyZ_vii) = (&Constraint_set_y);
  /* export: 'Constraint#get:classification' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AclassificationZ_ii) = (&Constraint_get_classification);
  /* export: 'Constraint#set:classification' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AclassificationZ_vii) = (&Constraint_set_classification);
  /* export: 'Constraint#get:name' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AnameZ_ii) = (&Constraint_get_name);
  /* export: 'Constraint#set:name' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AnameZ_vii) = (&Constraint_set_name);
  /* export: 'Constraint#get:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AserializedArgsZ_ii) = (&Constraint_get_serializedArgs);
  /* export: 'Constraint#set:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AserializedArgsZ_vii) = (&Constraint_set_serializedArgs);
  /* export: 'Constraint#constructor' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ23constructorZ_iiiiiii) = (&assembly_index_Constraint_constructor);
  /* export: 'Constraint#col' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ23colZ_viiiiii) = (&assembly_index_Constraint_col);
  /* export: 'Constraint.check' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ2EcheckZ_iiiii) = (&assembly_index_Constraint_check);
  /* export: 'Constraint.gen' */
  WASM_RT_ADD_PREFIX(Z_ConstraintZ2EgenZ_iiiiii) = (&assembly_index_Constraint_gen);
  /* export: 'Constraint1#get:x' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AxZ_ii) = (&Constraint1_get_x);
  /* export: 'Constraint1#set:x' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AxZ_vii) = (&Constraint1_set_x);
  /* export: 'Constraint1#get:y' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AyZ_ii) = (&Constraint1_get_y);
  /* export: 'Constraint1#set:y' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AyZ_vii) = (&Constraint1_set_y);
  /* export: 'Constraint1#get:classification' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AclassificationZ_ii) = (&Constraint1_get_classification);
  /* export: 'Constraint1#set:classification' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AclassificationZ_vii) = (&Constraint1_set_classification);
  /* export: 'Constraint1#get:name' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AnameZ_ii) = (&Constraint1_get_name);
  /* export: 'Constraint1#set:name' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AnameZ_vii) = (&Constraint1_set_name);
  /* export: 'Constraint1#get:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AserializedArgsZ_ii) = (&Constraint1_get_serializedArgs);
  /* export: 'Constraint1#set:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AserializedArgsZ_vii) = (&Constraint1_set_serializedArgs);
  /* export: 'Constraint1#constructor' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z23constructorZ_iiiiiii) = (&assembly_index_Constraint1_constructor);
  /* export: 'Constraint1#col' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z23colZ_viiiiii) = (&assembly_index_Constraint_col);
  /* export: 'Constraint1.check' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z2EcheckZ_iiiii) = (&assembly_index_Constraint1_check);
  /* export: 'Constraint1.gen' */
  WASM_RT_ADD_PREFIX(Z_Constraint1Z2EgenZ_iiiiii) = (&assembly_index_Constraint1_gen);
  /* export: 'Constraint2#get:x' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AxZ_ii) = (&Constraint2_get_x);
  /* export: 'Constraint2#set:x' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AxZ_vii) = (&Constraint2_set_x);
  /* export: 'Constraint2#get:y' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AyZ_ii) = (&Constraint2_get_y);
  /* export: 'Constraint2#set:y' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AyZ_vii) = (&Constraint2_set_y);
  /* export: 'Constraint2#get:classification' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AclassificationZ_ii) = (&Constraint2_get_classification);
  /* export: 'Constraint2#set:classification' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AclassificationZ_vii) = (&Constraint2_set_classification);
  /* export: 'Constraint2#get:name' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AnameZ_ii) = (&Constraint2_get_name);
  /* export: 'Constraint2#set:name' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AnameZ_vii) = (&Constraint2_set_name);
  /* export: 'Constraint2#get:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AserializedArgsZ_ii) = (&Constraint2_get_serializedArgs);
  /* export: 'Constraint2#set:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AserializedArgsZ_vii) = (&Constraint2_set_serializedArgs);
  /* export: 'Constraint2#constructor' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z23constructorZ_iiiiiii) = (&assembly_index_Constraint2_constructor);
  /* export: 'Constraint2#col' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z23colZ_viiiiii) = (&assembly_index_Constraint_col);
  /* export: 'Constraint2.gen' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z2EgenZ_iiiiii) = (&assembly_index_Constraint2_gen);
  /* export: 'Constraint2.check' */
  WASM_RT_ADD_PREFIX(Z_Constraint2Z2EcheckZ_iiiii) = (&assembly_index_Constraint2_check);
  /* export: 'Constraint3#get:x' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AxZ_ii) = (&Constraint3_get_x);
  /* export: 'Constraint3#set:x' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AxZ_vii) = (&Constraint3_set_x);
  /* export: 'Constraint3#get:y' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AyZ_ii) = (&Constraint3_get_y);
  /* export: 'Constraint3#set:y' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AyZ_vii) = (&Constraint3_set_y);
  /* export: 'Constraint3#get:classification' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AclassificationZ_ii) = (&Constraint3_get_classification);
  /* export: 'Constraint3#set:classification' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AclassificationZ_vii) = (&Constraint3_set_classification);
  /* export: 'Constraint3#get:name' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AnameZ_ii) = (&Constraint3_get_name);
  /* export: 'Constraint3#set:name' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AnameZ_vii) = (&Constraint3_set_name);
  /* export: 'Constraint3#get:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AserializedArgsZ_ii) = (&Constraint3_get_serializedArgs);
  /* export: 'Constraint3#set:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AserializedArgsZ_vii) = (&Constraint3_set_serializedArgs);
  /* export: 'Constraint3#constructor' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z23constructorZ_iiiiiii) = (&assembly_index_Constraint3_constructor);
  /* export: 'Constraint3#col' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z23colZ_viiiiii) = (&assembly_index_Constraint_col);
  /* export: 'Constraint3.brute' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z2EbruteZ_iiii) = (&assembly_index_Constraint3_brute);
  /* export: 'Constraint3.check' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z2EcheckZ_iiiii) = (&assembly_index_Constraint3_check);
  /* export: 'Constraint3.gen' */
  WASM_RT_ADD_PREFIX(Z_Constraint3Z2EgenZ_iiiiii) = (&assembly_index_Constraint3_gen);
  /* export: 'Constraint4#get:x' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AxZ_ii) = (&Constraint4_get_x);
  /* export: 'Constraint4#set:x' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AxZ_vii) = (&Constraint4_set_x);
  /* export: 'Constraint4#get:y' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AyZ_ii) = (&Constraint4_get_y);
  /* export: 'Constraint4#set:y' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AyZ_vii) = (&Constraint4_set_y);
  /* export: 'Constraint4#get:classification' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AclassificationZ_ii) = (&Constraint4_get_classification);
  /* export: 'Constraint4#set:classification' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AclassificationZ_vii) = (&Constraint4_set_classification);
  /* export: 'Constraint4#get:name' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AnameZ_ii) = (&Constraint4_get_name);
  /* export: 'Constraint4#set:name' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AnameZ_vii) = (&Constraint4_set_name);
  /* export: 'Constraint4#get:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AserializedArgsZ_ii) = (&Constraint4_get_serializedArgs);
  /* export: 'Constraint4#set:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AserializedArgsZ_vii) = (&Constraint4_set_serializedArgs);
  /* export: 'Constraint4#constructor' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z23constructorZ_iiiiiii) = (&assembly_index_Constraint4_constructor);
  /* export: 'Constraint4#col' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z23colZ_viiiiii) = (&assembly_index_Constraint_col);
  /* export: 'Constraint4.check' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z2EcheckZ_iiiii) = (&assembly_index_Constraint4_check);
  /* export: 'Constraint4.gen' */
  WASM_RT_ADD_PREFIX(Z_Constraint4Z2EgenZ_iiiiii) = (&assembly_index_Constraint4_gen);
  /* export: 'Constraint5#get:x' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AxZ_ii) = (&Constraint5_get_x);
  /* export: 'Constraint5#set:x' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AxZ_vii) = (&Constraint5_set_x);
  /* export: 'Constraint5#get:y' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AyZ_ii) = (&Constraint5_get_y);
  /* export: 'Constraint5#set:y' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AyZ_vii) = (&Constraint5_set_y);
  /* export: 'Constraint5#get:classification' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AclassificationZ_ii) = (&Constraint5_get_classification);
  /* export: 'Constraint5#set:classification' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AclassificationZ_vii) = (&Constraint5_set_classification);
  /* export: 'Constraint5#get:name' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AnameZ_ii) = (&Constraint5_get_name);
  /* export: 'Constraint5#set:name' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AnameZ_vii) = (&Constraint5_set_name);
  /* export: 'Constraint5#get:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AserializedArgsZ_ii) = (&Constraint5_get_serializedArgs);
  /* export: 'Constraint5#set:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AserializedArgsZ_vii) = (&Constraint5_set_serializedArgs);
  /* export: 'Constraint5#constructor' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z23constructorZ_iiiiiii) = (&assembly_index_Constraint5_constructor);
  /* export: 'Constraint5#col' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z23colZ_viiiiii) = (&assembly_index_Constraint_col);
  /* export: 'Constraint5.check' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z2EcheckZ_iiiii) = (&assembly_index_Constraint5_check);
  /* export: 'Constraint5.gen' */
  WASM_RT_ADD_PREFIX(Z_Constraint5Z2EgenZ_iiiiii) = (&assembly_index_Constraint5_gen);
  /* export: 'Constraint6#get:x' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AxZ_ii) = (&Constraint6_get_x);
  /* export: 'Constraint6#set:x' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AxZ_vii) = (&Constraint6_set_x);
  /* export: 'Constraint6#get:y' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AyZ_ii) = (&Constraint6_get_y);
  /* export: 'Constraint6#set:y' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AyZ_vii) = (&Constraint6_set_y);
  /* export: 'Constraint6#get:classification' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AclassificationZ_ii) = (&Constraint6_get_classification);
  /* export: 'Constraint6#set:classification' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AclassificationZ_vii) = (&Constraint6_set_classification);
  /* export: 'Constraint6#get:name' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AnameZ_ii) = (&Constraint6_get_name);
  /* export: 'Constraint6#set:name' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AnameZ_vii) = (&Constraint6_set_name);
  /* export: 'Constraint6#get:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AserializedArgsZ_ii) = (&Constraint6_get_serializedArgs);
  /* export: 'Constraint6#set:serializedArgs' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AserializedArgsZ_vii) = (&Constraint6_set_serializedArgs);
  /* export: 'Constraint6#constructor' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z23constructorZ_iiiiiii) = (&assembly_index_Constraint6_constructor);
  /* export: 'Constraint6#col' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z23colZ_viiiiii) = (&assembly_index_Constraint_col);
  /* export: 'Constraint6.check' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z2EcheckZ_iiiii) = (&assembly_index_Constraint6_check);
  /* export: 'Constraint6.gen' */
  WASM_RT_ADD_PREFIX(Z_Constraint6Z2EgenZ_iiiiii) = (&assembly_index_Constraint6_gen);
  /* export: 'checkAll' */
  WASM_RT_ADD_PREFIX(Z_checkAllZ_iiiii) = (&assembly_index_checkAll);
  /* export: 'State#get:mtx' */
  WASM_RT_ADD_PREFIX(Z_StateZ23getZ3AmtxZ_ii) = (&State_get_mtx);
  /* export: 'State#set:mtx' */
  WASM_RT_ADD_PREFIX(Z_StateZ23setZ3AmtxZ_vii) = (&State_set_mtx);
  /* export: 'State#get:parts' */
  WASM_RT_ADD_PREFIX(Z_StateZ23getZ3ApartsZ_ii) = (&State_get_parts);
  /* export: 'State#set:parts' */
  WASM_RT_ADD_PREFIX(Z_StateZ23setZ3ApartsZ_vii) = (&State_set_parts);
  /* export: 'State#constructor' */
  WASM_RT_ADD_PREFIX(Z_StateZ23constructorZ_iiii) = (&assembly_index_State_constructor);
  /* export: 'State.create' */
  WASM_RT_ADD_PREFIX(Z_StateZ2EcreateZ_iii) = (&assembly_index_State_create);
  /* export: 'genAll' */
  WASM_RT_ADD_PREFIX(Z_genAllZ_iiiiiiiiii) = (&assembly_index_genAll);
  /* export: 'deserializeBoardMatrix' */
  WASM_RT_ADD_PREFIX(Z_deserializeBoardMatrixZ_ii) = (&assembly_index_deserializeBoardMatrix);
  /* export: 'deserializePartitionList' */
  WASM_RT_ADD_PREFIX(Z_deserializePartitionListZ_ii) = (&assembly_index_deserializePartitionList);
  /* export: 'deserializeI32' */
  WASM_RT_ADD_PREFIX(Z_deserializeI32Z_ii) = (&assembly_index_deserializeI32);
  /* export: 'MatrixEncoder<i32>' */
  WASM_RT_ADD_PREFIX(Z_MatrixEncoderZ3Ci32Z3EZ_iii) = (&assembly_index_MatrixEncoder_i32_);
  /* export: 'MatrixEncoder<BoardMatrixElement>' */
  WASM_RT_ADD_PREFIX(Z_MatrixEncoderZ3CBoardMatrixElementZ3EZ_iii) = (&assembly_index_MatrixEncoder_BoardMatrixElement_);
  /* export: 'MatrixEncoder<PartitionListElement>' */
  WASM_RT_ADD_PREFIX(Z_MatrixEncoderZ3CPartitionListElementZ3EZ_iii) = (&assembly_index_MatrixEncoder_PartitionListElement_);
  /* export: 'serializeBoardMatrix' */
  WASM_RT_ADD_PREFIX(Z_serializeBoardMatrixZ_ii) = (&assembly_index_serializeBoardMatrix);
  /* export: 'serializePartitionList' */
  WASM_RT_ADD_PREFIX(Z_serializePartitionListZ_ii) = (&assembly_index_serializePartitionList);
  /* export: 'serializeI32' */
  WASM_RT_ADD_PREFIX(Z_serializeI32Z_ii) = (&assembly_index_serializeI32);
  /* export: 'memory.compare' */
  WASM_RT_ADD_PREFIX(Z_memoryZ2EcompareZ_iiii) = (&_lib_memory_memory_compare);
  /* export: 'memory.allocate' */
  WASM_RT_ADD_PREFIX(Z_memoryZ2EallocateZ_ii) = (&_lib_memory_memory_allocate);
  /* export: 'memory.free' */
  WASM_RT_ADD_PREFIX(Z_memoryZ2EfreeZ_vi) = (&_lib_memory_memory_free);
  /* export: 'memory.reset' */
  WASM_RT_ADD_PREFIX(Z_memoryZ2EresetZ_vv) = (&_lib_memory_memory_reset);
}

void WASM_RT_ADD_PREFIX(init)(void) {
  init_func_types();
  init_globals();
  init_memory();
  init_table();
  init_exports();
  start();
}
