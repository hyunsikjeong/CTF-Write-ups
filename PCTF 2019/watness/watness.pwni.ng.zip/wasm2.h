#ifndef OUT_H_GENERATED_
#define OUT_H_GENERATED_
#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#include "wasm-rt.h"

#ifndef WASM_RT_MODULE_PREFIX
#define WASM_RT_MODULE_PREFIX
#endif

#define WASM_RT_PASTE_(x, y) x ## y
#define WASM_RT_PASTE(x, y) WASM_RT_PASTE_(x, y)
#define WASM_RT_ADD_PREFIX(x) WASM_RT_PASTE(WASM_RT_MODULE_PREFIX, x)

/* TODO(binji): only use stdint.h types in header */
typedef uint8_t u8;
typedef int8_t s8;
typedef uint16_t u16;
typedef int16_t s16;
typedef uint32_t u32;
typedef int32_t s32;
typedef uint64_t u64;
typedef int64_t s64;
typedef float f32;
typedef double f64;

extern void WASM_RT_ADD_PREFIX(init)(void);

/* import: 'env' 'abort' */
extern void (*Z_envZ_abortZ_viiii)(u32, u32, u32, u32);
/* import: 'Date' 'now' */
extern f64 (*Z_DateZ_nowZ_dv)(void);
/* import: 'index' 'console.logS' */
extern void (*Z_indexZ_consoleZ2ElogSZ_vi)(u32);
/* import: 'index' 'console.logI' */
extern void (*Z_indexZ_consoleZ2ElogIZ_vi)(u32);

/* export: 'memory' */
extern wasm_rt_memory_t (*WASM_RT_ADD_PREFIX(Z_memory));
/* export: 'table' */
extern wasm_rt_table_t (*WASM_RT_ADD_PREFIX(Z_table));
/* export: 'genShuff' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_genShuffZ_i));
/* export: 'copyPath' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_copyPathZ_i));
/* export: 'gaussian' */
extern f64 (*WASM_RT_ADD_PREFIX(Z_gaussianZ_dv))(void);
/* export: 'arrayMap<PartitionListElement,PathMarker>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_arrayMapZ3CPartitionListElementZ2CPathMarkerZ3EZ_iii))(u32, u32);
/* export: 'arrayMap<i32>>>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_arrayMapZ3Ci32Z3EZ3EZ3EZ_iii))(u32, u32);
/* export: 'ArrayLen<BoardMatrixElement>>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ArrayLenZ3CBoardMatrixElementZ3EZ3EZ_ii))(u32);
/* export: 'ArrayLen<BoardMatrixElement>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ArrayLenZ3CBoardMatrixElementZ3EZ_ii))(u32);
/* export: 'ArrayLen<PartitionListElement>>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ArrayLenZ3CPartitionListElementZ3EZ3EZ_ii))(u32);
/* export: 'ArrayLen<PartitionListElement>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ArrayLenZ3CPartitionListElementZ3EZ_ii))(u32);
/* export: 'ArrayIndex<BoardMatrixElement>>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ArrayIndexZ3CBoardMatrixElementZ3EZ3EZ_iii))(u32, u32);
/* export: 'ArrayIndex<BoardMatrixElement>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ArrayIndexZ3CBoardMatrixElementZ3EZ_iii))(u32, u32);
/* export: 'ArrayIndex<PartitionListElement>>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ArrayIndexZ3CPartitionListElementZ3EZ3EZ_iii))(u32, u32);
/* export: 'ArrayIndex<PartitionListElement>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ArrayIndexZ3CPartitionListElementZ3EZ_iii))(u32, u32);
/* export: '_constrainer' */
extern void (*WASM_RT_ADD_PREFIX(Z__constrainerZ_vv))(void);
/* export: 'BoardMatrixElement#get:p' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23getZ3ApZ_ii))(u32);
/* export: 'BoardMatrixElement#set:p' */
extern void (*WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23setZ3ApZ_vii))(u32, u32);
/* export: 'BoardMatrixElement#get:t' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23getZ3AtZ_ii))(u32);
/* export: 'BoardMatrixElement#set:t' */
extern void (*WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23setZ3AtZ_vii))(u32, u32);
/* export: 'BoardMatrixElement#constructor' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ23constructorZ_iiii))(u32, u32, u32);
/* export: 'BoardMatrixElement.create' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_BoardMatrixElementZ2EcreateZ_iii))(u32, u32);
/* export: 'PartitionListElement#get:x' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23getZ3AxZ_ii))(u32);
/* export: 'PartitionListElement#set:x' */
extern void (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23setZ3AxZ_vii))(u32, u32);
/* export: 'PartitionListElement#get:y' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23getZ3AyZ_ii))(u32);
/* export: 'PartitionListElement#set:y' */
extern void (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23setZ3AyZ_vii))(u32, u32);
/* export: 'PartitionListElement#get:t' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23getZ3AtZ_ii))(u32);
/* export: 'PartitionListElement#set:t' */
extern void (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23setZ3AtZ_vii))(u32, u32);
/* export: 'PartitionListElement#constructor' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ23constructorZ_iiiii))(u32, u32, u32, u32);
/* export: 'PartitionListElement.create' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_PartitionListElementZ2EcreateZ_iiii))(u32, u32, u32);
/* export: 'Constraint#get:x' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AxZ_ii))(u32);
/* export: 'Constraint#set:x' */
extern void (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint#get:y' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AyZ_ii))(u32);
/* export: 'Constraint#set:y' */
extern void (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint#get:classification' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint#set:classification' */
extern void (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint#get:name' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AnameZ_ii))(u32);
/* export: 'Constraint#set:name' */
extern void (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint#get:serializedArgs' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint#set:serializedArgs' */
extern void (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint#constructor' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint#col' */
extern void (*WASM_RT_ADD_PREFIX(Z_ConstraintZ23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint.check' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint.gen' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_ConstraintZ2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'Constraint1#get:x' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AxZ_ii))(u32);
/* export: 'Constraint1#set:x' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint1#get:y' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AyZ_ii))(u32);
/* export: 'Constraint1#set:y' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint1#get:classification' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint1#set:classification' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint1#get:name' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AnameZ_ii))(u32);
/* export: 'Constraint1#set:name' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint1#get:serializedArgs' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint1#set:serializedArgs' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint1#constructor' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint1#col' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint1Z23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint1.check' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint1.gen' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint1Z2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'Constraint2#get:x' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AxZ_ii))(u32);
/* export: 'Constraint2#set:x' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint2#get:y' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AyZ_ii))(u32);
/* export: 'Constraint2#set:y' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint2#get:classification' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint2#set:classification' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint2#get:name' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AnameZ_ii))(u32);
/* export: 'Constraint2#set:name' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint2#get:serializedArgs' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint2#set:serializedArgs' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint2#constructor' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint2#col' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint2Z23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint2.gen' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'Constraint2.check' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint2Z2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint3#get:x' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AxZ_ii))(u32);
/* export: 'Constraint3#set:x' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint3#get:y' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AyZ_ii))(u32);
/* export: 'Constraint3#set:y' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint3#get:classification' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint3#set:classification' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint3#get:name' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AnameZ_ii))(u32);
/* export: 'Constraint3#set:name' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint3#get:serializedArgs' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint3#set:serializedArgs' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint3#constructor' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint3#col' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint3Z23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint3.brute' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z2EbruteZ_iiii))(u32, u32, u32);
/* export: 'Constraint3.check' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint3.gen' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint3Z2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'Constraint4#get:x' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AxZ_ii))(u32);
/* export: 'Constraint4#set:x' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint4#get:y' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AyZ_ii))(u32);
/* export: 'Constraint4#set:y' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint4#get:classification' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint4#set:classification' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint4#get:name' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AnameZ_ii))(u32);
/* export: 'Constraint4#set:name' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint4#get:serializedArgs' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint4#set:serializedArgs' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint4#constructor' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint4#col' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint4Z23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint4.check' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint4.gen' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint4Z2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'Constraint5#get:x' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AxZ_ii))(u32);
/* export: 'Constraint5#set:x' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint5#get:y' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AyZ_ii))(u32);
/* export: 'Constraint5#set:y' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint5#get:classification' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint5#set:classification' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint5#get:name' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AnameZ_ii))(u32);
/* export: 'Constraint5#set:name' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint5#get:serializedArgs' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint5#set:serializedArgs' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint5#constructor' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint5#col' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint5Z23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint5.check' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint5.gen' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint5Z2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'Constraint6#get:x' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AxZ_ii))(u32);
/* export: 'Constraint6#set:x' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AxZ_vii))(u32, u32);
/* export: 'Constraint6#get:y' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AyZ_ii))(u32);
/* export: 'Constraint6#set:y' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AyZ_vii))(u32, u32);
/* export: 'Constraint6#get:classification' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AclassificationZ_ii))(u32);
/* export: 'Constraint6#set:classification' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AclassificationZ_vii))(u32, u32);
/* export: 'Constraint6#get:name' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AnameZ_ii))(u32);
/* export: 'Constraint6#set:name' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AnameZ_vii))(u32, u32);
/* export: 'Constraint6#get:serializedArgs' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23getZ3AserializedArgsZ_ii))(u32);
/* export: 'Constraint6#set:serializedArgs' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23setZ3AserializedArgsZ_vii))(u32, u32);
/* export: 'Constraint6#constructor' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23constructorZ_iiiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint6#col' */
extern void (*WASM_RT_ADD_PREFIX(Z_Constraint6Z23colZ_viiiiii))(u32, u32, u32, u32, u32, u32);
/* export: 'Constraint6.check' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z2EcheckZ_iiiii))(u32, u32, u32, u32);
/* export: 'Constraint6.gen' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_Constraint6Z2EgenZ_iiiiii))(u32, u32, u32, u32, u32);
/* export: 'checkAll' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_checkAllZ_iiiii))(u32, u32, u32, u32);
/* export: 'State#get:mtx' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_StateZ23getZ3AmtxZ_ii))(u32);
/* export: 'State#set:mtx' */
extern void (*WASM_RT_ADD_PREFIX(Z_StateZ23setZ3AmtxZ_vii))(u32, u32);
/* export: 'State#get:parts' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_StateZ23getZ3ApartsZ_ii))(u32);
/* export: 'State#set:parts' */
extern void (*WASM_RT_ADD_PREFIX(Z_StateZ23setZ3ApartsZ_vii))(u32, u32);
/* export: 'State#constructor' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_StateZ23constructorZ_iiii))(u32, u32, u32);
/* export: 'State.create' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_StateZ2EcreateZ_iii))(u32, u32);
/* export: 'genAll' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_genAllZ_iiiiiiiiii))(u32, u32, u32, u32, u32, u32, u32, u32, u32);
/* export: 'deserializeBoardMatrix' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_deserializeBoardMatrixZ_ii))(u32);
/* export: 'deserializePartitionList' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_deserializePartitionListZ_ii))(u32);
/* export: 'deserializeI32' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_deserializeI32Z_ii))(u32);
/* export: 'MatrixEncoder<i32>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_MatrixEncoderZ3Ci32Z3EZ_iii))(u32, u32);
/* export: 'MatrixEncoder<BoardMatrixElement>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_MatrixEncoderZ3CBoardMatrixElementZ3EZ_iii))(u32, u32);
/* export: 'MatrixEncoder<PartitionListElement>' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_MatrixEncoderZ3CPartitionListElementZ3EZ_iii))(u32, u32);
/* export: 'serializeBoardMatrix' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_serializeBoardMatrixZ_ii))(u32);
/* export: 'serializePartitionList' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_serializePartitionListZ_ii))(u32);
/* export: 'serializeI32' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_serializeI32Z_ii))(u32);
/* export: 'memory.compare' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_memoryZ2EcompareZ_iiii))(u32, u32, u32);
/* export: 'memory.allocate' */
extern u32 (*WASM_RT_ADD_PREFIX(Z_memoryZ2EallocateZ_ii))(u32);
/* export: 'memory.free' */
extern void (*WASM_RT_ADD_PREFIX(Z_memoryZ2EfreeZ_vi))(u32);
/* export: 'memory.reset' */
extern void (*WASM_RT_ADD_PREFIX(Z_memoryZ2EresetZ_vv))(void);
#ifdef __cplusplus
}
#endif

#endif  /* OUT_H_GENERATED_ */
